# Kernel contract fixtures

These ABI/creation-bytecode fixtures exercise account behavior on a disposable Anvil chain. They are test builds, not mainnet deployment artifacts.

| Fixture                                                 | Source                                                                                                                                                                                                                     |
| ------------------------------------------------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Kernel v3.3, factory, ECDSA validator                   | [zerodevapp/kernel](https://github.com/zerodevapp/kernel/tree/cd697c7e21715d015e0643af22310a99aa17433b), tag `v3.3`, commit `cd697c7e21715d015e0643af22310a99aa17433b`                                                     |
| Kernel v4 UUPS, immutable ECDSA implementation, factory | [zerodevapp/kernel](https://github.com/zerodevapp/kernel/tree/c960b42d2ed4adb0d5328f6e762962debdf8e57a), released tag `v4.0` (contract version `0.4.0`), commit `c960b42d2ed4adb0d5328f6e762962debdf8e57a`                 |
| v4 ECDSA validator and module mocks                     | The same release's `test/mock/` sources: ECDSAValidator, MockSigner, MockPolicy, MockHook, MockExecutor, MockFallback, MockCallee and MockAction. These are upstream **test modules**, not production plugin audit claims. |
| EntryPoint 0.9                                          | [account-abstraction](https://github.com/eth-infinitism/account-abstraction/tree/86fcd84cf7263fe384d61d078ee747b16e69a496), commit `86fcd84cf7263fe384d61d078ee747b16e69a496`                                              |
| EntryPoint 0.7                                          | Artifact from the pinned npm development dependency `@account-abstraction/contracts@0.7.0`                                                                                                                                 |
| Detached paymaster                                      | Local `test/contracts/kernel-v4/test/DetachedPaymaster.sol`; verifies a separate signer using the pinned EntryPoint 0.9 signature decoder and records successful `postOp` calls. Test-only, not a production paymaster.    |

Sources and the compilation import closure are vendored under `test/contracts/`, with SPDX notices and available upstream license files retained. Both builds use Solidity **0.8.33**, Prague, optimizer **200** runs, and `via_ir = true`. All 22 v4 contract source files were compared byte-for-byte with the pinned release. Kernel source files retain the upstream contents; the v4 test modules are copied into `test/`, and `EntryPointFixture.sol` imports the EntryPoint for artifact generation. Release fixtures live in `4/`; the prerelease fixture directory has been removed. The test build retains compiler metadata and is not claimed to reproduce upstream deployment bytecode.

Dependency pins:

- Solady **0.1.26**, Soldeer archive SHA-256 `9872ac7cfd32c1eba32800508a1325c49f4a4aa8c6f670454db91971a583e26b`. Both test builds use this version; it differs from the historical v3.3 submodule pin.
- ExcessivelySafeCall **1.0.1**, commit `81cd99ce3e69117d665d7601c330ea03b97acce0`.
- OpenZeppelin Contracts **5.4.0**, Soldeer archive SHA-256 `3dd38f17610dba4602bd008ee2cb551e51e97d7b4ce04e1ffdf853da832942fa`.
- Account Abstraction **0.9.0**, commit listed above.

Regenerate with `bun run fixtures:kernel` after installing Foundry and Solidity 0.8.33. The build is offline and uses relative remappings; it needs no sibling repositories. `sha256.json` records the source/configuration and generated artifact hashes. Run `bun run test:kernel` after rebuilding. The release discovery test checks the deployed EIP-712 domain version, every module category, scoped hooks, removal, root replacement without an uninstall event, historical block pins and reconstruction through a provider limited to two-block log queries.

The integration relay uses conservative fallback estimates and calls the actual EntryPoint for validation/submission. Assertions cover deployment, independent signer/account addresses, key rotation, grants/revokes, module enable/disable without estimate RPCs, and the EP 0.9 detached-signature hash. The sponsorship integration test deploys an unfunded Kernel v4 account with parallel sender/paymaster signing, charges the paymaster deposit, executes `postOp`, and separately rejects corrupted sender and paymaster signatures. Complete deployment and sponsorship budgets skip every estimate RPC in that test. Run `bun run test:integration` for this additional coverage. This does not prove production gas minima or hosted bundler acceptance.
