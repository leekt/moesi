The optional `cetane/wasm` backend binds directly to the unmodified Keccak
binary distributed in `hash-wasm@4.12.0`. No additional runtime package or
external WASM asset is required. JavaScript hashing remains the default.

Run from a checkout with its pinned development dependencies installed:

```sh
node scripts/wasm-keccak/extract.mjs --check
```

Omit `--check` to regenerate the embedded TypeScript module and license files.
The script validates the package version, distribution-file hash, one exact
base64 payload, decoded binary hash and original license/source hashes before
writing. It performs no network access and does not modify the WASM payload.
`provenance.json` records the npm integrity and source/artifact fingerprints.
This is reproducible extraction of a pinned distribution artifact; it does
not claim a reproducible compilation from the C sources.

The artifact is `dist/keccak.umd.min.js`. Its sole WASM payload contains 4,018
bytes, with SHA-256
`4b3e3ab7973037bfdf21c776085c617dd15d8faad72c073f2eb4ca022a233f8b`.
The upstream implementation is `src/sha3.c`, using `src/hash-wasm.h` for its
16 KiB input buffer. The binary has no imports and fixed 128 KiB linear memory.
The adapter uses Keccak-256 parameters (`256`, padding `0x01`), calculates
single inputs through 16 KiB in one call, and streams larger or segmented
inputs through bounded chunks. Returned digests own their 32 bytes. The
instance, state and input buffer remain private.

The package MIT notice by Dani Biró and the original sha3.c permission notice
by Aleksey Kravchenko are retained in `src/wasm/LICENSE.hash-wasm` and
`src/wasm/LICENSE.sha3`. Both notices and this extraction/provenance directory
are included in the npm package. `hash-wasm` remains a pinned development
dependency for extraction and historical reference benchmarks.

Public setup runs six known-answer, segmented-input and reset checks before
installing the backend. Failed setup leaves JavaScript available and permits
an explicit retry. Tests preserve byte/hex validation, caller-view and decoder
reentrancy, blocked WebAssembly behavior, arbitrary chunk boundaries, input
immutability and output ownership. Installed hashing errors propagate rather
than silently falling back. Hash input is not guaranteed to be erased from
private scratch after use.

The [isolated paired comparison](../../bench/runs/20261003-eoa-tail/report.md)
and [fresh-process startup evidence](../../bench/runs/20261003-eoa-tail/direct-wasm/startup/README.md)
retain the measurements that motivated this adapter, with source identities
and limitations. They do not measure subsequent combinations with other changes.
