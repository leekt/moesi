// Re-extract the pinned upstream artifact; this does not rebuild the C source.
import assert from 'node:assert/strict'
import { createHash } from 'node:crypto'
import { readFile, writeFile } from 'node:fs/promises'
import { fileURLToPath } from 'node:url'

const sha256 = (bytes) => createHash('sha256').update(bytes).digest('hex')
const packageRoot = new URL('../../node_modules/hash-wasm/', import.meta.url)
const packageJson = JSON.parse(
  await readFile(new URL('package.json', packageRoot)),
)
assert.equal(packageJson.version, '4.12.0')
const artifact = await readFile(new URL('dist/keccak.umd.min.js', packageRoot))
assert.equal(
  sha256(artifact),
  'e27ef358910bbf7b6c3efaaa1a2ddc1b3cbccc61c00574ded4ad78b3cafea4f5',
)
const matches = [
  ...artifact.toString('utf8').matchAll(/["'](AGFzb[A-Za-z0-9+/=]+)["']/g),
]
assert.equal(matches.length, 1)
const encoded = matches[0][1]
assert.equal(encoded.length, 5360)
const binary = Buffer.from(encoded, 'base64')
assert.equal(binary.length, 4018)
const binaryHash = sha256(binary)
assert.equal(
  binaryHash,
  '4b3e3ab7973037bfdf21c776085c617dd15d8faad72c073f2eb4ca022a233f8b',
)
const moduleSource =
  '// Exact unmodified binary extracted from hash-wasm@4.12.0.\n' +
  `// SHA-256: ${binaryHash}\n` +
  '// Upstream notices: LICENSE.hash-wasm and LICENSE.sha3.\n' +
  `export const wasmBase64 =\n  '${encoded}'\n`
const sha3 = await readFile(new URL('src/sha3.c', packageRoot), 'utf8')
assert.equal(
  sha256(sha3),
  'f84ceb8bc4c556ee0f679116f13c3f611cfe8c0571a63191947e295ab87e501d',
)
const license = await readFile(new URL('LICENSE', packageRoot), 'utf8')
assert.equal(
  sha256(license),
  'c14dea172f72f2714284a0ac2ab1b00b5352a01409d58255a46227ffc541debd',
)
const files = {
  'keccak.wasm.ts': moduleSource,
  'LICENSE.hash-wasm': license,
  'LICENSE.sha3': sha3.slice(0, sha3.indexOf('*/') + 2) + '\n',
}
assert(process.argv.slice(2).every((arg) => arg === '--check'))
for (const [name, contents] of Object.entries(files)) {
  const target = new URL(`../../src/wasm/${name}`, import.meta.url)
  if (process.argv.includes('--check'))
    assert.equal(await readFile(target, 'utf8'), contents)
  else await writeFile(target, contents)
}
console.log(
  JSON.stringify({
    status: process.argv.includes('--check')
      ? 'exact extraction verified'
      : 'exact extraction written',
    artifact: fileURLToPath(new URL('dist/keccak.umd.min.js', packageRoot)),
    binaryHash,
    bytes: binary.length,
  }),
)
