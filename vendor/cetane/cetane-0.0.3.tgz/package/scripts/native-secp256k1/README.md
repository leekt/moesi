# Native libsecp256k1 signer

This optional Node-API 8 addon targets **macOS 11+ on Apple arm64**. The target
flag is a build minimum, not evidence of a run on every macOS release. It uses
libsecp256k1 v0.7.1 with its 22 KiB generator table and native `__int128`
arithmetic. No host-specific CPU tuning is enabled.

The source archive, compiler, Node 22.23.1 C headers and SDK settings are pinned
in `pins.json`. The explicit build uses local files only. It is never run by
package installation or module import and never downloads a compiler or source.

```sh
node scripts/native-secp256k1/build.mjs \
  --archive /path/to/secp256k1-v0.7.1.tar.gz \
  --headers /path/to/node22.23.1/include/node

# Rebuild and compare the committed binary and its provenance without replacing them.
node scripts/native-secp256k1/build.mjs \
  --archive /path/to/secp256k1-v0.7.1.tar.gz \
  --headers /path/to/node22.23.1/include/node --check
```

`--compiler`, `--sdk` and `--output` accept explicit local paths. Their contents
must match the pinned inputs. By default, compiler/SDK locations come from
`xcrun`, and output goes to `native/darwin-arm64`. Each attempt retains a fresh
temporary directory and an exact command/status manifest, including failures.
Relative source paths and prefix maps avoid embedding temporary build directories.
Only the two Node-API module entry symbols are exported; unused upstream routines
and tables can be removed by the linker. There is no arbitrary binary-size cap.

Each type-tagged `napi_wrap` object owns its key and separately randomized,
preallocated context. Raw API methods accept exact ordinary Uint8Array inputs,
copy them before cryptographic operations, and reject shared/detached buffers.
Methods verify the native receiver tag before accessing its context. Signing
uses upstream deterministic RFC 6979, low-S output and checked recovery parity.
No JavaScript callbacks run during cryptographic operations. Disposal/finalization
destroys the context, explicitly wipes its owned memory and key, then frees it;
temporary buffers are wiped on all exits. This does not promise VM-wide erasure
of caller strings or provide externally instrumented proof of heap erasure.

The upstream MIT license ships beside the native binary. Cetane's small C wrapper
uses the repository MIT license. The original isolated prototype and measurements
remain separate from verification of the final packaged asset.
