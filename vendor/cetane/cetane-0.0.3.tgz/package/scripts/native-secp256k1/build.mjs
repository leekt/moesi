import assert from 'node:assert/strict'
import { execFileSync } from 'node:child_process'
import { createHash } from 'node:crypto'
import { copyFile, mkdir, mkdtemp, readFile, writeFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { dirname, join, resolve } from 'node:path'
import { fileURLToPath } from 'node:url'

// Explicit, offline maintainer build. Module import and package installation never run it.
const directory = dirname(fileURLToPath(import.meta.url))
const pins = JSON.parse(await readFile(join(directory, 'pins.json'), 'utf8'))
const sha256 = (bytes) => createHash('sha256').update(bytes).digest('hex')
const arguments_ = process.argv.slice(2)
const options = {
  output: resolve(directory, '../../native/darwin-arm64'),
  check: false,
}
for (let index = 0; index < arguments_.length; index++) {
  const argument = arguments_[index]
  if (argument === '--check') options.check = true
  else if (
    ['--archive', '--headers', '--compiler', '--sdk', '--output'].includes(
      argument,
    ) &&
    arguments_[index + 1]
  )
    options[argument.slice(2)] = resolve(arguments_[++index])
  else
    throw Error(
      'Usage: node build.mjs --archive SOURCE.tar.gz --headers NODE_INCLUDE_DIR [--compiler CLANG] [--sdk SDK_DIR] [--output DIR] [--check]',
    )
}
assert(
  options.archive && options.headers,
  'Supply a local pinned archive and local Node header directory; no files are downloaded.',
)
assert.equal(
  process.platform,
  'darwin',
  'The current native signer build targets macOS only.',
)
assert.equal(
  process.arch,
  'arm64',
  'The current native signer build targets Apple arm64 only.',
)
const compiler =
  options.compiler ??
  execFileSync('/usr/bin/xcrun', ['--find', 'clang'], {
    encoding: 'utf8',
  }).trim()
const sdk =
  options.sdk ??
  execFileSync('/usr/bin/xcrun', ['--show-sdk-path'], {
    encoding: 'utf8',
  }).trim()
const archive = await readFile(options.archive)
assert.equal(
  sha256(archive),
  pins.source.archiveSha256,
  'Pinned upstream source archive checksum',
)
assert.equal(
  sha256(await readFile(compiler)),
  pins.compiler.sha256,
  'Pinned compiler checksum',
)
assert.equal(
  execFileSync(compiler, ['--version'], { encoding: 'utf8' }),
  pins.compiler.version,
  'Pinned compiler version',
)
assert.equal(
  sha256(await readFile(join(sdk, 'SDKSettings.json'))),
  pins.sdk.settingsSha256,
  'Pinned macOS SDK settings',
)
for (const [name, hash] of Object.entries(pins.headers.files))
  assert.equal(
    sha256(await readFile(join(options.headers, name))),
    hash,
    `Pinned Node header: ${name}`,
  )
const inputNames = ['addon.c', 'build.mjs', 'exports.txt', 'pins.json']
const inputs = Object.fromEntries(
  await Promise.all(
    inputNames.map(async (name) => [
      name,
      sha256(await readFile(join(directory, name))),
    ]),
  ),
)
const work = await mkdtemp(join(tmpdir(), 'cetane-native-build-'))
const commonArgs = [
  '-target',
  pins.target.triple,
  '-isysroot',
  sdk,
  '-std=c11',
  '-O3',
  '-fvisibility=hidden',
  '-fstack-protector-strong',
  '-ffunction-sections',
  '-fdata-sections',
  `-ffile-prefix-map=${work}=.`,
  `-fmacro-prefix-map=${work}=.`,
  '-DNAPI_VERSION=8',
  '-DBUILDING_NODE_EXTENSION',
  '-DENABLE_MODULE_RECOVERY',
  '-DUSE_FORCE_WIDEMUL_INT128',
  '-DCOMB_BLOCKS=11',
  '-DCOMB_TEETH=6',
  '-I',
  'include/node',
  '-I',
  'secp256k1-0.7.1/include',
  '-bundle',
  '-undefined',
  'dynamic_lookup',
  '-Wl,-dead_strip',
  '-Wl,-exported_symbols_list,exports.txt',
  'addon.c',
  'secp256k1-0.7.1/src/secp256k1.c',
  'secp256k1-0.7.1/src/precomputed_ecmult.c',
  'secp256k1-0.7.1/src/precomputed_ecmult_gen.c',
  '-o',
  'signer.node',
]
const manifest = {
  status: 'running',
  startedAt: new Date().toISOString(),
  work,
  archive: options.archive,
  headers: options.headers,
  compiler,
  sdk,
  inputs,
  pins,
  command: [compiler, ...commonArgs],
}
const save = () =>
  writeFile(
    join(work, 'build-manifest.json'),
    JSON.stringify(manifest, null, 2) + '\n',
  )
await save()
try {
  await writeFile(join(work, 'upstream.tar.gz'), archive)
  execFileSync('/usr/bin/tar', ['-xzf', 'upstream.tar.gz'], { cwd: work })
  await mkdir(join(work, 'include/node'), { recursive: true })
  for (const name of Object.keys(pins.headers.files))
    await copyFile(
      join(options.headers, name),
      join(work, 'include/node', name),
    )
  for (const name of ['addon.c', 'exports.txt'])
    await copyFile(join(directory, name), join(work, name))
  execFileSync(compiler, commonArgs, { cwd: work, stdio: 'inherit' })
  const binary = await readFile(join(work, 'signer.node'))
  const symbols = execFileSync(
    '/usr/bin/nm',
    ['-gU', join(work, 'signer.node')],
    { encoding: 'utf8' },
  )
  const exported = symbols
    .trim()
    .split('\n')
    .filter(Boolean)
    .map((line) => line.trim().split(/\s+/).at(-1))
    .sort()
  assert.deepEqual(
    exported,
    ['_napi_register_module_v1', '_node_api_module_get_api_version_v1'],
    'Only the two Node-API entry symbols are exported',
  )
  for (const name of inputNames)
    assert.equal(
      sha256(await readFile(join(directory, name))),
      inputs[name],
      `Build input changed: ${name}`,
    )
  const provenance = {
    schemaVersion: 1,
    source: pins.source,
    compiler: pins.compiler,
    headers: pins.headers,
    sdk: pins.sdk,
    target: pins.target,
    inputs,
    flags: commonArgs.map((argument) =>
      argument.replaceAll(work, '<WORK>').replaceAll(sdk, '<SDK>'),
    ),
    binary: { bytes: binary.length, sha256: sha256(binary) },
    exports: exported,
  }
  const encoded = JSON.stringify(provenance, null, 2) + '\n'
  if (options.check) {
    assert.deepEqual(
      binary,
      await readFile(join(options.output, 'signer.node')),
      'Rebuilt native binary matches',
    )
    assert.equal(
      encoded,
      await readFile(join(options.output, 'provenance.json'), 'utf8'),
      'Native build provenance matches',
    )
  } else {
    await mkdir(options.output, { recursive: true })
    await writeFile(join(options.output, 'signer.node'), binary)
    await writeFile(join(options.output, 'provenance.json'), encoded)
    await copyFile(
      join(work, 'secp256k1-0.7.1/COPYING'),
      join(options.output, 'LICENSE.secp256k1'),
    )
  }
  manifest.status = 'complete'
  manifest.binary = provenance.binary
  manifest.exports = exported
  manifest.linkedLibraries = execFileSync(
    '/usr/bin/otool',
    ['-L', join(work, 'signer.node')],
    { encoding: 'utf8' },
  )
  manifest.output = options.output
} catch (error) {
  manifest.status = 'failed'
  manifest.error = String(error)
  throw error
} finally {
  manifest.finishedAt = new Date().toISOString()
  await save()
  console.log(
    JSON.stringify({
      status: manifest.status,
      manifest: join(work, 'build-manifest.json'),
      binary: manifest.binary,
    }),
  )
}
