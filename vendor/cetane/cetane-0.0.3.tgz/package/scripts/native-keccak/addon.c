#define NAPI_VERSION 8
#include <node_api.h>
#include <stdbool.h>
#include <stdint.h>
#include <stddef.h>
#include "keccak.c"

/* Private raw contract: ordinary, attached Uint8Array views only. The JS
 * adapter normalizes RAB/SAB views to owned fixed backing. N-API 8 alone cannot
 * distinguish an already-OOB resizable view from a legitimate empty view.
 * No mutable C state or napi_ref is shared between calls or environments. */
static bool ok(napi_env env, napi_status status) {
  if (status == napi_ok) return true;
  bool pending = false;
  napi_is_exception_pending(env, &pending);
  if (!pending) napi_throw_error(env, NULL, "Native Keccak API operation failed.");
  return false;
}

static bool invalid(napi_env env, const char* message) {
  napi_throw_type_error(env, NULL, message);
  return false;
}

/* No property lookup, coercion, callbacks or borrowed data pointer here. */
static bool validate(napi_env env, napi_value value) {
  bool typed = false, ordinary = false, detached = true;
  napi_typedarray_type type;
  size_t length, offset;
  napi_value backing;
  if (!ok(env, napi_is_typedarray(env, value, &typed))) return false;
  if (!typed) return invalid(env, "Expected Uint8Array input.");
  if (!ok(env, napi_get_typedarray_info(env, value, &type, &length,
                                       NULL, &backing, &offset))) return false;
  if (type != napi_uint8_array) return invalid(env, "Expected Uint8Array input.");
  if (!ok(env, napi_is_arraybuffer(env, backing, &ordinary))) return false;
  if (!ordinary) return invalid(env, "Shared backing memory is unsupported.");
  if (!ok(env, napi_is_detached_arraybuffer(env, backing, &detached))) return false;
  if (detached) return invalid(env, "Detached backing memory is unsupported.");
  return true;
}

typedef struct { const uint8_t* data; size_t length; } input_view;

/* Called only after validation across both arguments.
 * get_typedarray_info reads native metadata without invoking JS getters; the
 * scoped argument handles retain each view and backing store throughout crypto. */
static bool borrow(napi_env env, napi_value value, input_view* view) {
  napi_typedarray_type type;
  void* data = NULL;
  size_t offset;
  if (!ok(env, napi_get_typedarray_info(env, value, &type, &view->length,
                                       &data, NULL, &offset))) return false;
  if (type != napi_uint8_array || (view->length && !data))
    return invalid(env, "Invalid Uint8Array storage.");
  view->data = (const uint8_t*)data;
  return true;
}

static napi_value hash(napi_env env, napi_callback_info info) {
  size_t argc = 3;
  napi_value argv[3], result = NULL;
  if (!ok(env, napi_get_cb_info(env, info, &argc, argv, NULL, NULL))) return NULL;
  if (argc != 1 && argc != 2) {
    invalid(env, "hash requires one or two byte segments.");
    return NULL;
  }
  for (size_t i = 0; i < argc; i++) if (!validate(env, argv[i])) return NULL;
  input_view inputs[2] = {{0}};
  for (size_t i = 0; i < argc; i++) if (!borrow(env, argv[i], &inputs[i])) return NULL;

  /* No N-API calls or JavaScript execution from here through finalization. */
  struct SHA3_CTX context;
  uint8_t output[32];
  keccak_init(&context);
  for (size_t i = 0; i < argc; i++)
    keccak_update(&context, inputs[i].data, inputs[i].length);
  keccak_final(&context, output);

  /* Inputs are no longer read. Creating the string may allocate or collect;
   * only owned stack bytes are used now. N-API copies these 66 Latin-1 bytes. */
  static const char digits[] = "0123456789abcdef";
  char encoded[66];
  encoded[0] = '0';
  encoded[1] = 'x';
  for (size_t i = 0; i < 32; i++) {
    encoded[2 + i * 2] = digits[output[i] >> 4];
    encoded[3 + i * 2] = digits[output[i] & 15];
  }
  if (!ok(env, napi_create_string_latin1(env, encoded, sizeof(encoded), &result)))
    return NULL;
  return result;
}

NAPI_MODULE_INIT() {
  const napi_property_descriptor properties[] = {
    {"hash", NULL, hash, NULL, NULL, NULL, napi_default, NULL},
  };
  if (!ok(env, napi_define_properties(env, exports, 1, properties))) return NULL;
  return exports;
}
