/* sha3.c - an implementation of Secure Hash Algorithm 3 (Keccak).
 * based on the
 * The Keccak SHA-3 submission. Submission to NIST (Round 3), 2011
 * by Guido Bertoni, Joan Daemen, Michaël Peeters and Gilles Van Assche
 *
 * Copyright (c) 2013, Aleksey Kravchenko <rhash.admin@gmail.com>
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOFTWARE  INCLUDING ALL IMPLIED WARRANTIES OF  MERCHANTABILITY
 * AND FITNESS.  IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT,
 * INDIRECT,  OR CONSEQUENTIAL DAMAGES  OR ANY DAMAGES WHATSOEVER RESULTING FROM
 * LOSS OF USE,  DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT,  NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF  OR IN CONNECTION  WITH THE USE  OR
 * PERFORMANCE OF THIS SOFTWARE.

 * Modified for hash-wasm by Dani Biró
 */

#include <stdint.h>
#include <stddef.h>

/* Derived from the pinned hash-wasm source. Explicit bytes make alignment and
 * aliasing independent of caller offsets and of the native platform. */
static uint64_t load64_le(const uint8_t* input) {
  uint64_t result = 0;
  for (unsigned i = 0; i < 8; i++) result |= (uint64_t)input[i] << (i * 8);
  return result;
}

#define NumberOfRounds 24
#define sha3_max_permutation_size 25
#define sha3_max_rate_in_qwords 24

#define I64(x) x##ULL
#define ROTL64(qword, n) ((qword) << (n) ^ ((qword) >> (64 - (n))))

struct SHA3_CTX {
  /* 1600 bits algorithm hashing state */
  uint64_t hash[sha3_max_permutation_size];
  /* 1536-bit buffer for leftovers */
  uint64_t message[sha3_max_rate_in_qwords];
  /* count of bytes in the message[] buffer */
  unsigned rest;
  /* size of a message block processed at once */
  unsigned block_size;
};


/* SHA3 (Keccak) constants for 24 rounds */
static const uint64_t keccak_round_constants[NumberOfRounds] = {
  I64(0x0000000000000001), I64(0x0000000000008082), I64(0x800000000000808A), I64(0x8000000080008000),
  I64(0x000000000000808B), I64(0x0000000080000001), I64(0x8000000080008081), I64(0x8000000000008009),
  I64(0x000000000000008A), I64(0x0000000000000088), I64(0x0000000080008009), I64(0x000000008000000A),
  I64(0x000000008000808B), I64(0x800000000000008B), I64(0x8000000000008089), I64(0x8000000000008003),
  I64(0x8000000000008002), I64(0x8000000000000080), I64(0x000000000000800A), I64(0x800000008000000A),
  I64(0x8000000080008081), I64(0x8000000000008080), I64(0x0000000080000001), I64(0x8000000080008008)
};

/* Initializing a sha3 context for given number of output bits */
static void keccak_init(struct SHA3_CTX* ctx) {
  /* NB: The Keccak capacity parameter = bits * 2 */
  uint32_t rate = 1600 - 256 * 2;

  for(int i = 0; i < sha3_max_permutation_size; i++) {
    ctx->hash[i] = 0;
  }

  for(int i = 0; i < sha3_max_rate_in_qwords; i++) {
    ctx->message[i] = 0;
  }

  ctx->rest = 0;
  ctx->block_size = rate / 8;
}

#define XORED_A(i) A[(i)] ^ A[(i) + 5] ^ A[(i) + 10] ^ A[(i) + 15] ^ A[(i) + 20]
#define THETA_STEP(i)    \
  A[(i)] ^= D[(i)];      \
  A[(i) + 5] ^= D[(i)];  \
  A[(i) + 10] ^= D[(i)]; \
  A[(i) + 15] ^= D[(i)]; \
  A[(i) + 20] ^= D[(i)]

/* Keccak theta() transformation */
static void keccak_theta(uint64_t* A) {
  uint64_t D[5];
  D[0] = ROTL64(XORED_A(1), 1) ^ XORED_A(4);
  D[1] = ROTL64(XORED_A(2), 1) ^ XORED_A(0);
  D[2] = ROTL64(XORED_A(3), 1) ^ XORED_A(1);
  D[3] = ROTL64(XORED_A(4), 1) ^ XORED_A(2);
  D[4] = ROTL64(XORED_A(0), 1) ^ XORED_A(3);
  THETA_STEP(0);
  THETA_STEP(1);
  THETA_STEP(2);
  THETA_STEP(3);
  THETA_STEP(4);
}

/* Keccak pi() transformation */
static void keccak_pi(uint64_t* A) {
  uint64_t A1;
  A1 = A[1];
  A[1] = A[6];
  A[6] = A[9];
  A[9] = A[22];
  A[22] = A[14];
  A[14] = A[20];
  A[20] = A[2];
  A[2] = A[12];
  A[12] = A[13];
  A[13] = A[19];
  A[19] = A[23];
  A[23] = A[15];
  A[15] = A[4];
  A[4] = A[24];
  A[24] = A[21];
  A[21] = A[8];
  A[8] = A[16];
  A[16] = A[5];
  A[5] = A[3];
  A[3] = A[18];
  A[18] = A[17];
  A[17] = A[11];
  A[11] = A[7];
  A[7] = A[10];
  A[10] = A1;
  /* note: A[ 0] is left as is */
}

#define CHI_STEP(i)                       \
  A0 = A[0 + (i)];                        \
  A1 = A[1 + (i)];                        \
  A[0 + (i)] ^= ~A1 & A[2 + (i)];         \
  A[1 + (i)] ^= ~A[2 + (i)] & A[3 + (i)]; \
  A[2 + (i)] ^= ~A[3 + (i)] & A[4 + (i)]; \
  A[3 + (i)] ^= ~A[4 + (i)] & A0;         \
  A[4 + (i)] ^= ~A0 & A1

/* Keccak chi() transformation */
static void keccak_chi(uint64_t* A) {
  uint64_t A0, A1;
  CHI_STEP(0);
  CHI_STEP(5);
  CHI_STEP(10);
  CHI_STEP(15);
  CHI_STEP(20);
}

/* The pinned assembly receives our owned aligned 25-lane state, never caller
 * input. Keep the checked byte absorption and Keccak padding unchanged. */
#if !defined(__APPLE__) || !defined(__aarch64__) || !defined(__ARM_FEATURE_SHA3)
#error "This isolated permutation requires Apple arm64 with SHA3 (minimum Apple M1)"
#endif
#if __BYTE_ORDER__ != __ORDER_LITTLE_ENDIAN__
#error "This isolated permutation requires little-endian state lanes"
#endif
extern void KeccakP1600_v84a_permute24(uint64_t state[25], const uint64_t rc[24])
  __attribute__((visibility("hidden")));

static void sha3_permutation(uint64_t* state) {
  KeccakP1600_v84a_permute24(state, keccak_round_constants);
}

/**
 * The core transformation. Process the specified block of data.
 *
 * @param hash the algorithm state
 * @param block the message block to process
 * @param block_size the size of the processed block in bytes
 */
static void sha3_process_block(
  uint64_t hash[25], const uint8_t* block, uint32_t block_size
) {
  /* expanded loop */
  hash[0] ^= load64_le(block + 0);
  hash[1] ^= load64_le(block + 8);
  hash[2] ^= load64_le(block + 16);
  hash[3] ^= load64_le(block + 24);
  hash[4] ^= load64_le(block + 32);
  hash[5] ^= load64_le(block + 40);
  hash[6] ^= load64_le(block + 48);
  hash[7] ^= load64_le(block + 56);
  hash[8] ^= load64_le(block + 64);
  /* if not sha3-512 */
  if (block_size > 72) {
    hash[9] ^= load64_le(block + 72);
    hash[10] ^= load64_le(block + 80);
    hash[11] ^= load64_le(block + 88);
    hash[12] ^= load64_le(block + 96);
    /* if not sha3-384 */
    if (block_size > 104) {
      hash[13] ^= load64_le(block + 104);
      hash[14] ^= load64_le(block + 112);
      hash[15] ^= load64_le(block + 120);
      hash[16] ^= load64_le(block + 128);
      /* if not sha3-256 */
      if (block_size > 136) {
        hash[17] ^= load64_le(block + 136);
#ifdef FULL_SHA3_FAMILY_SUPPORT
        /* if not sha3-224 */
        if (block_size > 144) {
          hash[18] ^= load64_le(block + 144);
          hash[19] ^= load64_le(block + 152);
          hash[20] ^= load64_le(block + 160);
          hash[21] ^= load64_le(block + 168);
          hash[22] ^= load64_le(block + 176);
          hash[23] ^= load64_le(block + 184);
          hash[24] ^= load64_le(block + 192);
        }
#endif
      }
    }
  }
  /* make a permutation of the hash */
  sha3_permutation(hash);
}

#define SHA3_FINALIZED 0x80000000

/**
 * Calculate message hash.
 * Can be called repeatedly with chunks of the message to be hashed.
 *
 * @param msg message chunk
 * @param size length of the message chunk
 */
static void keccak_update(struct SHA3_CTX* ctx, const uint8_t* msg, size_t size) {
  uint32_t index = (uint32_t)ctx->rest;
  uint32_t block_size = (uint32_t)ctx->block_size;

  if (ctx->rest & SHA3_FINALIZED) return; /* too late for additional input */
  ctx->rest = (unsigned)((ctx->rest + size % block_size) % block_size);

  /* fill partial block */
  if (index) {
    uint32_t left = block_size - index;
    uint32_t end = size < left ? size : left;
    uint8_t* msg_pointer = (uint8_t*)ctx->message + index;
    for (uint32_t i = 0; i < end; i++) {
      msg_pointer[i] = msg[i];
    }
    if (size < left) return;

    /* process partial block */
    sha3_process_block(ctx->hash, (const uint8_t*)ctx->message, block_size);
    msg += left;
    size -= left;
  }

  while (size >= block_size) {
    sha3_process_block(ctx->hash, msg, block_size);
    msg += block_size;
    size -= block_size;
  }

  if (size) {
    /* save leftovers */
    uint8_t* msg_pointer = (uint8_t*)ctx->message;
    for (uint8_t i = 0; i < size; i++) {
      msg_pointer[i] = msg[i];
    }
  }
}

/**
 * Store calculated hash into the given array.
 */
static void keccak_final(struct SHA3_CTX* ctx, uint8_t output[32]) {
  const uint8_t padding = 0x01;
  const uint32_t block_size = ctx->block_size;

  if (!(ctx->rest & SHA3_FINALIZED)) {
    /* clear the rest of the data queue */
    int8_t* start = (int8_t*)ctx->message + ctx->rest;
    for (int i = 0; i < block_size - ctx->rest; i++) {
      start[i] = 0;
    }
    ((int8_t*)ctx->message)[ctx->rest] |= padding;
    ((int8_t*)ctx->message)[block_size - 1] |= 0x80;

    /* process final block */
    sha3_process_block(ctx->hash, (const uint8_t*)ctx->message, block_size);
    ctx->rest = SHA3_FINALIZED; /* mark context as finalized */
  }

  for (unsigned i = 0; i < 32; i++) {
    output[i] = (uint8_t)(ctx->hash[i / 8] >> ((i % 8) * 8));
  }
}
