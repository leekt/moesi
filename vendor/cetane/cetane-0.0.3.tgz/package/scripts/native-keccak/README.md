# Experimental native Keccak build

`cetane/nativeHashing` is an explicit optional Node/Bun entry for Darwin arm64.
Importing it loads no native addon. Calling `enableNativeHashing()` loads the
packaged binary and checks six known answers before making it active. Package
installation and module import never download or compile code. Ordinary browser
and JavaScript entry graphs remain independent of this leaf.

This build combines the exact pinned hash-wasm 4.12.0/RHash byte absorption code
with XKCP commit `eb5244d6b95fb1c434b211bac293093e18aa8fd1`'s single-state
ARM SHA-3 permutation. Vendored sources and complete upstream licenses are in
`upstream/`; `derivation.patch` and `permutation.patch` explain the changes.
The permutation is available under Apache-2.0 OR ISC OR MIT; this distribution
selects MIT and retains the notices. The byte absorption code retains its
original permissive RHash license, while hash-wasm's package license is MIT.

The Node-API 8 addon uses one stack context per call, immutable round constants,
safe little-endian byte loading, Keccak padding `0x01`, and owned output. It
accepts one or two byte segments; no JavaScript callback occurs while native
input pointers are borrowed. The public adapter validates original and normalized
views and copies shared/resizable storage into owned fixed memory. Direct raw
RAB input is outside the private addon contract. The adapter deliberately rejects
already-out-of-bounds views rather than treating them as empty messages.

The explicit build target is `arm64-apple-macos11`, `-mcpu=apple-m1`. This is a
minimum CPU target, not host-native tuning. Only the two Node-API entry symbols
are exported. The build requires `eor3`, `rax1`, `xar`, and `bcax` to appear in its
saved disassembly and records the actual linked libraries. macOS 11 and M1 are
target settings; the isolated validation ran on macOS 26.7.1 Apple M4 with Node
22.23.1, Node 25.2.1, and Bun 1.4.2. Actual M1 execution remains unverified.

Upstream source, compiler, SDK-settings and Node-header hashes are in `pins.json`.
The derived C and build-driver hashes are recorded in generated provenance inputs.
The sources are vendored, so the maintainer build needs only local tools and
headers. It does not invoke an installer or fetch network resources:

```sh
node scripts/native-keccak/build.mjs --headers /path/to/node-22.23.1/include/node
node scripts/native-keccak/build.mjs --headers /path/to/node-22.23.1/include/node --check
```

Optional `--compiler`, `--sdk`, and `--output` parameters accept explicit local
paths that must satisfy the same pins. Every invocation uses a fresh temporary
work directory with relative inputs and source-path maps. A normal invocation
writes `native/darwin-arm64/keccak.node`, `keccak-provenance.json`, and the three
license files; `--check` leaves them unchanged and requires the rebuilt binary
and normalized provenance to match. Failed attempts retain their manifest and
error. The build does not claim reproducibility across different toolchains.

The reference 51,080-byte binary has SHA256
`4e6291e959e9b68cb91dc361425fd287db16d89cfebb31e3e5599390dab877b4`.
The addon returns an owned canonical hex string, avoiding an intermediate digest
buffer and JavaScript hex conversion. The adapter validates its type, length and
digits before exposing the result.
The [isolated validation](../../bench/runs/20261003-native-hex-output/validation/README.md)
records two identical builds and the complete three-runtime oracle, edge and
worker checks. Package/build provenance records the actual shipped inputs;
performance comparisons must distinguish the optional complete SDK path from
standalone hashing and identify both runtime and workload.

Both native and WASM hashing enablers cache their verified backend and original
successful promise. A warm call selects its backend synchronously without
another native load, WASM compilation or known-answer test. Concurrent cold
initializations install in verification-completion order; a pending cold setup
can therefore replace an intervening warm selection when it completes. Await
all intended setup, then call the desired enabler to choose deterministically.
Failure leaves the currently active backend intact and permits an explicit retry.

Input/output or engine-memory erasure is not guaranteed. Native signing private
keys do not enter the Keccak addon. This optional hash implementation changes
neither the signer/address separation nor signed transaction acknowledgment
integrity checks.
