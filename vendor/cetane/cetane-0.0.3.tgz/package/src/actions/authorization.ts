import { CetaneError } from '../errors.js'
import { scopeContext, traceAsync, traceOperation } from '../internal/trace.js'
import type {
  AuthorizationChange,
  Client,
  TransactionParameters,
} from '../types.js'
import {
  assertPipelineAccount,
  prepareCalls,
  sendResolvedCalls,
} from './send.js'

export type UpdateAuthorizationParameters = TransactionParameters & {
  changes: readonly AuthorizationChange[]
}

/** Owner rotation and grant/revoke share one ordered, atomic transaction. */
async function authorizationRequest(
  client: Client,
  parameters: UpdateAuthorizationParameters,
) {
  const metadata = client.trace
    ? await traceAsync(client.trace, 'ready.wait', () => client.ready)
    : await client.ready
  const nativeAA = client.chain.execution?.nativeAA
  if (nativeAA && metadata.nativeAA !== nativeAA)
    throw new CetaneError(
      'Native AA capability does not match the configured execution module.',
    )
  const account = parameters.account ?? client.account
  if (!account?.encodeAuthorizationChanges)
    throw new CetaneError(
      'This account does not support authorization updates.',
    )
  assertPipelineAccount(client, account)
  if (!parameters.changes.length)
    throw new CetaneError('At least one authorization change is required.')
  const signer = parameters.signer ?? client.signer
  const request = { ...parameters, account, ...(signer ? { signer } : {}) }
  const encoded = client.trace
    ? await traceAsync(
        client.trace,
        'authorization.encode',
        (span) =>
          account.encodeAuthorizationChanges!(
            parameters.changes,
            scopeContext(client, span),
            request,
          ),
        { count: parameters.changes.length },
      )
    : await account.encodeAuthorizationChanges(
        parameters.changes,
        client,
        request,
      )
  return { ...encoded, ...request, calls: encoded.calls }
}

export function prepareAuthorization(
  client: Client,
  parameters: UpdateAuthorizationParameters,
) {
  const prepare = async (scoped: Client) =>
    prepareCalls(scoped, await authorizationRequest(scoped, parameters))
  return client.trace
    ? traceOperation(client, 'prepareAuthorization', prepare)
    : prepare(client)
}

export async function updateAuthorization(
  client: Client,
  parameters: UpdateAuthorizationParameters,
) {
  const snapshot = {
    ...parameters,
    changes: parameters.changes.map((change) => ({ ...change })),
  }
  return sendResolvedCalls(client, snapshot, (scoped) =>
    authorizationRequest(scoped, snapshot),
  )
}
