import { CetaneError } from '../errors.js'
import { traceOperation, traceAsync } from '../internal/trace.js'
import type { Address, BlockTag, Client, Hex } from '../types.js'
import {
  assertAddress,
  assertHex,
  fromQuantity,
  toQuantity,
} from '../utils/hex.js'

export function getChainId(
  client: Client,
  parameters: { refresh?: boolean } = {},
): Promise<number> {
  return client.trace
    ? traceOperation(client, 'getChainId', (scoped) =>
        getChainIdInner(scoped, parameters),
      )
    : getChainIdInner(client, parameters)
}

async function getChainIdInner(
  client: Client,
  parameters: { refresh?: boolean } = {},
): Promise<number> {
  const { chainId } = client.trace
    ? await traceAsync(client.trace, 'ready.wait', () => client.ready)
    : await client.ready
  if (!parameters.refresh) return chainId
  return client.request<Hex>({ method: 'eth_chainId' }).then((value) => {
    const id = Number(fromQuantity(value))
    if (!Number.isSafeInteger(id))
      throw new CetaneError('Chain ID exceeds the safe integer range.')
    if (id !== chainId)
      throw new CetaneError('RPC chain ID does not match the cached chain.')
    return id
  })
}
export function getBlockNumber(client: Client): Promise<bigint> {
  return client.trace
    ? traceOperation(client, 'getBlockNumber', (scoped) =>
        getBlockNumberInner(scoped),
      )
    : getBlockNumberInner(client)
}

function getBlockNumberInner(client: Client): Promise<bigint> {
  return client.request<Hex>({ method: 'eth_blockNumber' }).then(fromQuantity)
}
export function getBalance(
  client: Client,
  parameters: { address: Address; blockTag?: BlockTag; blockNumber?: bigint },
): Promise<bigint> {
  return client.trace
    ? traceOperation(client, 'getBalance', (scoped) =>
        getBalanceInner(scoped, parameters),
      )
    : getBalanceInner(client, parameters)
}

function getBalanceInner(
  client: Client,
  parameters: { address: Address; blockTag?: BlockTag; blockNumber?: bigint },
): Promise<bigint> {
  assertAddress(parameters.address)
  return client
    .request<Hex>({
      method: 'eth_getBalance',
      params: [
        parameters.address,
        parameters.blockNumber === undefined
          ? (parameters.blockTag ?? 'latest')
          : toQuantity(parameters.blockNumber),
      ],
    })
    .then(fromQuantity)
}
export function getCode(
  client: Client,
  parameters: { address: Address; blockTag?: BlockTag; blockNumber?: bigint },
): Promise<Hex> {
  return client.trace
    ? traceOperation(client, 'getCode', (scoped) =>
        getCodeInner(scoped, parameters),
      )
    : getCodeInner(client, parameters)
}

function getCodeInner(
  client: Client,
  parameters: { address: Address; blockTag?: BlockTag; blockNumber?: bigint },
): Promise<Hex> {
  assertAddress(parameters.address)
  return client.request({
    method: 'eth_getCode',
    params: [
      parameters.address,
      parameters.blockNumber === undefined
        ? (parameters.blockTag ?? 'latest')
        : toQuantity(parameters.blockNumber),
    ],
  })
}

/** Read the canonical header fields used for capability and fee observations. */
export function getBlock(
  client: Client,
  parameters: { blockTag?: BlockTag; blockNumber?: bigint } = {},
) {
  return client.trace
    ? traceOperation(client, 'getBlock', (scoped) =>
        getBlockInner(scoped, parameters),
      )
    : getBlockInner(client, parameters)
}

async function getBlockInner(
  client: Client,
  parameters: { blockTag?: BlockTag; blockNumber?: bigint },
) {
  const value = await client.request<Record<string, unknown> | null>({
    method: 'eth_getBlockByNumber',
    params: [
      parameters.blockNumber === undefined
        ? (parameters.blockTag ?? 'latest')
        : toQuantity(parameters.blockNumber),
      false,
    ],
  })
  if (!value || typeof value !== 'object')
    throw new CetaneError('Block is unavailable.')
  return {
    number:
      value.number === null &&
      parameters.blockTag === 'pending' &&
      parameters.blockNumber === undefined
        ? null
        : fromQuantity(value.number),
    ...(value.difficulty === undefined
      ? {}
      : { difficulty: fromQuantity(value.difficulty) }),
    ...(value.baseFeePerGas === undefined
      ? {}
      : {
          baseFeePerGas:
            value.baseFeePerGas === null
              ? null
              : fromQuantity(value.baseFeePerGas),
        }),
  }
}
export function call(
  client: Client,
  parameters: {
    to: Address
    data?: Hex
    account?: Address
    value?: bigint
    blockTag?: BlockTag
    blockNumber?: bigint
    stateOverride?: readonly { readonly address: Address; readonly code: Hex }[]
  },
): Promise<{ data: Hex }> {
  return client.trace
    ? traceOperation(client, 'call', (scoped) => callInner(scoped, parameters))
    : callInner(client, parameters)
}

function callInner(
  client: Client,
  parameters: {
    to: Address
    data?: Hex
    account?: Address
    value?: bigint
    blockTag?: BlockTag
    blockNumber?: bigint
    stateOverride?: readonly { readonly address: Address; readonly code: Hex }[]
  },
): Promise<{ data: Hex }> {
  const { to, data, account, value } = parameters
  assertAddress(to)
  return client
    .request<Hex>({
      method: 'eth_call',
      params: [
        {
          to,
          ...(data !== undefined ? { data } : {}),
          ...(account ? { from: account } : {}),
          ...(value !== undefined ? { value: toQuantity(value) } : {}),
        },
        parameters.blockNumber === undefined
          ? (parameters.blockTag ?? 'latest')
          : toQuantity(parameters.blockNumber),
        ...(parameters.stateOverride === undefined
          ? []
          : [
              Object.fromEntries(
                parameters.stateOverride.map(({ address, code }) => {
                  assertAddress(address)
                  assertHex(code)
                  return [address, { code }]
                }),
              ),
            ]),
      ],
    })
    .then((data) => ({ data }))
}
