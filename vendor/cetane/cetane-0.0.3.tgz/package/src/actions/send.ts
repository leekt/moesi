import { CetaneError } from '../errors.js'
import { identity } from '../client.js'
import type {
  Account,
  Client,
  ExecutionPlan,
  Hash,
  PreparedTransaction,
  SendCallsParameters,
  SendTransactionParameters,
  TransactionParameters,
  Awaitable,
  Signer,
  ChainMetadata,
} from '../types.js'
import { assertAddress, assertHex } from '../utils/hex.js'
import {
  scopeContext,
  traceAsync,
  traceOperation,
  traceSync,
} from '../internal/trace.js'
import type { TraceContext } from '../trace/types.js'
import {
  assertNonceKnown,
  cachedNonce,
  withNonce,
  withNoncePipeline,
  trackSubmission,
  getNonceKey,
} from './nonce.js'
import type { NonceState } from './nonce.js'
import { withParallelNonce } from './parallelNonce.js'

type PlanEntry = {
  client: object
  plan: ExecutionPlan
  account: Account
  key: bigint
  explicit: boolean
  signer?: Signer
  result?: Promise<Hash>
}
const plans = new WeakMap<PreparedTransaction, PlanEntry>()

/** Internal guard shared by state-dependent preparation actions. */
export function assertPipelineAccount(client: Client, account: Account): void {
  if ((client.chain.submission?.maxInFlight ?? 1) <= 1) return
  if (
    account.encodeAuthorizationChanges ||
    account.encodeModuleChanges ||
    account.getDeployment ||
    account.encodeCalls
  )
    throw new CetaneError(
      'Nonce pipelining currently requires a plain EOA account.',
    )
}

type ResolvedCalls = SendCallsParameters & {
  account: Account
  nonceKey: bigint
}

function resolveNonceKey(
  account: Account,
  parameters: TransactionParameters,
): bigint {
  if ((parameters.nonceKey ?? 0n) < 0n)
    throw new CetaneError('Transaction quantities cannot be negative.')
  return getNonceKey(account, parameters)
}

function snapshotCalls(parameters: SendCallsParameters): SendCallsParameters {
  return {
    ...parameters,
    calls: Object.freeze(
      parameters.calls.map((call) => Object.freeze({ ...call })),
    ),
  }
}

function transactionCalls(
  parameters: SendTransactionParameters,
): SendCallsParameters {
  const { to, data, value, ...rest } = parameters
  const request = rest as SendCallsParameters
  request.calls = Object.freeze([
    Object.freeze({
      to,
      ...(data !== undefined ? { data } : {}),
      ...(value !== undefined ? { value } : {}),
    }),
  ])
  return request
}

function resolveRequest(
  parameters: SendCallsParameters,
  account: Account,
  key: bigint,
  nonce: bigint | undefined,
  signer: Signer | undefined,
): ResolvedCalls {
  // Every caller supplies a private snapshot; resolution never mutates caller inputs.
  const request = parameters as ResolvedCalls
  request.account = account
  request.nonceKey = key
  if (nonce !== undefined) request.nonce = nonce
  if (signer) request.signer = signer
  return request
}

/** Common validation/preparation; only explicitly prepared requests enter the public registry. */
function preparePlan(
  client: Client,
  request: ResolvedCalls,
  metadata: ChainMetadata,
): Promise<ExecutionPlan> {
  return client.trace
    ? traceAsync(client.trace, 'prepare', (span) =>
        preparePlanInner(scopeContext(client, span), request, metadata),
      )
    : preparePlanInner(client, request, metadata)
}

function validateRequest(
  client: Client,
  request: ResolvedCalls,
  metadata: ChainMetadata,
): void {
  const execution = client.chain.execution
  if (!execution)
    throw new CetaneError('This chain has no execution module configured.')
  if (execution.nativeAA && metadata.nativeAA !== execution.nativeAA)
    throw new CetaneError(
      `Native AA support is ${metadata.nativeAA}; configure or discover ${execution.nativeAA} support before sending.`,
    )
  if (request.calls.length === 0)
    throw new CetaneError('At least one call is required.')
  for (const call of request.calls) {
    assertAddress(call.to)
    if (call.data !== undefined) assertHex(call.data)
    if ((call.value ?? 0n) < 0n)
      throw new CetaneError('Call value cannot be negative.')
  }
  for (const value of [
    request.nonce,
    request.nonceKey,
    request.gas,
    request.maxFee,
  ])
    if (value !== undefined && value < 0n)
      throw new CetaneError('Transaction quantities cannot be negative.')
  if (
    request.blockMode !== undefined &&
    request.blockMode !== client.chain.blockMode
  )
    throw new CetaneError(
      'Block mode does not match the configured chain and submission endpoint.',
    )
  client.chain.validateCalls?.(request.calls, request)
}

function validatePlan(
  client: Client,
  request: ResolvedCalls,
  plan: ExecutionPlan,
): void {
  const transaction = Object.freeze(plan.transaction)
  const limits = client.chain.limits
  if (limits?.maxGas !== undefined && transaction.gas > limits.maxGas)
    throw new CetaneError('Gas limit exceeds the chain cap.')
  if (request.maxFee !== undefined && transaction.maxFee > request.maxFee)
    throw new CetaneError('Transaction exceeds maxFee.')
  if (limits?.maxFee !== undefined && transaction.maxFee > limits.maxFee)
    throw new CetaneError('Transaction exceeds the chain fee budget.')
  client.chain.validateTransaction?.(transaction, request)
}

async function preparePlanInner(
  client: Client,
  request: ResolvedCalls,
  metadata: ChainMetadata,
): Promise<ExecutionPlan> {
  if (client.trace)
    traceSync(client.trace, 'calls.validate', () =>
      validateRequest(client, request, metadata),
    )
  else validateRequest(client, request, metadata)
  const plan = await client.chain.execution!.prepare(client, request)
  if (client.trace)
    traceSync(client.trace, 'policy.validate', () =>
      validatePlan(client, request, plan),
    )
  else validatePlan(client, request, plan)
  return plan
}

async function prepareSnapshot(
  client: Client,
  parameters: SendCallsParameters,
): Promise<PreparedTransaction> {
  const metadata = client.trace
    ? await traceAsync(client.trace, 'ready.wait', () => client.ready)
    : await client.ready
  const account = parameters.account ?? client.account
  if (!account)
    throw new CetaneError('An account is required to send transactions.')
  assertPipelineAccount(client, account)
  const explicit = parameters.nonce !== undefined
  const key = resolveNonceKey(account, parameters)
  const nonce = parameters.nonce ?? cachedNonce(client, account, key)
  if (client.trace)
    traceSync(client.trace, 'nonce.source', () => {}, {
      source: explicit ? 'provided' : nonce === undefined ? 'rpc' : 'cache',
    })
  const signer = parameters.signer ?? client.signer
  const plan = await preparePlan(
    client,
    resolveRequest(parameters, account, key, nonce, signer),
    metadata,
  )
  const transaction = plan.transaction
  plans.set(transaction, {
    client: identity(client),
    plan,
    account,
    key,
    explicit,
    ...(signer ? { signer } : {}),
  })
  return transaction
}

export async function prepareCalls(
  client: Client,
  parameters: SendCallsParameters,
): Promise<PreparedTransaction> {
  return client.trace
    ? traceOperation(client, 'prepareCalls', (scoped) =>
        prepareSnapshot(scoped, snapshotCalls(parameters)),
      )
    : prepareSnapshot(client, snapshotCalls(parameters))
}

export function prepareTransactionRequest(
  client: Client,
  parameters: SendTransactionParameters,
): Promise<PreparedTransaction> {
  return client.trace
    ? traceOperation(client, 'prepareTransactionRequest', (scoped) =>
        prepareSnapshot(scoped, transactionCalls(parameters)),
      )
    : prepareSnapshot(client, transactionCalls(parameters))
}

/** A prepared request is immutable, client-bound, and submitted at most once. */
export function sendPreparedTransaction(
  client: Client,
  transaction: PreparedTransaction,
  parameters: { signer?: Signer } = {},
): Promise<Hash> {
  const entry = plans.get(transaction)
  if (!entry || entry.client !== identity(client))
    throw new CetaneError(
      'Prepared transaction belongs to a different client or was not prepared here.',
    )
  if (entry.result) return entry.result
  const signer = parameters.signer ?? entry.signer
  if (!signer)
    return Promise.reject(
      new CetaneError('A signer is required to authorize this transaction.'),
    )
  const send = (scoped: Client) =>
    withNonce(scoped, entry.account, entry.key, async (state) => {
      if (!entry.explicit) {
        assertNonceKnown(state)
        if (state.next !== undefined && state.next !== transaction.nonce)
          throw new CetaneError(
            'Prepared nonce is stale. Prepare the transaction again.',
          )
      }
      return broadcast(entry.plan, state, signer, scoped.trace)
    })
  return (entry.result = client.trace
    ? traceOperation(client, 'sendPreparedTransaction', send)
    : send(client))
}

function signPlan(
  plan: ExecutionPlan,
  signer: Signer,
  trace?: TraceContext,
): Promise<void> | undefined {
  if (!plan.sign) return
  if (trace)
    return traceAsync(trace, 'sign', (span) =>
      plan.sign!({ signer, ...(span ? { trace: span } : {}) }),
    )
  return plan.sign({ signer })
}

function submitPlan(plan: ExecutionPlan, trace?: TraceContext): Promise<Hash> {
  return trace
    ? traceAsync(trace, 'submit', (span) =>
        plan.submit(span ? { trace: span } : undefined),
      )
    : plan.submit()
}

async function broadcast(
  plan: ExecutionPlan,
  state: NonceState,
  signer: Signer,
  trace?: TraceContext,
): Promise<Hash> {
  await signPlan(plan, signer, trace)
  try {
    const hash = await submitPlan(plan, trace)
    const next = plan.transaction.nonce + 1n
    if (state.next === undefined || next > state.next) state.next = next
    delete state.uncertain
    return hash
  } catch (error) {
    // A rejected submission may already have reached a node. Never reuse blindly.
    state.uncertain = true
    throw error
  }
}

async function broadcastPipelined(
  plan: ExecutionPlan,
  state: NonceState,
  signer: Signer,
  trace?: TraceContext,
): Promise<{ pending: Promise<Hash> }> {
  await signPlan(plan, signer, trace)
  // Another ACK may have failed while a remote signer or preparation was pending.
  assertNonceKnown(state)
  const next = plan.transaction.nonce + 1n
  if (state.next === undefined || next > state.next) state.next = next
  let pending: Promise<Hash>
  try {
    pending = submitPlan(plan, trace)
  } catch (error) {
    state.uncertain = true
    throw error
  }
  // Success deliberately never clears uncertainty from another reservation.
  trackSubmission(state, pending)
  return { pending }
}

/** Internal action hook: resolve state-dependent calls only after acquiring the send queue. */
export function sendResolvedCalls(
  client: Client,
  parameters: TransactionParameters,
  resolve: (context: Client) => Awaitable<SendCallsParameters>,
): Promise<Hash> {
  return client.trace
    ? traceOperation(client, 'updateAuthorization', (scoped) =>
        sendQueued(scoped, { ...parameters }, resolve),
      )
    : sendQueued(client, { ...parameters }, resolve)
}

function sendQueued(
  client: Client,
  snapshot: TransactionParameters,
  resolve?: (context: Client) => Awaitable<SendCallsParameters>,
): Promise<Hash> {
  const account = snapshot.account ?? client.account
  if (!account)
    throw new CetaneError('An account is required to send transactions.')
  assertPipelineAccount(client, account)
  const signer = snapshot.signer ?? client.signer
  if (!signer)
    throw new CetaneError('A signer is required to authorize this transaction.')
  const key = resolveNonceKey(account, snapshot)
  if (
    (client.chain.submission?.maxSigning ?? 1) > 1 &&
    snapshot.nonce === undefined &&
    !resolve
  ) {
    return withParallelNonce(client, account, key, async (nonce) => {
      const metadata = client.trace
        ? await traceAsync(client.trace, 'ready.wait', () => client.ready)
        : await client.ready
      if (client.trace)
        traceSync(client.trace, 'nonce.source', () => {}, {
          source: nonce === undefined ? 'rpc' : 'cache',
        })
      const plan = await preparePlan(
        client,
        resolveRequest(
          snapshot as SendCallsParameters,
          account,
          key,
          nonce,
          signer,
        ),
        metadata,
      )
      return {
        nonce: plan.transaction.nonce,
        sign: () => signPlan(plan, signer, client.trace),
        submit: () => submitPlan(plan, client.trace),
      }
    })
  }
  if (
    (client.chain.submission?.maxInFlight ?? 1) > 1 &&
    snapshot.nonce === undefined &&
    !resolve
  ) {
    return withNoncePipeline(client, account, key, async (state) => {
      const metadata = client.trace
        ? await traceAsync(client.trace, 'ready.wait', () => client.ready)
        : await client.ready
      assertNonceKnown(state)
      if (client.trace)
        traceSync(client.trace, 'nonce.source', () => {}, {
          source: state.next === undefined ? 'rpc' : 'cache',
        })
      const plan = await preparePlan(
        client,
        resolveRequest(
          snapshot as SendCallsParameters,
          account,
          key,
          state.next,
          signer,
        ),
        metadata,
      )
      return broadcastPipelined(plan, state, signer, client.trace)
    })
  }
  return withNonce(client, account, key, async (state) => {
    if (snapshot.nonce === undefined) assertNonceKnown(state)
    const metadata = client.trace
      ? await traceAsync(client.trace, 'ready.wait', () => client.ready)
      : await client.ready
    const request = resolve
      ? snapshotCalls(
          await (client.trace
            ? traceAsync(client.trace, 'calls.resolve', async (span) =>
                resolve(scopeContext(client, span)),
              )
            : resolve(client)),
        )
      : (snapshot as SendCallsParameters)
    const nonce = snapshot.nonce ?? state.next
    if (client.trace)
      traceSync(client.trace, 'nonce.source', () => {}, {
        source:
          snapshot.nonce !== undefined
            ? 'provided'
            : state.next === undefined
              ? 'rpc'
              : 'cache',
      })
    const plan = await preparePlan(
      client,
      resolveRequest(request, account, key, nonce, signer),
      metadata,
    )
    return broadcast(plan, state, signer, client.trace)
  })
}

export async function sendCalls(
  client: Client,
  parameters: SendCallsParameters,
): Promise<{ id: Hash }> {
  return {
    id: await (client.trace
      ? traceOperation(client, 'sendCalls', (scoped) =>
          sendQueued(scoped, snapshotCalls(parameters)),
        )
      : sendQueued(client, snapshotCalls(parameters))),
  }
}

export function sendTransaction(
  client: Client,
  parameters: SendTransactionParameters,
): Promise<Hash> {
  try {
    return client.trace
      ? traceOperation(client, 'sendTransaction', (scoped) =>
          sendQueued(scoped, transactionCalls(parameters)),
        )
      : sendQueued(client, transactionCalls(parameters))
  } catch (error) {
    return Promise.reject(error)
  }
}

export async function estimateGas(
  client: Client,
  parameters: SendTransactionParameters,
): Promise<bigint> {
  return (await prepareTransactionRequest(client, parameters)).executionGas
}
