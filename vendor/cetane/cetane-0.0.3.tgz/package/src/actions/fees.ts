import { CetaneError } from '../errors.js'
import type { Context, FeeParameters, Fees } from '../types.js'
import { fromQuantity } from '../utils/hex.js'
import { readFeeData } from './feeReads.js'
import { traceOperation } from '../internal/trace.js'

export function estimateFeesPerGas(
  context: Context,
  parameters: FeeParameters = {},
): Promise<Fees> {
  if (context.trace)
    return traceOperation(
      context,
      'fees',
      (scoped) => estimateFees(scoped, parameters),
      {
        source:
          parameters.maxFeePerGas !== undefined &&
          parameters.maxPriorityFeePerGas !== undefined
            ? 'provided'
            : context.chain.fees?.estimate
              ? 'policy'
              : 'rpc',
      },
    )
  return estimateFees(context, parameters)
}

async function estimateFees(
  context: Context,
  parameters: FeeParameters,
): Promise<Fees> {
  const policy = context.chain.fees
  let fees: Fees
  if (
    parameters.maxFeePerGas !== undefined &&
    parameters.maxPriorityFeePerGas !== undefined
  ) {
    fees = {
      maxFeePerGas: parameters.maxFeePerGas,
      maxPriorityFeePerGas: parameters.maxPriorityFeePerGas,
    }
  } else if (policy?.estimate) {
    fees = await policy.estimate(context, parameters)
  } else {
    const multiplier = policy?.baseFeeMultiplier ?? 20_000
    if (!Number.isSafeInteger(multiplier) || multiplier < 10_000)
      throw new CetaneError('Invalid base fee multiplier.')
    const [block, tip] = await Promise.all([
      parameters.maxFeePerGas === undefined
        ? readFeeData<{ baseFeePerGas?: string }>(
            context,
            'eth_getBlockByNumber',
          )
        : undefined,
      parameters.maxPriorityFeePerGas ??
        readFeeData<string>(context, 'eth_maxPriorityFeePerGas').then(
          fromQuantity,
        ),
    ])
    const floor = policy?.minPriorityFeePerGas ?? 0n
    const maxPriorityFeePerGas =
      parameters.maxPriorityFeePerGas ?? (tip < floor ? floor : tip)
    if (
      parameters.maxFeePerGas === undefined &&
      block?.baseFeePerGas === undefined
    )
      throw new CetaneError(
        'A fee estimator is required for chains without baseFeePerGas.',
      )
    fees = {
      maxPriorityFeePerGas,
      maxFeePerGas:
        parameters.maxFeePerGas ??
        (fromQuantity(block!.baseFeePerGas) * BigInt(multiplier) + 9_999n) /
          10_000n +
          maxPriorityFeePerGas,
    }
  }
  return validateFees(context, fees)
}

/** Shared synchronous validation for explicit fees and asynchronous estimates. */
export function validateFees(context: Context, fees: Fees): Fees {
  const policy = context.chain.fees
  if (fees.maxPriorityFeePerGas < (policy?.minPriorityFeePerGas ?? 0n))
    throw new CetaneError('Priority fee is below the chain minimum.')
  if (fees.maxFeePerGas < fees.maxPriorityFeePerGas || fees.maxFeePerGas < 0n)
    throw new CetaneError('maxFeePerGas must cover maxPriorityFeePerGas.')
  if (
    policy?.maxFeePerGas !== undefined &&
    fees.maxFeePerGas > policy.maxFeePerGas
  )
    throw new CetaneError('Fee per gas exceeds the chain policy cap.')
  if (
    policy?.maxPriorityFeePerGas !== undefined &&
    fees.maxPriorityFeePerGas > policy.maxPriorityFeePerGas
  )
    throw new CetaneError('Priority fee exceeds the chain policy cap.')
  return fees
}
