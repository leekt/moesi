import { CetaneError } from '../errors.js'
import { traceOperation, traceSync } from '../internal/trace.js'
import type { Client, ModuleChange, TransactionParameters } from '../types.js'
import { assertPipelineAccount, prepareCalls, sendCalls } from './send.js'
import type { Account } from '../types.js'
import type { ReadModulesOptions } from '../accounts/kernelRead.js'
import { readKernelModules } from '../accounts/kernelRead.js'

export function readModules(
  client: Client,
  parameters: ReadModulesOptions & { account?: Account } = {},
) {
  const account = parameters.account ?? client.account
  if (account?.moduleDiscovery?.type !== 'kernel')
    throw new CetaneError(
      'This account does not support module discovery; use a Kernel 4 adapter.',
    )
  const read = (scoped: Client) =>
    readKernelModules(scoped, {
      ...parameters,
      address: account.address,
      version: account.moduleDiscovery!.version,
    })
  return client.trace
    ? traceOperation(client, 'readModules', read)
    : read(client)
}

export type UpdateModulesParameters = TransactionParameters & {
  changes: readonly ModuleChange[]
}
function moduleRequest(client: Client, parameters: UpdateModulesParameters) {
  const account = parameters.account ?? client.account
  if (!account?.encodeModuleChanges)
    throw new CetaneError('This account does not support module changes.')
  assertPipelineAccount(client, account)
  if (!parameters.changes.length)
    throw new CetaneError('At least one module change is required.')
  const encoded = client.trace
    ? traceSync(
        client.trace,
        'modules.encode',
        () => account.encodeModuleChanges!(parameters.changes),
        { count: parameters.changes.length },
      )
    : account.encodeModuleChanges(parameters.changes)
  return { ...encoded, ...parameters, account, calls: encoded.calls }
}
export function prepareModuleUpdate(
  client: Client,
  parameters: UpdateModulesParameters,
) {
  return client.trace
    ? traceOperation(client, 'prepareModuleUpdate', (scoped) =>
        prepareCalls(scoped, moduleRequest(scoped, parameters)),
      )
    : prepareCalls(client, moduleRequest(client, parameters))
}
export function updateModules(
  client: Client,
  parameters: UpdateModulesParameters,
) {
  const send = async (scoped: Client) =>
    (await sendCalls(scoped, moduleRequest(scoped, parameters))).id
  return client.trace
    ? traceOperation(client, 'updateModules', send)
    : send(client)
}
