import { CetaneError, TimeoutError } from '../errors.js'
import {
  preserveIdentity,
  preserveRequestIdentity,
} from '../internal/identity.js'
import {
  beginSpan,
  scopeContext,
  traceAsync,
  traceOperation,
} from '../internal/trace.js'
import type { Client, Hash, TransactionReceipt } from '../types.js'
import { assertHex, fromQuantity, toQuantity } from '../utils/hex.js'
import { formatReceipt } from '../execution/receipt.js'
import type { RpcReceipt } from '../execution/receipt.js'

export function getTransactionReceipt(
  client: Client,
  parameters: { hash: Hash },
): Promise<TransactionReceipt | null> {
  return client.trace
    ? traceOperation(client, 'getTransactionReceipt', (scoped) =>
        getReceipt(scoped, parameters),
      )
    : getReceipt(client, parameters)
}

async function getReceipt(
  client: Client,
  { hash }: { hash: Hash },
): Promise<TransactionReceipt | null> {
  assertHex(hash, 32)
  return client.trace
    ? traceAsync(
        client.trace,
        'receipt.read',
        (trace) => readReceipt(scopeContext(client, trace), hash),
        { source: 'immediate' },
      )
    : readReceipt(client, hash)
}

async function readReceipt(
  client: Client,
  hash: Hash,
): Promise<TransactionReceipt | null> {
  if (client.chain.execution)
    return client.chain.execution.getReceipt(client, hash)
  const receipt = await client.request<RpcReceipt | null>({
    method: 'eth_getTransactionReceipt',
    params: [hash],
  })
  return receipt ? formatReceipt(receipt, hash) : null
}

type WaitParameters = {
  hash: Hash
  confirmations?: number
  timeout?: number
  pollingInterval?: number
  signal?: AbortSignal
  /** Subscribe to hints that a receipt may have changed. Return an unsubscribe function. */
  subscribe?: (notify: () => void) => () => void
}

export function waitForTransactionReceipt(
  client: Client,
  parameters: WaitParameters,
): Promise<TransactionReceipt> {
  return client.trace
    ? traceOperation(client, 'waitForTransactionReceipt', (scoped) =>
        waitForReceipt(scoped, parameters),
      )
    : waitForReceipt(client, parameters)
}

async function waitForReceipt(
  client: Client,
  parameters: WaitParameters,
): Promise<TransactionReceipt> {
  const { hash, signal } = parameters
  assertHex(hash, 32)
  const confirmations = parameters.confirmations ?? 1
  const timeout = parameters.timeout ?? 120_000
  const interval = parameters.pollingInterval ?? client.pollingInterval
  if (
    !Number.isSafeInteger(confirmations) ||
    confirmations < 1 ||
    !Number.isFinite(timeout) ||
    timeout <= 0 ||
    !Number.isFinite(interval) ||
    interval <= 0 ||
    (parameters.subscribe !== undefined &&
      typeof parameters.subscribe !== 'function')
  )
    throw new CetaneError('Invalid receipt wait options.')
  signal?.throwIfAborted()
  const controller = new AbortController()
  const deadline = Date.now() + timeout
  const abort = () => controller.abort(signal?.reason)
  signal?.addEventListener('abort', abort, { once: true })
  const timer = setTimeout(
    () =>
      controller.abort(
        new TimeoutError('Timed out waiting for transaction receipt.'),
      ),
    timeout,
  )
  // Put cancellation inside each stage's RPC wrapper, without retaining an
  // earlier operation's instrumentation beneath it. Other wrappers stay intact.
  const requestContext = client.trace ? scopeContext(client, undefined) : client
  const scoped: Client = {
    ...client,
    request: (request, options) => {
      controller.signal.throwIfAborted()
      return requestContext.request(request, {
        ...options,
        signal: controller.signal,
      })
    },
    relay: (request, options) => {
      controller.signal.throwIfAborted()
      return requestContext.relay(request, {
        ...options,
        signal: controller.signal,
      })
    },
  }
  preserveIdentity(client, scoped)
  preserveRequestIdentity(client.request, scoped.request)
  preserveRequestIdentity(client.relay, scoped.relay)
  // Only one stage is awaited at a time. Keep one current rejection callback
  // instead of attaching every poll to a never-settled cancellation Promise.
  let rejectStage: ((reason: unknown) => void) | undefined
  let notified = false
  let acceptingNotifications = true
  let wakeSleep: (() => void) | undefined
  let unsubscribe: (() => void) | undefined
  const onAbort = () => rejectStage?.(controller.signal.reason)
  controller.signal.addEventListener('abort', onAbort, { once: true })
  function runStage<T>(work: () => Promise<T>): Promise<T> {
    controller.signal.throwIfAborted()
    return new Promise<T>((resolve, reject) => {
      rejectStage = reject
      Promise.resolve(work()).then(resolve, reject)
    }).finally(() => {
      rejectStage = undefined
    })
  }
  try {
    if (parameters.subscribe) {
      const stop = parameters.subscribe(() => {
        if (!acceptingNotifications) return
        notified = true
        wakeSleep?.()
      })
      if (typeof stop !== 'function')
        throw new CetaneError(
          'Receipt subscription must return an unsubscribe function.',
        )
      unsubscribe = stop
    }
    for (;;) {
      controller.signal.throwIfAborted()
      notified = false
      const started = Date.now()
      const heldRead = client.chain.execution?.waitForReceipt
      const receipt = client.trace
        ? await traceAsync(
            client.trace,
            'receipt.read',
            (trace) => {
              const reader = scopeContext(scoped, trace)
              return runStage(() =>
                heldRead
                  ? heldRead.call(client.chain.execution, reader, hash, {
                      timeout: Math.max(1, deadline - started),
                    })
                  : readReceipt(reader, hash),
              )
            },
            { source: heldRead ? 'held' : 'poll' },
          )
        : await runStage(() =>
            heldRead
              ? heldRead.call(client.chain.execution, scoped, hash, {
                  timeout: Math.max(1, deadline - started),
                })
              : readReceipt(scoped, hash),
          )
      if (receipt && !/^0x0{64}$/i.test(receipt.blockHash)) {
        const height =
          confirmations === 1
            ? receipt.blockNumber
            : fromQuantity(
                await (client.trace
                  ? traceAsync(client.trace, 'receipt.confirmation', (trace) =>
                      runStage(() =>
                        scopeContext(scoped, trace).request({
                          method: 'eth_blockNumber',
                        }),
                      ),
                    )
                  : runStage(() =>
                      scoped.request({ method: 'eth_blockNumber' }),
                    )),
              )
        if (height >= receipt.blockNumber + BigInt(confirmations - 1)) {
          const block = client.trace
            ? await traceAsync(client.trace, 'receipt.canonical', (trace) =>
                runStage(() =>
                  scopeContext(scoped, trace).request<{ hash: Hash } | null>({
                    method: 'eth_getBlockByNumber',
                    params: [toQuantity(receipt.blockNumber), false],
                  }),
                ),
              )
            : await runStage(() =>
                scoped.request<{ hash: Hash } | null>({
                  method: 'eth_getBlockByNumber',
                  params: [toQuantity(receipt.blockNumber), false],
                }),
              )
          if (block?.hash.toLowerCase() === receipt.blockHash.toLowerCase())
            return receipt
        }
      }
      if (notified) continue
      let sleepTimer: ReturnType<typeof setTimeout> | undefined
      const sleepSpan = client.trace
        ? beginSpan(client.trace, 'receipt.sleep')
        : undefined
      try {
        await runStage(
          () =>
            new Promise<void>((resolve) => {
              wakeSleep = resolve
              if (notified) {
                resolve()
                return
              }
              sleepTimer = setTimeout(
                resolve,
                heldRead
                  ? Math.max(0, interval - (Date.now() - started))
                  : interval,
              )
            }),
        )
        sleepSpan?.end()
      } catch (error) {
        sleepSpan?.end('error')
        throw error
      } finally {
        wakeSleep = undefined
        clearTimeout(sleepTimer)
      }
    }
  } finally {
    acceptingNotifications = false
    wakeSleep = undefined
    rejectStage = undefined
    clearTimeout(timer)
    signal?.removeEventListener('abort', abort)
    controller.signal.removeEventListener('abort', onAbort)
    unsubscribe?.()
  }
}
