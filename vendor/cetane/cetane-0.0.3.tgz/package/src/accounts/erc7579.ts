import { CetaneError } from '../errors.js'
import type { Address, Call, Hex, Module, ModuleChange } from '../types.js'
import { encodeAbiParameters } from '../utils/abi.js'
import { assertAddress, assertHex, word } from '../utils/hex.js'

/** Init data must already use the target account implementation's module wrapper. */
export function defineModule(module: Module): Module {
  assertAddress(module.address)
  assertHex(module.initData)
  if (module.deInitData !== undefined) assertHex(module.deInitData)
  word(module.type)
  if (module.type === 0n) throw new CetaneError('Module type must be positive.')
  for (const value of Object.values(module.gas ?? {}))
    if (value !== undefined) word(value)
  return Object.freeze({
    ...module,
    ...(module.gas ? { gas: Object.freeze({ ...module.gas }) } : {}),
  })
}

export function encodeModuleChanges(
  address: Address,
  changes: readonly ModuleChange[],
  overhead?: bigint,
): { calls: readonly Call[]; gas?: bigint } {
  let gas = overhead
  const calls: Call[] = changes.map((change) => {
    const module = defineModule(change.module)
    const enabling = change.type === 'enable'
    const budget = enabling ? module.gas?.enable : module.gas?.disable
    gas = gas !== undefined && budget !== undefined ? gas + budget : undefined
    const args = encodeAbiParameters(
      [{ type: 'uint256' }, { type: 'address' }, { type: 'bytes' }],
      [
        module.type,
        module.address,
        enabling ? module.initData : (module.deInitData ?? '0x'),
      ],
    )
    return {
      to: address,
      data: `${enabling ? '0x9517e29f' : '0xa71763a8'}${args.slice(2)}` as Hex,
    }
  })
  return { calls, ...(gas !== undefined ? { gas } : {}) }
}
