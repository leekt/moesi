import { CetaneError } from '../errors.js'
import type { Account, Address, Client } from '../types.js'
import { assertAddress } from '../utils/hex.js'

export async function createAccount(parameters: {
  client: Client
  owner?: Address
  address?: Address
  index?: bigint
}): Promise<Account> {
  await parameters.client.ready
  const factory = parameters.client.chain.account
  if (!factory)
    throw new CetaneError('This chain has no account factory configured.')
  if (parameters.owner) assertAddress(parameters.owner)
  if (parameters.address) assertAddress(parameters.address)
  const account = await factory(parameters)
  assertAddress(account.address)
  return account
}
