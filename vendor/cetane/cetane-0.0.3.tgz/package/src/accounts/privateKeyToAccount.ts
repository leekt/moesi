import type { Hex } from '../types.js'
import { bytesToHex, hexToBytes } from '../utils/bytes.js'
import { keccak256, hashMessage } from '../utils/hash.js'
import { assertHex } from '../utils/hex.js'
import { getPublicKey, signDigest } from './internal/signing.js'

export function privateKeyToAccount(privateKey: Hex): {
  readonly address: Hex
  sign(parameters: { hash: Hex }): Hex
  signMessage(parameters: { message: string | { raw: Hex | Uint8Array } }): Hex
} {
  assertHex(privateKey, 32)
  const key = hexToBytes(privateKey)
  const publicKey = getPublicKey(key, false)
  const address: Hex = `0x${keccak256(publicKey.subarray(1)).slice(-40)}`
  function sign({ hash }: { hash: Hex }): Hex {
    assertHex(hash, 32)
    const signature = signDigest(hexToBytes(hash), key, {
      prehash: false,
      format: 'recovered',
    })
    return `${bytesToHex(signature.subarray(1))}${(27 + signature[0]!).toString(16)}` as Hex
  }
  return {
    address,
    sign,
    signMessage: ({ message }) => sign({ hash: hashMessage(message) }),
  }
}
/** A key supplies signing capability, not a smart account identity. */
export const privateKeyToSigner = privateKeyToAccount
