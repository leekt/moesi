import { CetaneError } from '../../../errors.js'
import type { Hex } from '../../../types.js'
import { bytesToHex, hexToBytes } from '../../../utils/bytes.js'
import { hashMessage, keccak256 } from '../../../utils/hash.js'
import { assertHex } from '../../../utils/hex.js'
import { randomize } from './loader.js'
import type { NativeAddon, NativeSigner } from './types.js'

export function createNativeSigner(load: () => Promise<NativeAddon>) {
  return async function privateKeyToSigner(privateKey: Hex): Promise<{
    readonly address: Hex
    sign(parameters: { hash: Hex }): Hex
    signMessage(parameters: {
      message: string | { raw: Hex | Uint8Array }
    }): Hex
  }> {
    assertHex(privateKey, 32)
    const key = hexToBytes(privateKey)
    const seed = new Uint8Array(32)
    let native: NativeSigner | undefined
    try {
      randomize(seed)
      native = (await load()).createSigner(key, seed)
      const publicKey = native.publicKey()
      if (
        !(publicKey instanceof Uint8Array) ||
        publicKey.length !== 65 ||
        publicKey[0] !== 4
      )
        throw new CetaneError('Invalid native public key.')
      const address: Hex = `0x${keccak256(publicKey.subarray(1)).slice(-40)}`
      const handle = native
      function sign({ hash }: { hash: Hex }): Hex {
        assertHex(hash, 32)
        const message = hexToBytes(hash)
        let signature: Uint8Array | undefined
        try {
          signature = handle.sign(message)
          if (
            !(signature instanceof Uint8Array) ||
            signature.length !== 65 ||
            (signature[64] !== 27 && signature[64] !== 28)
          )
            throw new CetaneError('Invalid native recoverable signature.')
          return bytesToHex(signature)
        } finally {
          message.fill(0)
          if (signature instanceof Uint8Array) signature.fill(0)
        }
      }
      return {
        address,
        sign,
        signMessage: ({ message }) => sign({ hash: hashMessage(message) }),
      }
    } catch (error) {
      try {
        native?.dispose()
      } catch {
        // Preserve the factory failure while still wiping its temporary inputs.
      }
      throw error
    } finally {
      key.fill(0)
      seed.fill(0)
    }
  }
}
