import type { NativeAddon } from './types.js'

/** Loaded only after the public factory checks the supported native platform. */
export async function loadAddon(): Promise<NativeAddon> {
  const moduleName = 'node:module'
  const { createRequire } = (await import(moduleName)) as {
    createRequire(url: URL): (specifier: string) => NativeAddon
  }
  const require = createRequire(
    new URL('../../../../native/darwin-arm64/package.json', import.meta.url),
  )
  return require('./signer.node')
}
