import { CetaneError } from '../../../errors.js'
import type { Hex } from '../../../types.js'
import { bytesToHex, hexToBytes } from '../../../utils/bytes.js'
import { hashMessage, keccak256 } from '../../../utils/hash.js'
import { assertHex } from '../../../utils/hex.js'
import type { Secp256k1State } from './secp256k1.js'

/** The binary choice is fixed before any key is supplied, outside signing. */
export function createWasmSigner(loadSecp256k1: () => Promise<Secp256k1State>) {
  return async function privateKeyToSigner(privateKey: Hex): Promise<{
    readonly address: Hex
    sign(parameters: { hash: Hex }): Hex
    signMessage(parameters: {
      message: string | { raw: Hex | Uint8Array }
    }): Hex
  }> {
    assertHex(privateKey, 32)
    const key = hexToBytes(privateKey)
    try {
      const { exports, io } = await loadSecp256k1()
      let publicKey: Uint8Array
      try {
        io.set(key)
        if (exports.public_key() !== 1)
          throw new CetaneError('Invalid private key.')
        publicKey = io.slice(64, 129)
      } finally {
        exports.wipe()
      }
      const address: Hex = `0x${keccak256(publicKey.subarray(1)).slice(-40)}`
      function sign({ hash }: { hash: Hex }): Hex {
        assertHex(hash, 32)
        // Resolve all caller input before entering the shared synchronous scratch.
        const message = hexToBytes(hash)
        try {
          io.set(key)
          io.set(message, 32)
          if (exports.sign() !== 1)
            throw new CetaneError('WASM secp256k1 signing failed.')
          const recovery = io[128]
          if (recovery !== 27 && recovery !== 28)
            throw new CetaneError(
              'WASM signer returned unsupported recovery parity.',
            )
          return bytesToHex(io.subarray(64, 129))
        } finally {
          exports.wipe()
        }
      }
      return {
        address,
        sign,
        signMessage: ({ message }) => sign({ hash: hashMessage(message) }),
      }
    } catch (error) {
      // Failed factories do not retain a decoded private key.
      key.fill(0)
      throw error
    }
  }
}
