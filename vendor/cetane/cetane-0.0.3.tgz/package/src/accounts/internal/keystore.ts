import { CetaneError } from '../../errors.js'
import type { Account, Address, Authorization, Hex } from '../../types.js'
import {
  formatAuthorization,
  k1,
  stubSignature,
} from '../../execution/internal/keystore.js'
import type {
  AccountChange,
  InitialActor,
} from '../../execution/internal/keystore.js'

export type Actor = InitialActor & { expiry: number; stubSignature: Hex }
type AccountData = {
  keystore: Address
  root?: Authorization
  creation?: Extract<AccountChange, { type: 'create' }>
  valueCalls: boolean
}
export const actors = new WeakMap<Authorization, Actor>()
export const accounts = new WeakMap<Account, AccountData>()

export function getActor(authorization: Authorization): Actor {
  const value = actors.get(authorization)
  if (!value)
    throw new CetaneError(
      'Authorization was not created by the Keystore adapter.',
    )
  return value
}

export function getAccountData(account: Account): AccountData {
  const value = accounts.get(account)
  if (!value)
    throw new CetaneError('This execution module requires a Keystore account.')
  return value
}

export function getAuthenticator(
  account: Account,
  authorization?: Authorization,
): { address: Address; actorId?: Hex; stub: Hex } {
  const selected = authorization ?? getAccountData(account).root
  const value = selected ? getActor(selected) : undefined
  return {
    address: value?.authenticator ?? k1,
    ...(value ? { actorId: value.actorId } : {}),
    stub: formatAuthorization(
      value?.authenticator ?? k1,
      value?.stubSignature ?? stubSignature,
    ),
  }
}
