import type { Address, Context, Hex, Request } from '../../types.js'
import { assertHex } from '../../utils/hex.js'
import { requestIdentity } from '../../internal/identity.js'
import { traceAsync, traceRequestFunction } from '../../internal/trace.js'

const pending = new WeakMap<Request, Map<string, Promise<Hex>>>()

/** Share only outstanding probes; every later preparation sees current code. */
export function readDeploymentCode(
  context: Pick<Context, 'request' | 'trace'>,
  address: Address,
  block: 'latest' | 'pending',
): Promise<Hex> {
  const identity = requestIdentity(context.request)
  let reads = pending.get(identity)
  if (!reads) {
    reads = new Map()
    pending.set(identity, reads)
  }
  const key = `${address.toLowerCase()}:${block}`
  const existing = reads.get(key)
  if (existing)
    return context.trace
      ? traceAsync(context.trace, 'deployment.read', () => existing, {
          source: 'shared',
        })
      : existing
  const current = reads
  const result = (
    context.trace
      ? traceAsync(
          context.trace,
          'deployment.read',
          (span) =>
            traceRequestFunction(
              context.request,
              span,
              'rpc',
            )<Hex>({ method: 'eth_getCode', params: [address, block] }),
          { source: 'rpc' },
        )
      : context.request<Hex>({
          method: 'eth_getCode',
          params: [address, block],
        })
  ).then(
    (code) => {
      current.delete(key)
      assertHex(code)
      return code
    },
    (error) => {
      current.delete(key)
      throw error
    },
  )
  current.set(key, result)
  return result
}
