import { ecdsa, weierstrass } from '@noble/curves/abstract/weierstrass.js'
import { secp256k1 } from '@noble/curves/secp256k1.js'
import type { sha256 } from '@noble/hashes/sha2.js'
import { CetaneError } from '../../errors.js'
import { bytesToHex } from '../../utils/bytes.js'

type Hasher = {
  update(message: Uint8Array): Hasher
  digest(): Uint8Array
}
type Hmac = (key: Uint8Array, message: Uint8Array) => Uint8Array

function nodeHmac(): Hmac | undefined {
  try {
    const runtime = globalThis as typeof globalThis & {
      process?: {
        getBuiltinModule?: (id: 'node:crypto') =>
          | {
              createHmac?: (algorithm: 'sha256', key: Uint8Array) => Hasher
            }
          | undefined
      }
    }
    const createHmac =
      runtime.process?.getBuiltinModule?.('node:crypto')?.createHmac
    if (typeof createHmac !== 'function') return undefined
    return (key, message) => {
      const digest = createHmac('sha256', key).update(message).digest()
      if (digest.length !== 32)
        throw new CetaneError('Invalid HMAC-SHA256 digest.')
      return digest
    }
  } catch {
    // Browser shims and older/restricted Node runtimes use Noble's HMAC.
    return undefined
  }
}

function selectHmac(): Hmac | undefined {
  const CryptoHasher = (
    globalThis as typeof globalThis & {
      Bun?: {
        CryptoHasher?: new (algorithm: 'sha256', key: Uint8Array) => Hasher
      }
    }
  ).Bun?.CryptoHasher
  const hmac =
    typeof CryptoHasher !== 'function'
      ? nodeHmac()
      : (key: Uint8Array, message: Uint8Array): Uint8Array => {
          // A new HMAC instance is finalized on every invocation; no key or state
          // is cached between RFC-6979 steps or between signatures.
          const digest = new CryptoHasher('sha256', key)
            .update(message)
            .digest()
          if (digest.length !== 32)
            throw new CetaneError('Invalid HMAC-SHA256 digest.')
          return digest
        }
  if (!hmac) return undefined
  try {
    // RFC 4231 test case 1 proves the optional runtime API actually uses its
    // key. An unavailable/unsupported backend falls back before any signing.
    const probe = hmac(
      new Uint8Array(20).fill(0x0b),
      new TextEncoder().encode('Hi There'),
    )
    if (
      bytesToHex(probe) !==
      '0xb0344c61d8db38535ca8afceaf0bf12b881dc200c9833da726e9376c2e32cff7'
    )
      return undefined
  } catch {
    return undefined
  }
  return hmac
}

function createSigningCurve() {
  // A private generator table serves every signer and public-key derivation.
  // Noble's default W=8 is retained. Omitting endomorphism avoids its overhead
  // for repeated generator multiplication without changing shared Noble state.
  const Point = weierstrass(secp256k1.Point.CURVE(), {
    Fp: secp256k1.Point.Fp,
    Fn: secp256k1.Point.Fn,
  })
  const hmac = selectHmac()
  // Pinned Noble 2.0.1 returns its hash, but omits it from the ECDSA declaration.
  // Reuse that exact SHA-256 implementation instead of bundling another version.
  const hash = (secp256k1 as typeof secp256k1 & { hash: typeof sha256 }).hash
  // Noble owns nonce generation, curve multiplication, scalar validation,
  // recovery and low-S normalization. Signing errors propagate in either backend.
  return ecdsa(Point, hash, hmac ? { hmac, lowS: true } : { lowS: true })
}

const curve = /* @__PURE__ */ createSigningCurve()
export const signDigest = curve.sign
export const getPublicKey = curve.getPublicKey
