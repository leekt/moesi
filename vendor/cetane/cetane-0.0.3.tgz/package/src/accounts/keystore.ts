import { CetaneError } from '../errors.js'
import type {
  Account,
  AccountFactory,
  Address,
  Authorization,
  Call,
  Hex,
} from '../types.js'
import { encodeAbiParameters, decodeAbiParameters } from '../utils/abi.js'
import { addressWord, assertAddress, assertHex, word } from '../utils/hex.js'
import {
  changesHash,
  creationAddress,
  formatAuthorization,
  k1,
  stubSignature,
  validateActor,
} from '../execution/internal/keystore.js'
import type { ConfigChange } from '../execution/internal/keystore.js'
import {
  actors,
  accounts,
  getActor as actor,
  getAuthenticator,
} from './internal/keystore.js'
import type { Actor } from './internal/keystore.js'

export const draftReference = Object.freeze({
  status: 'DRAFT',
  specification: '16390e1faee756757021e785f4e6ef35a7e6a0f5',
  contracts: '812317be00d6829e217e0cc92f75be362fde0711',
  baseClient: 'd1cd95c42902d356dc95a15b79902bb26a4673e6',
} as const)
const bytes = { type: 'bytes' } as const
const actorConfig = {
  type: 'tuple',
  components: [
    { name: 'authenticator', type: 'address' },
    { name: 'expiry', type: 'uint48' },
    { name: 'scope', type: 'uint16' },
  ],
} as const
const changeArgs = {
  type: 'tuple[]',
  components: [
    { name: 'changeType', type: 'uint8' },
    { name: 'payload', type: 'bytes' },
  ],
} as const
const batch = {
  type: 'tuple',
  components: [
    { name: 'channel', type: 'uint8' },
    { name: 'sequence', type: 'uint64' },
    { name: 'changes', ...changeArgs },
    { name: 'signature', type: 'bytes' },
  ],
} as const
const executionArgs = [
  {
    type: 'tuple[]',
    components: [
      { name: 'target', type: 'address' },
      { name: 'value', type: 'uint256' },
      { name: 'data', type: 'bytes' },
    ],
  },
] as const
const selectors = {
  sequences: '0x82e5f7c6', // getChangeSequences(address)
  apply: '0x20c4a62c', // applySignedAccountChanges(address,(uint8,uint64,(uint8,bytes)[],bytes))
  execute: '0x34fcd5be', // executeBatch((address,uint256,bytes)[])
} as const

/** Public identity and authority only. Signers remain separate from these descriptors. */
export function createAuthorization(
  parameters: (
    | { owner: Address; actorId?: never }
    | { actorId: Hex; owner?: never }
  ) & {
    authenticator?: Address
    role: 'owner' | 'delegate'
    scope?: number
    expiry?: number
    policy?: { manager: Address; commitment: Hex }
    stubSignature?: Hex
  },
): Authorization {
  const authenticator = parameters.authenticator ?? k1
  if (parameters.owner) assertAddress(parameters.owner)
  const actorId = parameters.actorId ?? `0x${addressWord(parameters.owner!)}`
  const scope = parameters.scope ?? (parameters.role === 'owner' ? 0 : 0x13)
  if ((parameters.role === 'owner') !== (scope === 0))
    throw new CetaneError(
      'Owners require scope 0; delegates require an explicit nonzero scope.',
    )
  if ((scope & 0x09) === 0x09)
    throw new CetaneError(
      'An operator scope overrides the policy gate; choose one initiation mode.',
    )
  const expiry = parameters.expiry ?? 0
  if (!Number.isSafeInteger(expiry) || expiry < 0)
    throw new CetaneError('Invalid actor expiry.')
  word(BigInt(expiry), 6)
  let policyData: Hex = '0x'
  if (parameters.policy) {
    assertAddress(parameters.policy.manager)
    assertHex(parameters.policy.commitment, 32)
    policyData = `${parameters.policy.manager}${parameters.policy.commitment.slice(2)}`
  }
  if ((scope & 0x08) !== 0 && !parameters.policy)
    throw new CetaneError(
      'A policy-gated actor requires a manager and commitment.',
    )
  const stub =
    parameters.stubSignature ??
    (authenticator.toLowerCase() === k1 ? stubSignature : undefined)
  if (!stub)
    throw new CetaneError(
      'A custom authenticator requires an estimation signature.',
    )
  assertHex(stub)
  const actor: Actor = {
    actorId,
    authenticator,
    scope,
    policyData,
    expiry,
    stubSignature: stub,
  }
  validateActor(actor)
  const authorization = Object.freeze({ id: actorId })
  actors.set(authorization, Object.freeze(actor))
  return authorization
}

/** Existing account, or counterfactual creation from explicit runtime bytecode and public actors. */
export function defineAccount(options: {
  keystore: Address
  root?: Authorization
  creation?: { bytecode: Hex; actors: readonly Authorization[] }
  valueCalls?: boolean
}): AccountFactory {
  options = { ...options }
  assertAddress(options.keystore)
  if (BigInt(options.keystore) === 0n)
    throw new CetaneError('Keystore must be nonzero.')
  if (options.root) actor(options.root)
  const creation = options.creation
    ? {
        bytecode: options.creation.bytecode,
        actors: options.creation.actors
          .map((value) => {
            const item = actor(value)
            if (item.expiry !== 0)
              throw new CetaneError(
                'Initial actors cannot expire; set expiry after creation.',
              )
            return item
          })
          .sort((a, b) => (BigInt(a.actorId) < BigInt(b.actorId) ? -1 : 1)),
      }
    : undefined
  return ({ address, index = 0n }) => {
    word(index)
    const entry = creation
      ? Object.freeze({
          type: 'create' as const,
          salt: `0x${word(index)}` as Hex,
          bytecode: creation.bytecode,
          actors: Object.freeze(
            creation.actors.map((item) =>
              Object.freeze({
                actorId: item.actorId,
                authenticator: item.authenticator,
                scope: item.scope,
                policyData: item.policyData,
              }),
            ),
          ),
        })
      : undefined
    const predicted = entry
      ? creationAddress(options.keystore, entry)
      : undefined
    if (predicted && address && predicted !== address.toLowerCase())
      throw new CetaneError(
        'Account address does not match its creation configuration.',
      )
    const resolved = address ?? predicted
    if (!resolved)
      throw new CetaneError(
        'Provide an account address or creation configuration.',
      )
    assertAddress(resolved)
    const account: Account = {
      address: resolved,
      async signTransaction({ hash, signer, authorization }) {
        return formatAuthorization(
          getAuthenticator(account, authorization).address,
          await signer.sign({ hash }),
        )
      },
      encodeCalls(calls) {
        return `${selectors.execute}${encodeAbiParameters(executionArgs, [calls.map((call) => ({ target: call.to, value: call.value ?? 0n, data: call.data ?? '0x' }))]).slice(2)}`
      },
      async encodeAuthorizationChanges(changes, context, parameters) {
        if (!parameters.signer)
          throw new CetaneError(
            'A signer is required to authorize configuration changes.',
          )
        const encoded: ConfigChange[] = []
        const grant = (value: Authorization) => {
          const item = actor(value)
          encoded.push({
            type: 0,
            payload: encodeAbiParameters(
              [{ type: 'bytes32' }, actorConfig, bytes],
              [
                item.actorId,
                {
                  authenticator: item.authenticator,
                  expiry: item.expiry,
                  scope: item.scope,
                },
                item.policyData,
              ],
            ),
          })
        }
        const revoke = (value: Authorization) =>
          encoded.push({
            type: 1,
            payload: encodeAbiParameters(
              [{ type: 'bytes32' }],
              [actor(value).actorId],
            ),
          })
        for (const change of changes) {
          if (change.type === 'grant') grant(change.authorization)
          else if (change.type === 'revoke') revoke(change.authorization)
          else {
            const previous = actor(change.current),
              next = actor(change.next)
            if ((previous.scope === 0) !== (next.scope === 0))
              throw new CetaneError(
                'Replacement must preserve the owner/delegate role.',
              )
            grant(change.next)
            if (previous.actorId.toLowerCase() !== next.actorId.toLowerCase())
              revoke(change.current)
          }
        }
        const result = await context.request<Hex>({
          method: 'eth_call',
          params: [
            {
              to: options.keystore,
              data: `${selectors.sequences}${addressWord(resolved)}`,
            },
            'pending',
          ],
        })
        const [multichain, epoch, local] = decodeAbiParameters(
          [{ type: 'uint64' }, { type: 'uint32' }, { type: 'uint32' }],
          result,
        )
        if (local >= 0xfffffffe)
          throw new CetaneError(
            'The local configuration sequence is saturated.',
          )
        // Creation runs before calls and initializes the local sequence to 1.
        const initial = entry && multichain === 0n && epoch === 0 && local === 0
        const sequence = (BigInt(epoch) << 32n) | BigInt(initial ? 1 : local)
        const signature = await account.signTransaction!({
          hash: changesHash(resolved, context.chain.id, sequence, encoded),
          signer: parameters.signer,
          ...(parameters.authorization
            ? { authorization: parameters.authorization }
            : {}),
        })
        const calls: Call[] = [
          {
            to: options.keystore,
            data: `${selectors.apply}${encodeAbiParameters([{ type: 'address' }, batch], [resolved, { channel: 0, sequence, changes: encoded.map((change) => ({ changeType: change.type, payload: change.payload })), signature }]).slice(2)}`,
          },
        ]
        return { calls }
      },
    }
    accounts.set(
      account,
      Object.freeze({
        keystore: options.keystore,
        ...(options.root ? { root: options.root } : {}),
        ...(entry ? { creation: entry } : {}),
        valueCalls: options.valueCalls ?? true,
      }),
    )
    return account
  }
}
