import { CetaneError } from '../errors.js'
import { encodeModuleChanges } from './erc7579.js'
import type {
  AccountFactory,
  Address,
  Authorization,
  Call,
  Hex,
} from '../types.js'
import { encodeAbiParameters } from '../utils/abi.js'
import { keccak256 } from '../utils/hash.js'
import { assertAddress, assertHex, word } from '../utils/hex.js'
import { readDeploymentCode } from './internal/deployment.js'
export { readKernelModules } from './kernelRead.js'
export type {
  ReadModulesOptions,
  KernelModuleSnapshot,
  ObservedModule,
} from './kernelRead.js'

export { defineValidatorModule } from './kernelModules.js'

export type Version = '3.3' | '4'
export const releaseReference = Object.freeze({
  version: '0.4.0',
  tag: 'v4.0',
  repository: 'https://github.com/zerodevapp/kernel',
  commit: 'c960b42d2ed4adb0d5328f6e762962debdf8e57a',
} as const)
const zero: Address = `0x${'00'.repeat(20)}`
const stub: Hex = `0x79be667ef9dcbbac55a06295ce870b07029bfcdb2dce28d959f2815b16f81798${'7f'.repeat(32)}1b`
const bytes = { type: 'bytes' } as const
const moduleArgs = [{ type: 'uint256' }, { type: 'address' }, bytes] as const
const executionArgs = [{ type: 'bytes32' }, bytes] as const
const batchArgs = [
  {
    type: 'tuple[]',
    components: [
      { name: 'to', type: 'address' },
      { name: 'value', type: 'uint256' },
      { name: 'data', type: 'bytes' },
    ],
  },
] as const
const packages = {
  type: 'tuple[]',
  components: [
    { name: 'moduleType', type: 'uint256' },
    { name: 'module', type: 'address' },
    { name: 'moduleData', type: 'bytes' },
    { name: 'internalData', type: 'bytes' },
  ],
} as const
const rootArgs = [
  { type: 'bytes21' },
  { type: 'address' },
  bytes,
  bytes,
] as const
const selector = (signature: string): Hex =>
  keccak256(new TextEncoder().encode(signature)).slice(0, 10) as Hex
const selectors = {
  execute: selector('execute(bytes32,bytes)'),
  initialize: selector('initialize(bytes21,address,bytes,bytes,bytes[])'),
  install: selector('installModule(uint256,address,bytes)'),
  uninstall: selector('uninstallModule(uint256,address,bytes)'),
  changeRoot: selector('changeRootValidator(bytes21,address,bytes,bytes)'),
  setRoot: selector('setRoot(bytes21)'),
  grant: selector('grantAccess(bytes21,bytes4,bool)'),
  uninstallValidation: selector('uninstallValidation(bytes21,bytes,bytes)'),
  onInstall: selector('onInstall(bytes)'),
  onUninstall: selector('onUninstall(bytes)'),
  create: selector('createAccount(bytes,bytes32)'),
  getAddress: selector('getAddress(bytes,bytes32)'),
  deployV4: selector('deploy((uint256,address,bytes,bytes)[],uint256)'),
  getAddressV4: selector('getAddress((uint256,address,bytes,bytes)[],uint256)'),
}
type ModuleGas = { enable?: bigint; disable?: bigint }
type Validator = {
  validator: Address
  owner: Address
  role: 'owner' | 'delegate'
  selectors: readonly Hex[]
  gas: ModuleGas
}
const authorizations = new WeakMap<Authorization, Validator>()

/** Public ECDSA validator configuration. No key material or signer is retained. */
export function createAuthorization(parameters: {
  validator: Address
  owner: Address
  role: 'owner' | 'delegate'
  selectors?: readonly Hex[]
  gas?: ModuleGas
}): Authorization {
  assertAddress(parameters.validator)
  assertAddress(parameters.owner)
  if (
    parameters.validator.toLowerCase() === zero ||
    parameters.owner.toLowerCase() === zero
  )
    throw new CetaneError('Validator and owner must be nonzero.')
  const allowed = parameters.selectors?.slice() ?? []
  allowed.forEach((value) => assertHex(value, 4))
  const authorization = Object.freeze({
    id: `0x01${parameters.validator.slice(2).toLowerCase()}` as Hex,
  })
  const gas = { ...parameters.gas }
  for (const value of Object.values(gas)) if (value !== undefined) word(value)
  authorizations.set(authorization, {
    validator: parameters.validator,
    owner: parameters.owner,
    role: parameters.role,
    selectors: allowed,
    gas,
  })
  return authorization
}
function get(authorization: Authorization): Validator {
  const value = authorizations.get(authorization)
  if (!value)
    throw new CetaneError(
      'Authorization was not created by this account adapter.',
    )
  return value
}
function moduleCall(to: Address, selector: Hex, data: Hex): Call {
  return { to, data: `${selector}${data.slice(2)}` }
}
function initialization(root: Authorization) {
  const value = get(root)
  if (value.role !== 'owner')
    throw new CetaneError('Initial authorization must be an owner.')
  return [
    {
      moduleType: 1n,
      module: value.validator,
      moduleData: value.owner,
      internalData: '0x' as Hex,
    },
  ]
}

/** Kernel 3.3 / EntryPoint 0.7, or Kernel 4 / EntryPoint 0.9. */
export function defineAccount(
  options: {
    version?: Version
    factory?: Address
    root?: Authorization
    moduleGasOverhead?: bigint
  } = {},
): AccountFactory {
  const version = options.version ?? '3.3'
  if (version !== '3.3' && version !== '4')
    throw new CetaneError('Unsupported Kernel version.')
  if (options.factory) assertAddress(options.factory)
  if (options.moduleGasOverhead !== undefined) word(options.moduleGasOverhead)
  return async ({ client, address, index = 0n }) => {
    word(index)
    let deploymentData: Hex | undefined
    let resolved = address
    if (options.factory) {
      if (!options.root)
        throw new CetaneError(
          'Counterfactual deployment requires public root authorization data.',
        )
      let args: Hex
      if (version === '3.3') {
        const root = get(options.root)
        if (root.role !== 'owner')
          throw new CetaneError('Initial authorization must be an owner.')
        const init: Hex = `${selectors.initialize}${encodeAbiParameters([...rootArgs, { type: 'bytes[]' }], [options.root.id, zero, root.owner, '0x', []]).slice(2)}`
        args = encodeAbiParameters(
          [bytes, { type: 'bytes32' }],
          [init, `0x${word(index)}`],
        )
      } else
        args = encodeAbiParameters(
          [packages, { type: 'uint256' }],
          [initialization(options.root), index],
        )
      deploymentData = `${version === '3.3' ? selectors.create : selectors.deployV4}${args.slice(2)}`
      if (!resolved) {
        const result = await client.request<Hex>({
          method: 'eth_call',
          params: [
            {
              to: options.factory,
              data: `${version === '3.3' ? selectors.getAddress : selectors.getAddressV4}${args.slice(2)}`,
            },
            'latest',
          ],
        })
        assertHex(result, 32)
        resolved = `0x${result.slice(-40)}`
      }
    }
    if (!resolved)
      throw new CetaneError(
        'Provide an account address or configure its factory and public root.',
      )
    const accountAddress = resolved
    return {
      address: accountAddress,
      ...(version === '4'
        ? { moduleDiscovery: { type: 'kernel' as const, version } }
        : {}),
      encodeModuleChanges: (changes) =>
        encodeModuleChanges(accountAddress, changes, options.moduleGasOverhead),
      stubSignature: stub,
      signTransaction: ({ hash, signer }) => signer.sign({ hash }),
      getNonceKey(key, authorization) {
        word(key, 2)
        return authorization
          ? (BigInt(get(authorization).validator) << 16n) | (1n << 176n) | key
          : key
      },
      encodeCalls(calls) {
        const single = calls.length === 1
        const call = calls[0]!
        const data: Hex = single
          ? `${call.to}${word(call.value ?? 0n)}${(call.data ?? '0x').slice(2)}`
          : encodeAbiParameters(batchArgs, [
              calls.map((c) => ({
                to: c.to,
                value: c.value ?? 0n,
                data: c.data ?? '0x',
              })),
            ])
        return `${selectors.execute}${encodeAbiParameters(executionArgs, [single ? `0x${'00'.repeat(32)}` : `0x01${'00'.repeat(31)}`, data]).slice(2)}`
      },
      async getDeployment(context) {
        if (!options.factory || !deploymentData) return undefined
        const code = await readDeploymentCode(context, accountAddress, 'latest')
        return code === '0x'
          ? { factory: options.factory, data: deploymentData }
          : undefined
      },
      encodeAuthorizationChanges(changes) {
        const calls: Call[] = []
        let gas: bigint | undefined = options.moduleGasOverhead
        const addGas = (amount: bigint | undefined) => {
          gas =
            gas !== undefined && amount !== undefined ? gas + amount : undefined
        }
        const grant = (authorization: Authorization) => {
          const value = get(authorization)
          addGas(value.gas.enable)
          const internalData: Hex = `0x${value.selectors.map((s) => s.slice(2)).join('')}`
          const data: Hex =
            version === '3.3'
              ? `${zero}${encodeAbiParameters([bytes, bytes, bytes], [value.owner, '0x', value.selectors[0] ?? '0x']).slice(2)}`
              : encodeAbiParameters([bytes, bytes], [value.owner, internalData])
          calls.push(
            moduleCall(
              accountAddress,
              selectors.install,
              encodeAbiParameters(moduleArgs, [1n, value.validator, data]),
            ),
          )
          if (version === '3.3')
            for (const s of value.selectors.slice(1))
              calls.push(
                moduleCall(
                  accountAddress,
                  selectors.grant,
                  encodeAbiParameters(
                    [{ type: 'bytes21' }, { type: 'bytes4' }, { type: 'bool' }],
                    [authorization.id, s, true],
                  ),
                ),
              )
        }
        const revoke = (authorization: Authorization) => {
          const value = get(authorization)
          addGas(value.gas.disable)
          calls.push(
            version === '3.3'
              ? moduleCall(
                  accountAddress,
                  selectors.uninstallValidation,
                  encodeAbiParameters(
                    [{ type: 'bytes21' }, bytes, bytes],
                    [authorization.id, '0x', '0x'],
                  ),
                )
              : moduleCall(
                  accountAddress,
                  selectors.uninstall,
                  encodeAbiParameters(moduleArgs, [
                    1n,
                    value.validator,
                    encodeAbiParameters([bytes, bytes], ['0x', '0x']),
                  ]),
                ),
          )
        }
        for (const change of changes) {
          if (change.type === 'grant') {
            if (get(change.authorization).role === 'owner')
              throw new CetaneError('Use replace to change the Kernel owner.')
            grant(change.authorization)
          } else if (change.type === 'revoke') {
            if (get(change.authorization).role === 'owner')
              throw new CetaneError(
                'Replace the Kernel owner before revoking it.',
              )
            revoke(change.authorization)
          } else {
            const previous = get(change.current),
              next = get(change.next)
            if (previous.role !== next.role)
              throw new CetaneError(
                'Replacement must preserve the authorization role.',
              )
            if (change.current.id === change.next.id) {
              addGas(previous.gas.disable)
              addGas(next.gas.enable)
              if (
                previous.selectors.join('').toLowerCase() !==
                next.selectors.join('').toLowerCase()
              )
                throw new CetaneError(
                  'Key rotation preserves selector permissions; revoke and grant to change selectors.',
                )
              // ECDSA validator key rotation preserves the installed module and its selector grants.
              calls.push(
                moduleCall(
                  previous.validator,
                  selectors.onUninstall,
                  encodeAbiParameters([bytes], ['0x']),
                ),
              )
              calls.push(
                moduleCall(
                  next.validator,
                  selectors.onInstall,
                  encodeAbiParameters([bytes], [next.owner]),
                ),
              )
            } else {
              // Root-selection storage/callback cost is implementation-specific; estimate unless
              // the caller supplies a complete operation gas limit.
              if (previous.role === 'owner') gas = undefined
              grant(change.next)
              if (previous.role === 'owner')
                calls.push(
                  version === '3.3'
                    ? moduleCall(
                        accountAddress,
                        selectors.changeRoot,
                        encodeAbiParameters(rootArgs, [
                          change.next.id,
                          zero,
                          next.owner,
                          '0x',
                        ]),
                      )
                    : moduleCall(
                        accountAddress,
                        selectors.setRoot,
                        encodeAbiParameters(
                          [{ type: 'bytes21' }],
                          [change.next.id],
                        ),
                      ),
                )
              revoke(change.current)
            }
          }
        }
        return { calls, ...(gas !== undefined ? { gas } : {}) }
      },
    }
  }
}
