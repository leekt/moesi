import { parseAbi } from 'abitype'
import type { Address, Hex } from '../types.js'
import { decodeAbiParameters, decodeFunctionData } from '../utils/abi.js'

const abi = /* @__PURE__ */ parseAbi([
  'struct Install { uint256 moduleType; address module; bytes moduleData; bytes internalData; }',
  'struct PackedUserOperation { address sender; uint256 nonce; bytes initCode; bytes callData; bytes32 accountGasLimits; uint256 preVerificationGas; bytes32 gasFees; bytes paymasterAndData; bytes signature; }',
  'struct UserOpsPerAggregator { PackedUserOperation[] userOps; address aggregator; bytes signature; }',
  'function handleOps(PackedUserOperation[] ops, address beneficiary)',
  'function handleAggregatedOps(UserOpsPerAggregator[] opsPerAggregator, address beneficiary)',
  'function executeUserOp(PackedUserOperation userOp, bytes32 userOpHash)',
  'function execute(bytes32 mode, bytes executionData)',
  'function executeFromExecutor(bytes32 mode, bytes executionData)',
  'function installModule(uint256 moduleType, address module, bytes initData)',
  'function installModule(Install[] packages)',
  'function installModule(bool replayable, uint256 nonce, Install[] packages, bytes signature)',
  'function setRoot(Install[] packages, bool removeCurrent, bytes uninstallData)',
  'function setRoot(bytes21 vId)',
  'function initialize(Install[] packages)',
  'function deploy(Install[] packages, uint256 index)',
])
type Package = { moduleType: bigint; module: Address; internalData: Hex }
export type KernelHistoryHints = {
  permissionIds: Set<Hex>
  selectors: Set<Hex>
}
/** Calldata supplies discovery hints only. Every resulting context is checked against pinned state. */
export function collectKernelHistory(
  data: Hex,
  account: Address,
  hints: KernelHistoryHints,
  depth = 0,
): void {
  if (depth > 16) return
  try {
    const decoded = decodeFunctionData({ abi, data })
    const { functionName: name, args } = decoded
    const packages = (values: readonly Package[]) => {
      for (const p of values) {
        if (
          (p.moduleType === 5n || p.moduleType === 6n) &&
          p.internalData.length >= 10
        )
          hints.permissionIds.add(
            p.internalData.slice(0, 10).toLowerCase() as Hex,
          )
        if (p.moduleType === 3n && p.internalData.length >= 10)
          hints.selectors.add(p.internalData.slice(0, 10).toLowerCase() as Hex)
        if (p.moduleType === 11n) {
          if (
            p.internalData.startsWith('0x0102') &&
            p.internalData.length >= 14
          )
            hints.permissionIds.add(
              `0x${p.internalData.slice(6, 14)}`.toLowerCase() as Hex,
            )
          if (p.internalData.startsWith('0x03') && p.internalData.length >= 12)
            hints.selectors.add(
              `0x${p.internalData.slice(4, 12)}`.toLowerCase() as Hex,
            )
        }
      }
    }
    const operation = (op: {
      sender: Address
      nonce: bigint
      callData: Hex
      initCode: Hex
      signature: Hex
    }) => {
      if (op.sender.toLowerCase() !== account.toLowerCase()) return
      collectKernelHistory(op.callData, account, hints, depth + 1)
      // executeUserOp callData prefixes the inner call with only its selector.
      if (op.callData.startsWith('0x8dd7712f'))
        collectKernelHistory(
          `0x${op.callData.slice(10)}`,
          account,
          hints,
          depth + 1,
        )
      if (op.initCode.length > 42)
        collectKernelHistory(
          `0x${op.initCode.slice(42)}`,
          account,
          hints,
          depth + 1,
        )
      // Kernel enable-mode signatures carry install packages, independently of callData.
      if (((op.nonce >> 248n) & 8n) !== 0n) {
        const [, enabled] = decodeAbiParameters(
          [
            { name: 'nonce', type: 'uint256' },
            {
              name: 'packages',
              type: 'tuple[]',
              components: [
                { name: 'moduleType', type: 'uint256' },
                { name: 'module', type: 'address' },
                { name: 'moduleData', type: 'bytes' },
                { name: 'internalData', type: 'bytes' },
              ],
            },
            { name: 'enableSignature', type: 'bytes' },
            { name: 'userOpSignature', type: 'bytes' },
          ],
          op.signature,
        )
        packages(enabled)
      }
    }
    if (name === 'handleOps') args[0].forEach(operation)
    else if (name === 'handleAggregatedOps')
      args[0].forEach((group) => group.userOps.forEach(operation))
    else if (name === 'executeUserOp') operation(args[0])
    else if (name === 'execute' || name === 'executeFromExecutor') {
      const [mode, calls] = args
      if (mode.slice(2, 4) === '00' && calls.length >= 106) {
        if (calls.slice(0, 42).toLowerCase() === account.toLowerCase())
          collectKernelHistory(
            `0x${calls.slice(106)}`,
            account,
            hints,
            depth + 1,
          )
      } else if (mode.slice(2, 4) === '01') {
        const [batch] = decodeAbiParameters(
          [
            {
              type: 'tuple[]',
              components: [
                { name: 'to', type: 'address' },
                { name: 'value', type: 'uint256' },
                { name: 'data', type: 'bytes' },
              ],
            },
          ],
          calls,
        )
        for (const call of batch)
          if (call.to.toLowerCase() === account.toLowerCase())
            collectKernelHistory(call.data, account, hints, depth + 1)
      }
    } else if (name === 'initialize' || name === 'deploy') packages(args[0])
    else if (name === 'setRoot') {
      if (typeof args[0] === 'string') {
        if (args[0].startsWith('0x02'))
          hints.permissionIds.add(`0x${args[0].slice(4, 12)}`)
      } else packages(args[0])
    } else if (name === 'installModule') {
      if (typeof args[0] === 'bigint') {
        const [, internalData] = decodeAbiParameters(
          [{ type: 'bytes' }, { type: 'bytes' }],
          args[2] as Hex,
        )
        packages([
          { moduleType: args[0], module: args[1] as Address, internalData },
        ])
      } else if (typeof args[0] === 'boolean')
        packages(args[2] as readonly Package[])
      else packages(args[0])
    }
  } catch {
    // Arbitrary outer contracts and opaque signature modes cannot be enumerated without tracing.
    // The caller keeps their module events history-derived and reports unknown contexts.
  }
}
