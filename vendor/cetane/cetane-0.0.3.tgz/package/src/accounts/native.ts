import { CetaneError } from '../errors.js'
import type { AccountFactory } from '../types.js'

export const account: AccountFactory = ({ owner, address, index }) => {
  const resolved = address ?? owner
  if (!resolved) throw new CetaneError('An account address is required.')
  if (index !== undefined && index !== 0n)
    throw new CetaneError('This account does not support derivation indexes.')
  return {
    address: resolved,
  }
}
