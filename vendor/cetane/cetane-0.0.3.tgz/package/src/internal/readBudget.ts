import { CetaneError } from '../errors.js'
import type { Request, RpcRequest } from '../types.js'

export type ReadBudget = {
  maxRequests?: number
  timeout?: number
  signal?: AbortSignal
}
export class ReadBudgetExceeded extends CetaneError {}

/** One deadline and request count shared by a compound read; providers need not honor abort. */
export function createReadBudget(request: Request, options: ReadBudget = {}) {
  const maxRequests = options.maxRequests ?? 256
  const timeout = options.timeout ?? 10_000
  if (
    !Number.isSafeInteger(maxRequests) ||
    maxRequests < 1 ||
    !Number.isFinite(timeout) ||
    timeout <= 0 ||
    timeout > 2_147_483_647
  )
    throw new CetaneError(
      'Read budget must have positive requests and timeout.',
    )
  const deadline = performance.now() + timeout
  let requests = 0
  return {
    get requests() {
      return requests
    },
    async request<T>(input: RpcRequest): Promise<T> {
      options.signal?.throwIfAborted()
      const remaining = deadline - performance.now()
      if (requests >= maxRequests || remaining <= 0)
        throw new ReadBudgetExceeded('Read budget exhausted.')
      requests++
      const controller = new AbortController()
      let timer: ReturnType<typeof setTimeout> | undefined
      let abort: (() => void) | undefined
      const cancelled = new Promise<never>((_, reject) => {
        timer = setTimeout(() => {
          const error = new ReadBudgetExceeded('Read deadline exceeded.')
          controller.abort(error)
          reject(error)
        }, remaining)
        abort = () => {
          controller.abort(options.signal!.reason)
          reject(options.signal!.reason)
        }
        options.signal?.addEventListener('abort', abort, { once: true })
      })
      try {
        return await Promise.race([
          request<T>(input, { signal: controller.signal }),
          cancelled,
        ])
      } finally {
        clearTimeout(timer)
        if (abort) options.signal?.removeEventListener('abort', abort)
      }
    },
  }
}
