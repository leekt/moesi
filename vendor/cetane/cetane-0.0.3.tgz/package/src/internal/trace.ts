import type { Client, Context, Request } from '../types.js'
import type { TraceContext, TraceSpan } from '../trace/types.js'
import { preserveIdentity, preserveRequestIdentity } from './identity.js'
import { nextTraceOperationId, nextTraceSpanId } from './defaultTrace.js'

export type ActiveSpan = {
  readonly trace: TraceContext
  end(status?: TraceSpan['status']): void
}

const wrappedRequests = new WeakMap<Request, Request>()
const monotonicNow = () => performance.now()

function emit(trace: TraceContext, span: TraceSpan): void {
  try {
    // A JavaScript observer can return a Promise despite the void callback type.
    const result = trace.sink(span) as unknown
    if (
      result !== null &&
      (typeof result === 'object' || typeof result === 'function') &&
      typeof (result as { then?: unknown }).then === 'function'
    )
      void Promise.resolve(result).catch(() => {})
  } catch {
    // Diagnostics cannot change transaction or nonce semantics.
  }
}

export function beginSpan(
  trace: TraceContext | undefined,
  name: string,
  attributes?: TraceSpan['attributes'],
): ActiveSpan | undefined {
  if (!trace) return undefined
  const now = trace.now ?? monotonicNow
  let startMs: number
  try {
    startMs = now()
    if (!Number.isFinite(startMs)) return undefined
  } catch {
    return undefined
  }
  const id = nextTraceSpanId()
  const child: TraceContext = { ...trace, spanId: id }
  const snapshot = attributes ? Object.freeze({ ...attributes }) : undefined
  let ended = false
  return {
    trace: child,
    end(status = 'ok') {
      if (ended) return
      ended = true
      let durationMs: number
      try {
        const endMs = now()
        if (!Number.isFinite(endMs)) return
        durationMs = Math.max(0, endMs - startMs)
      } catch {
        return
      }
      emit(
        trace,
        Object.freeze({
          operationId: trace.operationId,
          id,
          ...(trace.spanId !== undefined ? { parentId: trace.spanId } : {}),
          name,
          startMs,
          durationMs,
          status,
          ...(snapshot ? { attributes: snapshot } : {}),
        }),
      )
    },
  }
}

export function traceSync<T>(
  trace: TraceContext | undefined,
  name: string,
  run: () => T,
  attributes?: TraceSpan['attributes'],
): T {
  const span = beginSpan(trace, name, attributes)
  if (!span) return run()
  try {
    const value = run()
    span.end()
    return value
  } catch (error) {
    span.end('error')
    throw error
  }
}

export function traceAsync<T>(
  trace: TraceContext | undefined,
  name: string,
  run: (trace: TraceContext | undefined) => T | PromiseLike<T>,
  attributes?: TraceSpan['attributes'],
): Promise<T> {
  const span = beginSpan(trace, name, attributes)
  if (!span) return Promise.resolve(run(undefined))
  try {
    return Promise.resolve(run(span.trace)).then(
      (value) => {
        span.end()
        return value
      },
      (error: unknown) => {
        span.end('error')
        throw error
      },
    )
  } catch (error) {
    span.end('error')
    throw error
  }
}

export function traceRequestFunction(
  request: Request,
  trace: TraceContext | undefined,
  endpoint: 'rpc' | 'relay' | 'sponsor',
): Request {
  if (!trace) return request
  // Only unwrap our instrumentation. Cancellation, deadlines and other wrappers remain active.
  const original = wrappedRequests.get(request) ?? request
  const wrapped: Request = (parameters, options) =>
    traceAsync(trace, 'rpc', () => original(parameters, options), {
      method: parameters.method,
      endpoint,
    })
  wrappedRequests.set(wrapped, original)
  preserveRequestIdentity(request, wrapped)
  return wrapped
}

export function scopeContext<T extends Context>(
  context: T,
  trace: TraceContext | undefined,
): T {
  if (!trace && !context.trace) return context
  if (!trace) {
    const { trace: _trace, ...fields } = context
    const scoped = Object.setPrototypeOf(
      fields,
      Object.getPrototypeOf(context),
    ) as T
    Object.assign(scoped, {
      request: wrappedRequests.get(context.request) ?? context.request,
      relay: wrappedRequests.get(context.relay) ?? context.relay,
    })
    preserveIdentity(context as unknown as Client, scoped as unknown as Client)
    return scoped
  }
  const scoped: T = Object.assign(
    Object.create(Object.getPrototypeOf(context)),
    context,
    {
      trace,
      request: traceRequestFunction(context.request, trace, 'rpc'),
      relay: traceRequestFunction(context.relay, trace, 'relay'),
    },
  )
  preserveIdentity(context as unknown as Client, scoped as unknown as Client)
  return scoped
}

export function startOperation<T extends Context>(
  context: T,
  name: string,
  attributes?: TraceSpan['attributes'],
): { context: T; span: ActiveSpan } | undefined {
  if (!context.trace) return undefined
  if (context.trace.spanId === undefined && context.trace.sample) {
    try {
      if (!context.trace.sample()) return undefined
    } catch {
      return undefined
    }
  }
  const trace =
    context.trace.spanId === undefined
      ? { ...context.trace, operationId: nextTraceOperationId() }
      : context.trace
  const span = beginSpan(trace, name, attributes)
  if (!span) return undefined
  return { context: scopeContext(context, span.trace), span }
}

export function traceOperation<T extends Context, R>(
  context: T,
  name: string,
  run: (context: T) => Promise<R>,
  attributes?: TraceSpan['attributes'],
): Promise<R> {
  const operation = startOperation(context, name, attributes)
  if (!operation)
    return run(context.trace ? scopeContext(context, undefined) : context)
  try {
    return run(operation.context).then(
      (value) => {
        operation.span.end()
        return value
      },
      (error: unknown) => {
        operation.span.end('error')
        throw error
      },
    )
  } catch (error) {
    operation.span.end('error')
    throw error
  }
}
