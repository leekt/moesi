import { installKeccakBackend } from '../utils/hash.js'

export type KeccakBackend = Parameters<typeof installKeccakBackend>[0]

/** Each optional backend owns its verification promise and verified closure. */
export function createHashingEnabler(
  initialize: () => Promise<KeccakBackend>,
  install: (backend: KeccakBackend) => void = installKeccakBackend,
): () => Promise<void> {
  let setup: Promise<void> | undefined
  let verified: KeccakBackend | undefined
  return function enable(): Promise<void> {
    // A completed setup can be selected again without loading or repeating KATs.
    if (verified) install(verified)
    return (setup ??= Promise.resolve()
      .then(initialize)
      .then((hash) => {
        install(hash)
        verified = hash
      })
      .catch((error: unknown) => {
        setup = undefined
        throw error
      }))
  }
}
