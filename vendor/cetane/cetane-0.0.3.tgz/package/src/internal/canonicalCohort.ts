// Shares queued calls only, never in-flight results. Scheduling is internal.
import type { RequestOptions, RpcRequest, Transport } from '../types.js'

import { TransportError } from '../errors.js'

export type CanonicalReadStats = Readonly<{
  /** Admitted logical canonical reads, including callers that later cancel. */
  admitted: number
  /** Logical callers joined to an existing queued cohort. */
  joined: number
  /** Canonical base.request invocations, including synchronous failures. */
  dispatched: number
  rejected: number
  cancelled: number
  pending: number
}>
export type CanonicalReadTransport = Transport & {
  /** Snapshot of this wrapper's canonical-read counters; excludes other RPCs. */
  stats(): CanonicalReadStats
}

type Listener = (error: boolean, value: unknown) => void
type Cohort = {
  listeners: Set<Listener>
  controller: AbortController
  done: boolean
  cancelDispatch: (() => void) | undefined
}

function dispatch(base: Transport, request: RpcRequest, cohort: Cohort) {
  const settle = (error: boolean, value: unknown) => {
    if (cohort.done) return
    cohort.done = true
    for (const listener of cohort.listeners) listener(error, value)
  }
  try {
    Promise.resolve(
      base.request(request, { signal: cohort.controller.signal }),
    ).then(
      (value) => settle(false, value),
      (error) => settle(true, error),
    )
  } catch (error) {
    settle(true, error)
  }
}

export function createCanonicalCohort(
  base: Transport,
  schedule: (work: () => void) => void | (() => void) = queueMicrotask,
  { maxPending = 1024 }: { maxPending?: number } = {},
): CanonicalReadTransport {
  if (!Number.isSafeInteger(maxPending) || maxPending < 1)
    throw new RangeError('maxPending must be a positive safe integer')
  const queued = new Map<string, Cohort>()
  // Counts logical subscribers, including those awaiting a dispatched RPC.
  let pending = 0,
    admitted = 0,
    joined = 0,
    dispatched = 0,
    rejected = 0,
    cancelled = 0
  return {
    stats: () => ({
      admitted,
      joined,
      dispatched,
      rejected,
      cancelled,
      pending,
    }),
    request<T>(request: RpcRequest, options?: RequestOptions): Promise<T> {
      const params = request.params
      if (
        request.method !== 'eth_getBlockByNumber' ||
        params?.length !== 2 ||
        typeof params[0] !== 'string' ||
        !/^0x(?:0|[1-9a-f][0-9a-f]*)$/.test(params[0]) ||
        params[1] !== false
      )
        return base.request<T>(request, options)
      const signal = options?.signal
      if (signal?.aborted) return Promise.reject(signal.reason)
      if (pending >= maxPending) {
        rejected++
        return Promise.reject(
          new TransportError('Canonical cohort capacity exceeded'),
        )
      }
      const key = params[0]
      let cohort = queued.get(key)
      admitted++
      if (cohort) joined++
      if (!cohort) {
        cohort = {
          listeners: new Set(),
          controller: new AbortController(),
          done: false,
          cancelDispatch: undefined,
        }
        queued.set(key, cohort)
        const current = cohort
        const cancel = schedule(() => {
          current.cancelDispatch = undefined
          // This boundary prevents a late caller from reusing an older observation.
          if (queued.get(key) === current) queued.delete(key)
          if (!current.done && current.listeners.size) {
            dispatched++
            dispatch(
              base,
              { method: 'eth_getBlockByNumber', params: [key, false] },
              current,
            )
          }
        })
        if (typeof cancel === 'function') current.cancelDispatch = cancel
      }
      const current = cohort
      pending++
      return new Promise<T>((resolve, reject) => {
        let done = false
        const finish: Listener = (error, value) => {
          if (done) return
          done = true
          pending--
          current.listeners.delete(finish)
          signal?.removeEventListener('abort', abort)
          if (error) reject(value)
          else resolve(value as T)
        }
        const abort = () => {
          if (done) return
          cancelled++
          finish(true, signal!.reason)
          if (!current.listeners.size && !current.done) {
            current.done = true
            current.cancelDispatch?.()
            current.cancelDispatch = undefined
            if (queued.get(key) === current) queued.delete(key)
            current.controller.abort(signal!.reason)
          }
        }
        current.listeners.add(finish)
        signal?.addEventListener('abort', abort, { once: true })
      })
    },
  }
}
