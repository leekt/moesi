import { TransportError } from '../errors.js'

export type Reply = {
  jsonrpc: '2.0'
  id: number
  result?: unknown
  error?: { code: number; message: string; data?: unknown }
}

export function validateReply(
  data: unknown,
  id: number,
  method: string,
): Reply {
  if (
    !data ||
    typeof data !== 'object' ||
    Array.isArray(data) ||
    !('jsonrpc' in data) ||
    data.jsonrpc !== '2.0' ||
    !('id' in data) ||
    data.id !== id ||
    'result' in data === 'error' in data
  )
    throw new TransportError(`Invalid JSON-RPC response for ${method}.`)
  if ('error' in data) {
    const error = data.error as Reply['error']
    if (
      !error ||
      !Number.isInteger(error.code) ||
      typeof error.message !== 'string'
    )
      throw new TransportError(`Invalid JSON-RPC error for ${method}.`)
  }
  return data as Reply
}
