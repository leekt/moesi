import type { TraceContext } from '../trace/types.js'

type Registration = {
  factory: () => TraceContext | undefined
  previous: Registration | undefined
  active: boolean
}

type SharedTraceState = {
  current: Registration | undefined
  operationId: number
  spanId: number
}

// A preload and a bundled application can contain separate Cetane copies.
// Share only the versioned diagnostics bridge; no exporter is loaded here.
const key = Symbol.for('cetane.tracing.v1')
const globals = globalThis as typeof globalThis & {
  [key: symbol]: SharedTraceState | undefined
}

function state(): SharedTraceState {
  return (globals[key] ??= {
    current: undefined,
    operationId: 0,
    spanId: 0,
  })
}

export function nextTraceOperationId(): number {
  return ++state().operationId
}

export function nextTraceSpanId(): number {
  return ++state().spanId
}

/** Register portable defaults without bringing an exporter into the client. */
export function setDefaultTraceFactory(
  factory: () => TraceContext | undefined,
): () => void {
  const shared = state()
  const registration: Registration = {
    factory,
    previous: shared.current,
    active: true,
  }
  shared.current = registration
  return () => {
    if (!registration.active) return
    registration.active = false
    if (shared.current !== registration) return
    shared.current = registration.previous
    while (shared.current && !shared.current.active)
      shared.current = shared.current.previous
  }
}

export function getDefaultTrace(): TraceContext | undefined {
  try {
    return globals[key]?.current?.factory()
  } catch {
    // Diagnostics setup cannot prevent an application from creating a client.
    return undefined
  }
}

/** Diagnostics tooling can detect resource-only registrations without calling their factory. */
export function hasDefaultTraceRegistration(): boolean {
  return Boolean(globals[key]?.current)
}
