import type { Hash } from '../../types.js'

/** Private Node-API boundary; callers must provide ordinary fixed byte views. */
export type NativeKeccakAddon = {
  hash(first: Uint8Array, second?: Uint8Array): Hash
}
