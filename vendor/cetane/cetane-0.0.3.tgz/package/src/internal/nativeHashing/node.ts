import type { NativeKeccakAddon } from './types.js'

/** Imported only after the public enabler checks the supported platform. */
export async function loadAddon(): Promise<NativeKeccakAddon> {
  const moduleName = 'node:module'
  const { createRequire } = (await import(moduleName)) as {
    createRequire(url: URL): (specifier: string) => NativeKeccakAddon
  }
  const require = createRequire(
    new URL('../../../native/darwin-arm64/package.json', import.meta.url),
  )
  return require('./keccak.node')
}
