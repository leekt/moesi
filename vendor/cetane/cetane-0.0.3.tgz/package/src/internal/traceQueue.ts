/** FIFO with amortized linear draining and prompt release of exported references. */
export class TraceQueue<T> {
  private items: (T | undefined)[] = []
  private head = 0

  get length() {
    return this.items.length - this.head
  }

  push(value: T) {
    this.items.push(value)
  }

  take(count: number): T[] {
    const end = Math.min(this.head + count, this.items.length)
    // Only consumed slots are undefined; the live suffix contains T values.
    const values = this.items.slice(this.head, end) as T[]
    this.items.fill(undefined, this.head, end)
    this.head = end
    if (this.head === this.items.length) this.clear()
    else if (this.head >= 4096 && this.head * 2 >= this.items.length) {
      this.items = this.items.slice(this.head)
      this.head = 0
    }
    return values
  }

  clear() {
    this.items = []
    this.head = 0
  }
}
