import { randomUUID } from 'node:crypto'
import { TraceQueue } from '../internal/traceQueue.js'
import process from 'node:process'
import {
  setInterval,
  clearInterval,
  setTimeout,
  clearTimeout,
  setImmediate,
  clearImmediate,
} from 'node:timers'
import { setDefaultTraceFactory } from '../internal/defaultTrace.js'
import type { TraceContext, TraceSink, TraceSpan } from '../trace/types.js'
import { createTraceExporter, writeTraceDiagnostic } from './exporters.js'
import type { TraceExporterOptions } from './exporters.js'
import type {
  ResourceSample,
  TraceBatch,
  TraceExporter,
} from './productionTypes.js'

export type { ResourceSample, TraceBatch, TraceExporter, TraceExporterOptions }

export type ProductionTraceOptions = {
  output?: TraceExporterOptions | TraceExporter
  serviceName?: string
  /** Fraction of complete operations to trace. Resources have a separate interval. */
  sampleRate?: number
  /** Retained spans, including the batch currently being exported. */
  maxSpans?: number
  maxResourceSamples?: number
  batchSize?: number
  flushIntervalMs?: number
  /** Zero disables process CPU and memory samples. */
  resourceIntervalMs?: number
  shutdownTimeoutMs?: number
  onError?: (kind: 'export' | 'resources') => void
}
export type ProductionTraceStats = Readonly<{
  bufferedSpans: number
  bufferedResources: number
  droppedSpans: number
  droppedResources: number
  exportFailures: number
  resourceFailures: number
  closed: boolean
}>
export type ProductionTrace = {
  readonly sink: TraceSink
  readonly sessionId: string
  readonly stats: ProductionTraceStats
  /** Flush work queued at invocation; export failures are counted and never rethrown. */
  flush(): Promise<void>
  /** Stop future capture and make a bounded best-effort final flush. Drain application work first. */
  shutdown(): Promise<void>
}

function integer(
  value: number,
  name: string,
  min: number,
  max: number,
): number {
  if (!Number.isSafeInteger(value) || value < min || value > max)
    throw new RangeError(`${name} must be an integer from ${min} to ${max}.`)
  return value
}

/** Server-only production collector. No exporter runs on the transaction's call stack. */
export function startTracing(
  options: ProductionTraceOptions = {},
): ProductionTrace {
  const rate = options.sampleRate ?? 1
  if (!Number.isFinite(rate) || rate < 0 || rate > 1)
    throw new RangeError('sampleRate must be between zero and one.')
  const maxSpans = integer(options.maxSpans ?? 10_000, 'maxSpans', 1, 1_000_000)
  const maxResources = integer(
    options.maxResourceSamples ?? 1024,
    'maxResourceSamples',
    1,
    100_000,
  )
  const batchSize = integer(
    options.batchSize ?? Math.min(256, maxSpans),
    'batchSize',
    1,
    maxSpans,
  )
  const flushInterval = integer(
    options.flushIntervalMs ?? 1000,
    'flushIntervalMs',
    10,
    60_000,
  )
  const resourceInterval = options.resourceIntervalMs ?? 1000
  if (resourceInterval !== 0)
    integer(resourceInterval, 'resourceIntervalMs', 50, 60_000)
  const shutdownTimeout = integer(
    options.shutdownTimeoutMs ?? 2000,
    'shutdownTimeoutMs',
    1,
    60_000,
  )
  const serviceName = options.serviceName ?? 'cetane'
  if (!serviceName || serviceName.length > 256)
    throw new RangeError(
      'serviceName must contain between 1 and 256 characters.',
    )
  const output = options.output ?? { type: 'stderr' as const }
  const exporter = 'export' in output ? output : createTraceExporter(output)
  const sessionId = randomUUID().replaceAll('-', '')
  const timeOriginMs = performance.timeOrigin
  const pendingSpans = new TraceQueue<TraceSpan>()
  const pendingResources = new TraceQueue<ResourceSample>()
  let retainedSpans = 0,
    retainedResources = 0,
    droppedSpans = 0,
    droppedResources = 0
  let exportFailures = 0,
    resourceFailures = 0,
    reportedSpanDrops = 0,
    reportedResourceDrops = 0
  let closed = false
  let abandoned = false
  let flushing: Promise<void> | undefined
  let batchFlush: ReturnType<typeof setImmediate> | undefined
  let queuedFlush: Promise<void> | undefined
  let shutdown: Promise<void> | undefined
  let closingExporter: Promise<void> | undefined
  const warned = new Set<string>()
  function scheduleBatchFlush() {
    if (
      closed ||
      abandoned ||
      flushing ||
      batchFlush ||
      (pendingSpans.length < batchSize && pendingResources.length < batchSize)
    )
      return
    batchFlush = setImmediate(() => {
      batchFlush = undefined
      void flush()
    })
    batchFlush.unref()
  }
  const warn = (kind: 'export' | 'resources') => {
    try {
      if (options.onError) {
        const result = options.onError(kind) as unknown
        if (
          result !== null &&
          (typeof result === 'object' || typeof result === 'function') &&
          typeof (result as { then?: unknown }).then === 'function'
        )
          void Promise.resolve(result).catch(() => {})
      } else if (!warned.has(kind)) {
        warned.add(kind)
        void writeTraceDiagnostic(
          `[cetane.trace] ${kind} failed; diagnostics may be incomplete.\n`,
        ).catch(() => {})
      }
    } catch {
      /* Diagnostics must never affect application work. */
    }
  }
  const sink: TraceSink = (span) => {
    if (closed || retainedSpans >= maxSpans) {
      droppedSpans++
      return
    }
    pendingSpans.push(span)
    retainedSpans++
    scheduleBatchFlush()
  }
  function closeExporter(): Promise<void> {
    return (closingExporter ??= Promise.resolve().then(async () => {
      try {
        await exporter.close?.()
      } catch {
        exportFailures++
        warn('export')
      }
    }))
  }
  let previousCpu: { user: number; system: number } | undefined
  let previousTime = 0
  function sampleResources() {
    if (closed || resourceInterval === 0) return
    try {
      const timeMs = performance.now()
      const cpu = process.cpuUsage()
      const memory = process.memoryUsage()
      const elapsed = timeMs - previousTime
      const cpuPercent =
        !previousCpu || elapsed <= 0
          ? 0
          : Math.max(
              0,
              (cpu.user - previousCpu.user + cpu.system - previousCpu.system) /
                (elapsed * 10),
            )
      previousCpu = cpu
      previousTime = timeMs
      if (retainedResources >= maxResources) {
        droppedResources++
        return
      }
      pendingResources.push({
        timeMs,
        cpuUserMicros: cpu.user,
        cpuSystemMicros: cpu.system,
        cpuPercent,
        rssBytes: memory.rss,
        heapUsedBytes: memory.heapUsed,
        heapTotalBytes: memory.heapTotal,
        externalBytes: memory.external,
        arrayBuffersBytes: memory.arrayBuffers,
      })
      retainedResources++
      scheduleBatchFlush()
    } catch {
      resourceFailures++
      warn('resources')
    }
  }
  function flush(): Promise<void> {
    if (batchFlush) {
      clearImmediate(batchFlush)
      batchFlush = undefined
    }
    if (abandoned) return Promise.resolve()
    if (flushing) {
      // Coalesce concurrent callers into one follow-up snapshot, including work
      // queued since the active export began, without an unbounded Promise chain.
      return (queuedFlush ??= flushing.then(() => {
        queuedFlush = undefined
        return flush()
      }))
    }
    let spansLeft = pendingSpans.length,
      resourcesLeft = pendingResources.length
    if (
      !spansLeft &&
      !resourcesLeft &&
      reportedSpanDrops === droppedSpans &&
      reportedResourceDrops === droppedResources
    )
      return Promise.resolve()
    // Defer JSON encoding and I/O until after the producer's synchronous work.
    const work = Promise.resolve().then(async () => {
      let turnStarted = performance.now()
      let batches = 0
      do {
        const spans = pendingSpans.take(Math.min(batchSize, spansLeft))
        const resources = pendingResources.take(
          Math.min(batchSize, resourcesLeft),
        )
        spansLeft -= spans.length
        resourcesLeft -= resources.length
        const batch: TraceBatch = {
          schemaVersion: 1,
          sessionId,
          serviceName,
          pid: process.pid,
          timeOriginMs,
          spans,
          resources,
          droppedSpans,
          droppedResources,
        }
        reportedSpanDrops = droppedSpans
        reportedResourceDrops = droppedResources
        try {
          await exporter.export(batch)
        } catch {
          if (!abandoned) {
            droppedSpans += spans.length
            droppedResources += resources.length
          }
          exportFailures++
          warn('export')
        } finally {
          retainedSpans -= spans.length
          retainedResources -= resources.length
        }
        // Resolved exporter promises alone do not let sockets/timers run.
        // Amortize clock reads and yield long drains without changing the snapshot.
        if (
          !abandoned &&
          (spansLeft || resourcesLeft) &&
          ++batches % 64 === 0 &&
          performance.now() - turnStarted >= 4
        ) {
          await new Promise<void>((resolve) => setImmediate(resolve))
          turnStarted = performance.now()
        }
      } while (!abandoned && (spansLeft || resourcesLeft))
    })
    flushing = work.finally(() => {
      flushing = undefined
      scheduleBatchFlush()
    })
    return flushing
  }
  const trace: TraceContext = {
    sink,
    operationId: 0,
    sample: () => !closed && (rate === 1 || (rate > 0 && Math.random() < rate)),
  }
  const unregister = setDefaultTraceFactory(() =>
    closed || rate === 0 ? undefined : trace,
  )
  const flushTimer = setInterval(() => {
    void flush()
  }, flushInterval)
  flushTimer.unref()
  const resourceTimer =
    resourceInterval > 0
      ? setInterval(sampleResources, resourceInterval)
      : undefined
  resourceTimer?.unref()
  const onBeforeExit = () => {
    void flush()
  }
  process.on('beforeExit', onBeforeExit)
  sampleResources()
  const controller: ProductionTrace = {
    sink,
    sessionId,
    get stats() {
      return Object.freeze({
        bufferedSpans: retainedSpans,
        bufferedResources: retainedResources,
        droppedSpans,
        droppedResources,
        exportFailures,
        resourceFailures,
        closed,
      })
    },
    flush,
    shutdown() {
      if (shutdown) return shutdown
      sampleResources()
      closed = true
      unregister()
      clearInterval(flushTimer)
      if (batchFlush) {
        clearImmediate(batchFlush)
        batchFlush = undefined
      }
      if (resourceTimer) clearInterval(resourceTimer)
      process.removeListener('beforeExit', onBeforeExit)
      shutdown = (async () => {
        let timer: ReturnType<typeof setTimeout> | undefined
        const timeout = new Promise<void>((resolve) => {
          timer = setTimeout(() => {
            abandoned = true
            droppedSpans += retainedSpans
            droppedResources += retainedResources
            retainedSpans -= pendingSpans.length
            retainedResources -= pendingResources.length
            pendingSpans.clear()
            pendingResources.clear()
            // Release network handles even if the active export has stalled.
            void closeExporter()
            resolve()
          }, shutdownTimeout)
        })
        const drain = (async () => {
          await flush()
          // A previous in-flight export may have excluded work added after its snapshot.
          await flush()
          await closeExporter()
        })()
        await Promise.race([drain, timeout])
        if (timer) clearTimeout(timer)
      })()
      return shutdown
    },
  }
  return controller
}

const environmentKey = Symbol.for('cetane.tracing.environment.v1')
const environmentRegistry = globalThis as unknown as {
  [key: symbol]: ProductionTrace | undefined
}
export function getEnvironmentTracing(): ProductionTrace | undefined {
  return environmentRegistry[environmentKey]
}

/** Read once during preload; changing environment variables later does not reconfigure live clients. */
export function enableTracingFromEnv(
  env: Readonly<Record<string, string | undefined>> = process.env,
): ProductionTrace | undefined {
  const environmentTracing = getEnvironmentTracing()
  if (environmentTracing && !environmentTracing.stats.closed)
    return environmentTracing
  if (!['1', 'true'].includes(env.CETANE_TRACE ?? '')) return undefined
  try {
    const number = (name: string) => {
      if (env[name] === undefined) return undefined
      if (!env[name]!.trim()) throw new Error('Empty numeric trace setting.')
      return Number(env[name])
    }
    const type = env.CETANE_TRACE_OUTPUT ?? 'stderr'
    let output: TraceExporterOptions
    if (type === 'file') {
      if (!env.CETANE_TRACE_FILE)
        throw new Error('CETANE_TRACE_FILE is required for file output.')
      output = {
        type,
        path: env.CETANE_TRACE_FILE.replaceAll('%p', String(process.pid)),
      }
    } else if (type === 'otlp') {
      if (!env.CETANE_TRACE_ENDPOINT)
        throw new Error('CETANE_TRACE_ENDPOINT is required for OTLP output.')
      let headers: Record<string, string> | undefined
      if (env.CETANE_TRACE_HEADERS) {
        const parsed: unknown = JSON.parse(env.CETANE_TRACE_HEADERS)
        if (
          !parsed ||
          typeof parsed !== 'object' ||
          Array.isArray(parsed) ||
          Object.values(parsed).some((v) => typeof v !== 'string')
        )
          throw new Error('Invalid trace headers.')
        headers = parsed as Record<string, string>
      }
      output = {
        type,
        endpoint: env.CETANE_TRACE_ENDPOINT,
        ...(headers ? { headers } : {}),
        ...(number('CETANE_TRACE_EXPORT_TIMEOUT_MS') !== undefined
          ? { timeoutMs: number('CETANE_TRACE_EXPORT_TIMEOUT_MS')! }
          : {}),
      }
    } else if (type === 'stderr' || type === 'stdout') output = { type }
    else throw new Error('Invalid trace output.')
    const parameters: ProductionTraceOptions = { output }
    const numbers = {
      CETANE_TRACE_SAMPLE_RATE: 'sampleRate',
      CETANE_TRACE_MAX_SPANS: 'maxSpans',
      CETANE_TRACE_MAX_RESOURCE_SAMPLES: 'maxResourceSamples',
      CETANE_TRACE_BATCH_SIZE: 'batchSize',
      CETANE_TRACE_FLUSH_INTERVAL_MS: 'flushIntervalMs',
      CETANE_TRACE_RESOURCE_INTERVAL_MS: 'resourceIntervalMs',
      CETANE_TRACE_SHUTDOWN_TIMEOUT_MS: 'shutdownTimeoutMs',
    } as const
    for (const [variable, field] of Object.entries(numbers)) {
      const value = number(variable)
      if (value !== undefined) parameters[field] = value
    }
    const service = env.CETANE_TRACE_SERVICE_NAME ?? env.OTEL_SERVICE_NAME
    if (service !== undefined) parameters.serviceName = service
    const controller = startTracing(parameters)
    environmentRegistry[environmentKey] = controller
    return controller
  } catch {
    // Configuration can contain file names, URLs and authentication headers.
    void writeTraceDiagnostic(
      '[cetane.trace] Invalid tracing configuration; tracing disabled.\n',
    ).catch(() => {})
    return undefined
  }
}
