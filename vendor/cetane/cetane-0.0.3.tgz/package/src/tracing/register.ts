import { enableTracingFromEnv } from './node.js'

// Opt-in server preload. Importing this entry without CETANE_TRACE=1 does nothing.
enableTracingFromEnv()
