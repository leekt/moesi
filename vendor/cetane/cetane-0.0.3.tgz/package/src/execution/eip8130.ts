import { estimateFeesPerGas } from '../actions/fees.js'
import {
  getAccountData,
  getAuthenticator,
} from '../accounts/internal/keystore.js'
import { signTransaction } from '../accounts/sign.js'
import { readDeploymentCode } from '../accounts/internal/deployment.js'
import { CetaneError } from '../errors.js'
import { scopeContext, traceAsync, traceSync } from '../internal/trace.js'
import type {
  Address,
  Execution,
  FeePayer,
  Fees,
  Hex,
  Signer,
} from '../types.js'
import {
  assertAddress,
  assertHex,
  fromQuantity,
  toQuantity,
  word,
} from '../utils/hex.js'
import { keccak256 } from '../utils/hash.js'
import { encodeRlp, rlpPrefix, toRlp, toRlpInteger } from '../utils/rlp.js'
import type { RlpValue } from '../utils/rlp.js'
import {
  changeFields,
  changeTag,
  formatAuthorization,
  k1,
  stubSignature,
} from './internal/keystore.js'
import type { AccountChange, WireFormat } from './internal/keystore.js'
import { assertStubCoverage } from './internal/sponsorship.js'
import { formatReceipt } from './receipt.js'
import type { RpcReceipt } from './receipt.js'
import { submitRaw } from './internal/submit.js'

export type {
  AccountChange,
  ConfigChange,
  InitialActor,
  WireFormat,
} from './internal/keystore.js'
export type Envelope = Fees & {
  chainId: number
  sender?: Address
  nonceKey: bigint
  nonce: bigint
  validAfter?: number
  validBefore?: number
  gas: bigint
  accountChanges?: readonly AccountChange[]
  calls: readonly (readonly { to: Address; value?: bigint; data: Hex }[])[]
  metadata?: Hex
  payer?: Address
  wireFormat?: WireFormat
}
const nonceFree = (1n << 256n) - 1n

function assertAccount(address: Address): void {
  assertAddress(address)
  if (BigInt(address) === 0n)
    throw new CetaneError('Account address must be nonzero.')
}

function validWindow(after = 0, before = 0): void {
  for (const value of [after, before]) {
    if (!Number.isSafeInteger(value) || value < 0)
      throw new CetaneError('Invalid validity timestamp.')
    word(BigInt(value), 8)
  }
  const milliseconds = (value: number) =>
    BigInt(value) * (value < 100_000_000_000 ? 1_000n : 1n)
  if (before !== 0 && milliseconds(before) < milliseconds(after))
    throw new CetaneError('validBefore must not precede validAfter.')
}

function fields(envelope: Envelope): RlpValue[] {
  if (!Number.isSafeInteger(envelope.chainId) || envelope.chainId <= 0)
    throw new CetaneError('Invalid chain ID.')
  word(envelope.nonceKey)
  word(envelope.nonce, 8)
  word(envelope.gas, 8)
  word(envelope.maxFeePerGas, 16)
  word(envelope.maxPriorityFeePerGas, 16)
  if (envelope.maxFeePerGas < envelope.maxPriorityFeePerGas)
    throw new CetaneError('Priority fee exceeds the fee cap.')
  validWindow(envelope.validAfter, envelope.validBefore)
  if (
    envelope.nonceKey === nonceFree &&
    (envelope.nonce !== 0n || !envelope.validBefore)
  )
    throw new CetaneError(
      'Nonce-free envelopes require sequence 0 and an expiry.',
    )
  for (const address of [envelope.sender, envelope.payer])
    if (address !== undefined) assertAccount(address)
  assertHex(envelope.metadata ?? '0x')
  return [
    toRlpInteger(envelope.chainId),
    envelope.sender ?? '0x',
    toRlpInteger(envelope.nonceKey),
    toRlpInteger(envelope.nonce),
    toRlpInteger(envelope.validAfter ?? 0),
    toRlpInteger(envelope.validBefore ?? 0),
    toRlpInteger(envelope.maxPriorityFeePerGas),
    toRlpInteger(envelope.maxFeePerGas),
    toRlpInteger(envelope.gas),
    changeFields(envelope.accountChanges ?? [], envelope.wireFormat),
    envelope.calls.map((phase) =>
      phase.map((call) => {
        assertAddress(call.to)
        assertHex(call.data)
        if (envelope.wireFormat === 'base-zenith') {
          word(call.value ?? 0n)
          return [call.to, toRlpInteger(call.value ?? 0n), call.data]
        }
        if (call.value !== undefined && call.value !== 0n)
          throw new CetaneError(
            'Draft calls cannot carry native value directly.',
          )
        return [call.to, call.data]
      }),
    ),
    envelope.metadata ?? '0x',
    envelope.payer ?? '0x',
  ]
}

/** Draft codec leaf; application actions use the configured execution adapter. */
export function serialize(
  envelope: Envelope,
  authorizations: { sender: Hex; payer?: Hex },
): Hex {
  assertHex(authorizations.sender)
  assertHex(authorizations.payer ?? '0x')
  if (!envelope.payer && authorizations.payer && authorizations.payer !== '0x')
    throw new CetaneError('A payer signature requires a payer account.')
  return `0x79${toRlp([...fields(envelope), authorizations.sender, authorizations.payer ?? '0x']).slice(2)}`
}
export function getSigningHash(envelope: Envelope, payerSender?: Address): Hex {
  const body = fields(envelope)
  if (payerSender) {
    assertAccount(payerSender)
    if (
      envelope.sender &&
      payerSender.toLowerCase() !== envelope.sender.toLowerCase()
    )
      throw new CetaneError(
        'Payer hash sender does not match the transaction sender.',
      )
    body[1] = payerSender
  }
  return keccak256(`0x${payerSender ? '7a' : '79'}${toRlp(body).slice(2)}`)
}

export function toRpc(
  envelope: Envelope,
  authorizations: { sender: Hex; payer?: Hex },
): Record<string, unknown> {
  return {
    type: '0x79',
    chainId: toQuantity(envelope.chainId),
    sender: envelope.sender,
    nonceKey: toQuantity(envelope.nonceKey),
    nonce: toQuantity(envelope.nonce),
    validAfter: toQuantity(envelope.validAfter ?? 0),
    validBefore: toQuantity(envelope.validBefore ?? 0),
    maxPriorityFeePerGas: toQuantity(envelope.maxPriorityFeePerGas),
    maxFeePerGas: toQuantity(envelope.maxFeePerGas),
    gas: toQuantity(envelope.gas),
    accountChanges: (envelope.accountChanges ?? []).map((change) => {
      const type = toQuantity(
        changeTag(change.type, envelope.wireFormat ?? 'draft'),
      )
      if (change.type === 'create')
        return {
          type,
          userSalt: change.salt,
          code: change.bytecode,
          initialActors: change.actors.map((actor) => ({
            ...actor,
            scope: toQuantity(actor.scope),
          })),
        }
      if (change.type === 'delegate') return { type, target: change.target }
      return {
        type,
        channel: toQuantity(change.channel),
        sequence: toQuantity(change.sequence),
        changes: change.changes.map((item) => ({
          changeType: toQuantity(item.type),
          payload: item.payload,
        })),
        signature: change.auth,
      }
    }),
    calls:
      envelope.wireFormat === 'base-zenith'
        ? envelope.calls.map((phase) =>
            phase.map((call) => ({
              to: call.to,
              value: toQuantity(call.value ?? 0n),
              data: call.data,
            })),
          )
        : envelope.calls,
    metadata: envelope.metadata ?? '0x',
    ...(envelope.payer ? { payer: envelope.payer } : {}),
    senderAuth: authorizations.sender,
    ...(authorizations.payer ? { payerAuth: authorizations.payer } : {}),
  }
}

async function sign(signer: Signer, hash: Hex): Promise<Hex> {
  return signer.sign({ hash })
}

export function createExecution(
  options: {
    payer?: FeePayer
    maxAuthenticationGas?: bigint
    metadata?: Hex
    wireFormat?: WireFormat
  } = {},
): Execution {
  options = {
    ...options,
    ...(options.payer ? { payer: { ...options.payer } } : {}),
  }
  const wireFormat = options.wireFormat ?? 'draft'
  changeTag('create', wireFormat)
  const maxAuthenticationGas = options.maxAuthenticationGas ?? 100_000n
  word(maxAuthenticationGas, 8)
  assertHex(options.metadata ?? '0x')
  return {
    nativeAA: '8130',
    async getNonce(context, account, key) {
      word(key)
      if (key === nonceFree)
        throw new CetaneError(
          'Nonce-free transactions require a dedicated replay policy.',
        )
      const nonce = fromQuantity(
        await context.request({
          method: 'eth_getTransactionCount',
          params: [
            account.address,
            'pending',
            ...(key === 0n ? [] : [toQuantity(key)]),
          ],
        }),
      )
      word(nonce, 8)
      return nonce
    },
    async prepare(context, parameters) {
      const account = parameters.account
      const data = getAccountData(account)
      const sender = getAuthenticator(account, parameters.authorization)
      const nonceKey = parameters.nonceKey ?? 0n
      word(nonceKey)
      if (nonceKey === nonceFree)
        throw new CetaneError(
          'Nonce-free transactions require a dedicated replay policy.',
        )
      validWindow(parameters.validAfter, parameters.validBefore)
      if (parameters.feeToken !== undefined)
        throw new CetaneError(
          'This execution module pays fees in the native currency.',
        )
      const sponsor =
        parameters.sponsor === false
          ? undefined
          : (context.sponsor ?? options.payer)
      if (parameters.sponsor === true && !sponsor)
        throw new CetaneError(
          'Sponsorship was requested, but no sponsor is configured.',
        )
      if (sponsor && 'request' in sponsor)
        throw new CetaneError(
          'This execution module requires a local fee payer.',
        )
      const payer = sponsor && 'account' in sponsor ? { ...sponsor } : undefined
      const payerAddress =
        payer?.account.address ??
        (sponsor && 'sign' in sponsor ? sponsor.address : undefined)
      if (sponsor && !payerAddress)
        throw new CetaneError('A fee payer account address is required.')
      if (payerAddress) assertAccount(payerAddress)
      const payerStub = sponsor
        ? payer
          ? getAuthenticator(payer.account, payer.authorization).stub
          : formatAuthorization(k1, stubSignature)
        : undefined
      const calls =
        wireFormat === 'base-zenith'
          ? parameters.calls.map((call) => ({
              to: call.to,
              value: call.value ?? 0n,
              data: call.data ?? '0x',
            }))
          : parameters.calls.some((call) => (call.value ?? 0n) !== 0n)
            ? data.valueCalls
              ? [
                  {
                    to: account.address,
                    data: context.trace
                      ? traceSync(context.trace, 'calls.encode', () =>
                          account.encodeCalls!(parameters.calls),
                        )
                      : account.encodeCalls!(parameters.calls),
                  },
                ]
              : undefined
            : parameters.calls.map((call) => ({
                to: call.to,
                data: call.data ?? '0x',
              }))
      if (!calls)
        throw new CetaneError(
          'Value transfers require the configured account execution ABI.',
        )
      const [nonce, fees, code] = await Promise.all([
        context.trace
          ? parameters.nonce !== undefined
            ? traceSync(context.trace, 'nonce.read', () => parameters.nonce!, {
                source: 'provided',
              })
            : traceAsync(
                context.trace,
                'nonce.read',
                (trace) =>
                  this.getNonce(
                    scopeContext(context, trace),
                    account,
                    nonceKey,
                  ),
                { source: 'rpc' },
              )
          : (parameters.nonce ?? this.getNonce(context, account, nonceKey)),
        estimateFeesPerGas(context, parameters),
        data.creation
          ? context.trace
            ? traceAsync(context.trace, 'deployment', (trace) =>
                readDeploymentCode(
                  scopeContext(context, trace),
                  account.address,
                  'pending',
                ),
              )
            : readDeploymentCode(context, account.address, 'pending')
          : undefined,
      ])
      const envelope: Envelope = {
        chainId: context.chain.id,
        sender: account.address,
        nonceKey,
        nonce,
        ...fees,
        gas: parameters.gas ?? 0n,
        calls: [calls],
        accountChanges: data.creation && code === '0x' ? [data.creation] : [],
        wireFormat,
        ...(payerAddress ? { payer: payerAddress } : {}),
        ...(parameters.validAfter !== undefined
          ? { validAfter: parameters.validAfter }
          : {}),
        ...(parameters.validBefore !== undefined
          ? { validBefore: parameters.validBefore }
          : {}),
        ...(options.metadata !== undefined
          ? { metadata: options.metadata }
          : {}),
      }
      const body = context.trace
        ? traceSync(context.trace, 'encoding', () => fields(envelope))
        : fields(envelope)
      const stub = {
        sender: sender.stub,
        ...(payerStub ? { payer: payerStub } : {}),
      }
      if (parameters.gas === undefined) {
        const request = toRpc(envelope, stub)
        if (wireFormat === 'base-zenith' && sender.actorId)
          request.senderActorId = sender.actorId
        delete request.gas
        envelope.gas = fromQuantity(
          await (context.trace
            ? traceAsync(context.trace, 'gas.estimate', (trace) =>
                scopeContext(context, trace).request<Hex>({
                  method: 'eth_estimateGas',
                  params: [request],
                }),
              )
            : context.request<Hex>({
                method: 'eth_estimateGas',
                params: [request],
              })),
        )
        word(envelope.gas, 8)
        body[8] = toRlpInteger(envelope.gas)
      } else if (context.trace) {
        traceSync(context.trace, 'gas.budget', () => parameters.gas, {
          source: 'provided',
        })
      }
      // The body is a private, validated snapshot. Reuse its encoded list payload
      // when authorization bytes become available instead of walking it again.
      const payload = context.trace
        ? traceSync(context.trace, 'encoding', () =>
            body.map(encodeRlp).join(''),
          )
        : body.map(encodeRlp).join('')
      const encoded = rlpPrefix(payload.length / 2, 192) + payload
      function authorized(sender: Hex, payer: Hex = '0x'): Hex {
        const tail = encodeRlp(sender) + encodeRlp(payer)
        return `0x79${rlpPrefix((payload.length + tail.length) / 2, 192)}${payload}${tail}`
      }
      const senderHash = context.trace
        ? traceSync(
            context.trace,
            'hash.signing',
            () => keccak256(`0x79${encoded}`),
            { source: 'sender' },
          )
        : keccak256(`0x79${encoded}`)
      const payerHash = sponsor
        ? context.trace
          ? traceSync(
              context.trace,
              'hash.signing',
              () => keccak256(`0x7a${encoded}`),
              { source: 'payer' },
            )
          : keccak256(`0x7a${encoded}`)
        : undefined
      const gas = envelope.gas + (sponsor ? maxAuthenticationGas : 0n)
      const maxSize = context.chain.limits?.maxTransactionSize
      if (
        maxSize !== undefined &&
        (authorized(stub.sender, stub.payer).length - 2) / 2 > maxSize
      )
        throw new CetaneError('Transaction exceeds the chain size cap.')
      let raw: Hex | undefined
      return {
        transaction: {
          chainId: context.chain.id,
          from: account.address,
          calls: parameters.calls,
          nonce,
          executionGas: envelope.gas,
          gas,
          ...fees,
          maxFee: gas * fees.maxFeePerGas,
        },
        async sign({ signer, trace } = {}) {
          const [senderAuth, payerAuth] = await Promise.all([
            trace
              ? traceAsync(trace, 'sign.sender', () =>
                  signTransaction(account, parameters, senderHash, signer),
                )
              : signTransaction(account, parameters, senderHash, signer),
            payer
              ? trace
                ? traceAsync(trace, 'sign.payer', () =>
                    signTransaction(
                      payer.account,
                      {
                        signer: payer.signer,
                        ...(payer.authorization
                          ? { authorization: payer.authorization }
                          : {}),
                      },
                      payerHash!,
                    ),
                  )
                : signTransaction(
                    payer.account,
                    {
                      signer: payer.signer,
                      ...(payer.authorization
                        ? { authorization: payer.authorization }
                        : {}),
                    },
                    payerHash!,
                  )
              : sponsor && 'sign' in sponsor
                ? trace
                  ? traceAsync(trace, 'sign.payer', () =>
                      sign(sponsor, payerHash!).then((signature) =>
                        formatAuthorization(k1, signature),
                      ),
                    )
                  : sign(sponsor, payerHash!).then((signature) =>
                      formatAuthorization(k1, signature),
                    )
                : undefined,
          ])
          assertHex(senderAuth)
          assertStubCoverage(
            sender.stub,
            senderAuth,
            'Sender authorization',
            false,
          )
          if (payerAuth) {
            assertHex(payerAuth)
            assertStubCoverage(
              payerStub!,
              payerAuth,
              'Payer authorization',
              false,
            )
          }
          raw = trace
            ? traceSync<Hex>(trace, 'serialization', () =>
                authorized(senderAuth, payerAuth),
              )
            : authorized(senderAuth, payerAuth)
          if (maxSize !== undefined && (raw.length - 2) / 2 > maxSize)
            throw new CetaneError('Transaction exceeds the chain size cap.')
        },
        async submit({ trace } = {}) {
          if (!raw)
            throw new CetaneError(
              'Transaction must be signed before submission.',
            )
          return submitRaw(scopeContext(context, trace).relay, raw, trace)
        },
      }
    },
    async getReceipt(context, hash) {
      const receipt = await context.request<RpcReceipt | null>({
        method: 'eth_getTransactionReceipt',
        params: [hash],
      })
      return receipt ? formatReceipt(receipt, hash) : null
    },
  }
}
