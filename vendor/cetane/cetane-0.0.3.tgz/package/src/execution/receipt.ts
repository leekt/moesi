import { CetaneError } from '../errors.js'
import type { Hash, Hex, Log, TransactionReceipt } from '../types.js'
import { assertAddress, assertHex, fromQuantity } from '../utils/hex.js'

export type RpcReceipt = {
  transactionHash: Hash
  blockHash: Hash
  blockNumber: Hex
  status: Hex
  gasUsed: Hex
  effectiveGasPrice: Hex
  logs: {
    address: Hex
    data: Hex
    topics: Hex[]
    blockNumber: Hex | null
    transactionHash: Hash | null
    logIndex: Hex | null
  }[]
}
export function formatReceipt(
  receipt: RpcReceipt,
  id: Hash,
): TransactionReceipt {
  assertHex(receipt.transactionHash, 32)
  assertHex(receipt.blockHash, 32)
  if (receipt.status !== '0x0' && receipt.status !== '0x1')
    throw new CetaneError('Invalid receipt status.')
  const logs: Log[] = receipt.logs.map((log) => {
    assertAddress(log.address)
    assertHex(log.data)
    for (const topic of log.topics) assertHex(topic, 32)
    return {
      ...log,
      blockNumber:
        log.blockNumber === null ? null : fromQuantity(log.blockNumber),
      logIndex:
        log.logIndex === null ? null : Number(fromQuantity(log.logIndex)),
    }
  })
  return {
    id,
    transactionHash: receipt.transactionHash,
    blockHash: receipt.blockHash,
    blockNumber: fromQuantity(receipt.blockNumber),
    status: receipt.status === '0x1' ? 'success' : 'reverted',
    gasUsed: fromQuantity(receipt.gasUsed),
    effectiveGasPrice: fromQuantity(receipt.effectiveGasPrice),
    logs,
  }
}
