/** Opt-in Node HTTP/1.1 transport with bounded requests and explicit shutdown. */
import { Agent as HttpAgent, request as httpRequest } from 'node:http'
import { Agent as HttpsAgent, request as httpsRequest } from 'node:https'
import type { ClientRequest } from 'node:http'
import { StringDecoder } from 'node:string_decoder'
import { urlToHttpOptions } from 'node:url'
import { RpcError, TimeoutError, TransportError } from '../../errors.js'
import type { RequestOptions, RpcRequest } from '../../types.js'
import { validateReply } from '../../internal/rpcReply.js'

export type HttpNodeOptions = {
  timeout?: number
  maxSockets?: number
  maxPending?: number
  maxResponseBytes?: number
  headers?: HeadersInit
  ca?: string | Uint8Array
}

export function createNodeHttp(address: string, options: HttpNodeOptions = {}) {
  const url = new URL(address)
  if (url.protocol !== 'http:' && url.protocol !== 'https:')
    throw new TransportError('Unsupported URL protocol.')
  const timeout = options.timeout ?? 10_000
  if (!Number.isFinite(timeout) || timeout <= 0)
    throw new TransportError('HTTP timeout must be positive.')
  const maxSockets = options.maxSockets ?? 32
  const maxPending = options.maxPending ?? 1024
  const maxResponseBytes = options.maxResponseBytes ?? 16 * 1024 * 1024
  for (const [name, value] of Object.entries({
    maxSockets,
    maxPending,
    maxResponseBytes,
  }))
    if (!Number.isSafeInteger(value) || value <= 0)
      throw new TransportError(`${name} must be a positive safe integer.`)
  const secure = url.protocol === 'https:'
  if (!secure && options.ca !== undefined)
    throw new TransportError('A custom CA requires HTTPS.')
  const normalized = new Headers(options.headers)
  for (const name of [
    'content-length',
    'transfer-encoding',
    'connection',
    'upgrade',
    'host',
  ])
    if (normalized.has(name))
      throw new TransportError(`The transport manages the ${name} header.`)
  if (
    normalized.has('accept-encoding') &&
    normalized.get('accept-encoding') !== 'identity'
  )
    throw new TransportError('This transport supports identity encoding only.')
  normalized.set('accept-encoding', 'identity')
  if (!normalized.has('content-type'))
    normalized.set('content-type', 'application/json')
  const headers = Object.fromEntries(normalized.entries())
  const agent = new (secure ? HttpsAgent : HttpAgent)({
    keepAlive: true,
    maxSockets,
    ...(options.ca === undefined
      ? {}
      : {
          ca:
            typeof options.ca === 'string'
              ? options.ca
              : Buffer.from(options.ca),
        }),
  })
  const request = secure ? httpsRequest : httpRequest
  const endpoint = {
    ...urlToHttpOptions(url),
    agent,
    method: 'POST',
    headers,
  }
  let id = 0
  let closed = false
  let retiring = 0
  const pending = new Set<() => void>()
  return {
    close() {
      if (closed) return
      closed = true
      for (const cancel of pending) cancel()
      agent.destroy()
    },
    request<T>(
      { method, params = [] }: RpcRequest,
      options?: RequestOptions,
      rawBody?: string,
    ) {
      return new Promise<T>((resolve, reject) => {
        const signal = options?.signal
        if (closed) return reject(new TransportError('Transport is closed.'))
        if (signal?.aborted) return reject(signal.reason)
        if (pending.size + retiring >= maxPending)
          return reject(
            new TransportError('Transport request capacity exceeded.'),
          )
        const requestId = ++id
        let req: ClientRequest | undefined
        let settled = false
        let timer: ReturnType<typeof setTimeout> | undefined
        const finish = (error: unknown, value?: T) => {
          if (settled) return
          settled = true
          // Agent retains a cancelled socket waiter until it emits close.
          // Keep charging that retained object against capacity in the meantime.
          if (req && !req.socket) {
            retiring++
            req.once('close', () => {
              retiring--
            })
          }
          pending.delete(shutdown)
          clearTimeout(timer)
          signal?.removeEventListener('abort', abort)
          if (error !== undefined) reject(error)
          else resolve(value as T)
        }
        const abort = () => {
          finish(signal!.reason)
          req?.destroy()
        }
        const shutdown = () => {
          finish(new TransportError('Transport is closed.'))
          req?.destroy()
        }
        // Reserve before serialization: a caller's toJSON can reenter request/close.
        pending.add(shutdown)
        let body: string
        try {
          body =
            rawBody ??
            JSON.stringify({ jsonrpc: '2.0', id: requestId, method, params })
          if (settled) return
          if (signal?.aborted) return abort()
          req = request(endpoint)
          req.setHeader('content-length', Buffer.byteLength(body))
        } catch (cause) {
          finish(new TransportError(`Request failed for ${method}.`, { cause }))
          return
        }
        req.on('error', (cause) =>
          finish(
            new TransportError(`Request failed for ${method}.`, { cause }),
          ),
        )
        req.on('response', (response) => {
          response.on('error', (cause) =>
            finish(
              new TransportError(`Response failed for ${method}.`, { cause }),
            ),
          )
          if (
            !response.statusCode ||
            response.statusCode < 200 ||
            response.statusCode >= 300
          ) {
            finish(
              new TransportError(`HTTP ${response.statusCode} for ${method}.`, {
                ...(response.statusCode === undefined
                  ? {}
                  : { status: response.statusCode }),
              }),
            )
            response.destroy()
            return
          }
          const encoding = response.headers['content-encoding']
            ?.trim()
            .toLowerCase()
          if (encoding && encoding !== 'identity') {
            finish(
              new TransportError(
                `Unsupported HTTP content encoding: ${encoding}.`,
              ),
            )
            response.destroy()
            return
          }
          const decoder = new StringDecoder('utf8')
          let text = ''
          let responseBytes = 0
          response.on('data', (chunk: Buffer) => {
            if (settled) return
            responseBytes += chunk.length
            if (responseBytes > maxResponseBytes) {
              finish(new TransportError('HTTP response size limit exceeded.'))
              response.destroy()
              req?.destroy()
              return
            }
            text += decoder.write(chunk)
          })
          response.on('end', () => {
            if (settled) return
            try {
              text += decoder.end()
              // Match Fetch's UTF-8 BOM handling.
              const data: unknown = JSON.parse(
                text.charCodeAt(0) === 0xfeff ? text.slice(1) : text,
              )
              if (rawBody !== undefined) finish(undefined, data as T)
              else {
                const reply = validateReply(data, requestId, method)
                if (reply.error) throw new RpcError(method, reply.error)
                finish(undefined, reply.result as T)
              }
            } catch (cause) {
              finish(
                cause instanceof RpcError || cause instanceof TransportError
                  ? cause
                  : new TransportError(`Request failed for ${method}.`, {
                      cause,
                    }),
              )
            }
          })
        })
        timer = setTimeout(() => {
          finish(new TimeoutError(`${method} timed out.`))
          req?.destroy()
        }, timeout)
        signal?.addEventListener('abort', abort, { once: true })
        req.end(body)
      })
    },
  }
}
