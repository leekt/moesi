/** Opt-in Node HTTP/1.1 transport with bounded requests and explicit shutdown. */
import type { Transport, RpcRequest, RequestOptions } from '../types.js'
import { createNodeHttp, type HttpNodeOptions } from './internal/nodeHttp.js'

export type { HttpNodeOptions } from './internal/nodeHttp.js'

export function httpNode(
  address: string,
  options: HttpNodeOptions = {},
): Transport & { close(): void } {
  const connection = createNodeHttp(address, options)
  return {
    close: connection.close,
    request<T>(rpc: RpcRequest, requestOptions?: RequestOptions) {
      return connection.request<T>(rpc, requestOptions)
    },
  }
}
