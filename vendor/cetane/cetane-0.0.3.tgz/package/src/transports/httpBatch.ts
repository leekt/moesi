import { TransportError } from '../errors.js'
import type { Transport, RpcRequest, RequestOptions } from '../types.js'
import { http, type HttpOptions } from './http.js'
import { createReadBatch } from '../internal/readBatch.js'

export type HttpBatchOptions = HttpOptions & {
  /** Maximum calls per HTTP request (2–1024, default 20). */
  maxSize?: number
  /** Optional bound on retained logical calls, including direct writes. Rejects excess before serialization. */
  maxPending?: number
}

/** Opt-in read batching for compatible providers. Writes are never batched or retried. */
export function httpBatch(
  url: string,
  options: HttpBatchOptions = {},
): Transport {
  const maximum = options.maxPending
  if (maximum !== undefined && (!Number.isSafeInteger(maximum) || maximum < 1))
    throw new TransportError(
      'HTTP batch maxPending must be a positive integer.',
    )
  const direct = http(url, options)
  const fetch = options.fetch ?? globalThis.fetch
  const headers = new Headers(options.headers)
  if (!headers.has('content-type'))
    headers.set('content-type', 'application/json')
  const batch = createReadBatch(
    direct,
    async (body, signal) => {
      const response = await fetch(url, {
        method: 'POST',
        headers,
        signal,
        body,
      })
      if (!response.ok) {
        void response.body?.cancel().catch(() => {})
        throw new TransportError(
          `HTTP ${response.status} for JSON-RPC batch.`,
          { status: response.status },
        )
      }
      return response.json()
    },
    options,
  )
  if (maximum === undefined) return batch
  let pending = 0
  return {
    request<T>(request: RpcRequest, options?: RequestOptions): Promise<T> {
      const signal = options?.signal
      if (signal?.aborted) return Promise.reject(signal.reason)
      if (pending >= maximum)
        return Promise.reject(
          new TransportError('Transport request capacity exceeded.'),
        )
      pending++
      let retired = false
      return batch.request<T>(request, options, () => {
        if (retired) return
        retired = true
        pending--
      })
    },
  }
}
