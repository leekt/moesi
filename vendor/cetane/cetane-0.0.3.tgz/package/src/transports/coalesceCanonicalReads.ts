import { clearImmediate, setImmediate } from 'node:timers'
import { createCanonicalCohort } from '../internal/canonicalCohort.js'
import type { Transport } from '../types.js'
export type {
  CanonicalReadStats,
  CanonicalReadTransport,
} from '../internal/canonicalCohort.js'

export type CoalesceCanonicalReadsOptions = {
  /** Maximum logical canonical reads awaiting completion. Default 1024. */
  maxPending?: number
}

/**
 * Opt-in Node wrapper for same-turn eth_getBlockByNumber(quantity, false) reads.
 * Never shares an already-dispatched request or caches a completed response.
 * Adds a setImmediate scheduling turn. Caller retains ownership of base.close().
 * Trace RPC spans remain logical calls; stats().dispatched counts base invocations.
 */
export function coalesceCanonicalReads(
  base: Transport,
  options: CoalesceCanonicalReadsOptions = {},
) {
  return createCanonicalCohort(
    base,
    (work) => {
      const timer = setImmediate(work)
      return () => clearImmediate(timer)
    },
    options,
  )
}
