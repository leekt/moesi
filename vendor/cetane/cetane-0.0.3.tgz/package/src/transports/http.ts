import { RpcError, TimeoutError, TransportError } from '../errors.js'
import type { Transport, RpcRequest, RequestOptions } from '../types.js'

export type HttpOptions = {
  fetch?: typeof globalThis.fetch
  timeout?: number
  headers?: HeadersInit
}

/** One request, one round trip. Writes are never automatically retried. */
export function http(url: string, options: HttpOptions = {}): Transport {
  const fetch = options.fetch ?? globalThis.fetch
  const timeout = options.timeout ?? 10_000
  if (!Number.isFinite(timeout) || timeout <= 0)
    throw new TransportError('HTTP timeout must be positive.')
  const headers = new Headers(options.headers)
  if (!headers.has('content-type'))
    headers.set('content-type', 'application/json')
  let id = 0
  return {
    async request<T>(
      { method, params = [] }: RpcRequest,
      requestOptions?: RequestOptions,
    ): Promise<T> {
      const requestId = ++id
      const controller = new AbortController()
      const signal = requestOptions?.signal
      const abort = () => controller.abort(signal?.reason)
      signal?.throwIfAborted()
      signal?.addEventListener('abort', abort, { once: true })
      const timer = setTimeout(
        () => controller.abort(new TimeoutError(`${method} timed out.`)),
        timeout,
      )
      try {
        const response = await fetch(url, {
          method: 'POST',
          headers,
          signal: controller.signal,
          body: JSON.stringify({
            jsonrpc: '2.0',
            id: requestId,
            method,
            params,
          }),
        })
        if (!response.ok) {
          // An unread error body can occupy a pooled connection until GC.
          void response.body?.cancel().catch(() => {})
          throw new TransportError(`HTTP ${response.status} for ${method}.`, {
            status: response.status,
          })
        }
        const data = (await response.json()) as Record<string, unknown>
        if (
          !data ||
          data.jsonrpc !== '2.0' ||
          data.id !== requestId ||
          'result' in data === 'error' in data
        )
          throw new TransportError(`Invalid JSON-RPC response for ${method}.`)
        if ('error' in data) {
          const error = data.error as { code: number; message: string }
          if (
            !error ||
            !Number.isInteger(error.code) ||
            typeof error.message !== 'string'
          )
            throw new TransportError(`Invalid JSON-RPC error for ${method}.`)
          throw new RpcError(method, error)
        }
        return data.result as T
      } catch (error) {
        if (controller.signal.aborted) throw controller.signal.reason
        if (error instanceof RpcError || error instanceof TransportError)
          throw error
        throw new TransportError(`Request failed for ${method}.`, {
          cause: error,
        })
      } finally {
        clearTimeout(timer)
        signal?.removeEventListener('abort', abort)
      }
    },
  }
}
