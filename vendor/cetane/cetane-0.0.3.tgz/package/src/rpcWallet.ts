import { createClient } from './client.js'
import { CetaneError } from './errors.js'
import { createExecution, isEvmExecution } from './execution/evm.js'
import type { Account, Address, Chain, Hex, Transport } from './types.js'
import { assertAddress, assertHex, toQuantity } from './utils/hex.js'

/** A wallet-owned EOA. Signing/fees/nonce selection belong to its RPC provider. */
export function createRpcWalletClient(parameters: {
  chain: Chain
  transport: Transport
  account: Address
}) {
  assertAddress(parameters.account)
  if (
    (parameters.chain.nativeAA !== undefined &&
      parameters.chain.nativeAA !== false) ||
    parameters.chain.account ||
    (parameters.chain.execution && !isEvmExecution(parameters.chain.execution))
  )
    throw new CetaneError('RPC wallets require an ordinary EVM chain.')
  const account = Object.freeze({ address: parameters.account })
  const client = createClient({
    chain: {
      ...parameters.chain,
      nativeAA: false,
      execution: parameters.chain.execution ?? createExecution(),
    },
    transport: parameters.transport,
    account,
  })
  return Object.freeze({
    ...client,
    async sendTransaction(input: {
      account?: Account
      to: Address
      data?: Hex
      value?: bigint
    }): Promise<Hex> {
      if (
        input.account &&
        input.account.address.toLowerCase() !== account.address.toLowerCase()
      )
        throw new CetaneError('RPC wallet account mismatch.')
      assertAddress(input.to)
      if (input.data !== undefined) assertHex(input.data)
      const transaction = {
        from: account.address,
        to: input.to,
        ...(input.data === undefined ? {} : { data: input.data }),
        ...(input.value === undefined
          ? {}
          : { value: toQuantity(input.value) }),
      }
      const hash = await client.request<Hex>({
        method: 'eth_sendTransaction',
        params: [transaction],
      })
      assertHex(hash, 32)
      return hash
    },
  })
}
