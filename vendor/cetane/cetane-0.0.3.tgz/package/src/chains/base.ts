import { defineChain } from '../client.js'
import { mainnet } from './mainnet.js'

export const base = defineChain({
  ...mainnet,
  id: 8453,
  name: 'Base',
  blockTime: 2_000,
  pollingInterval: 250,
  limits: { maxGas: 16_777_216n, maxTransactionSize: 130_000 },
  fees: { minPriorityFeePerGas: 1_000_000n },
})
