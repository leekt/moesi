import { defineChain } from '../client.js'
import { defineAccount } from '../accounts/kernel.js'
import { createExecution } from '../execution/erc4337.js'
import type { Chain } from '../types.js'
import type { RelayPolicy } from '../relays/bundle.js'

/** Infrastructure profile; applications keep using ordinary account and transaction actions. */
export function withKernel(
  chain: Chain,
  options: NonNullable<Parameters<typeof defineAccount>[0]> & {
    gas?: NonNullable<Parameters<typeof createExecution>[0]>['gas']
    relay?: RelayPolicy
  } = {},
) {
  return defineChain({
    ...chain,
    account: defineAccount(options),
    execution: createExecution({
      version: options.version === '4' ? '0.9' : '0.7',
      ...(options.gas ? { gas: options.gas } : {}),
      ...(options.relay?.receiptWait !== undefined
        ? { receiptWait: options.relay.receiptWait }
        : {}),
    }),
    ...(options.relay?.fees
      ? { fees: { ...chain.fees, estimate: options.relay.fees } }
      : {}),
  })
}
