import type { TraceSink, TraceSpan } from './trace/types.js'

export type { TraceContext, TraceSink, TraceSpan } from './trace/types.js'

export type TraceDistribution = Readonly<{
  p50: number
  p95: number
  p99: number
  min: number
  max: number
}>

export type TraceStageSummary = Readonly<{
  name: string
  attributes?: TraceSpan['attributes']
  count: number
  errors: number
  /** Sum of inclusive durations; parallel work can make this exceed wall time. */
  totalMs: number
  /** Sum after removing each span's direct-child interval union. Not a CPU measurement. */
  selfMs: number
  inclusive: TraceDistribution
  exclusive: TraceDistribution
}>

export type TraceSummary = Readonly<{
  spans: number
  droppedSpans: number
  operations: number
  /** Elapsed window covered by retained spans, including gaps between operations. */
  durationMs: number
  stages: readonly TraceStageSummary[]
}>

export type ChromeTrace = {
  displayTimeUnit: 'ms'
  traceEvents: {
    name: string
    cat: 'cetane'
    ph: 'X'
    pid: number
    tid: number
    /** Chrome trace timestamps and durations are microseconds. */
    ts: number
    dur: number
    args: Record<string, string | number | boolean>
  }[]
  metadata: { droppedSpans: number; clock: 'monotonic'; units: 'microseconds' }
}

export type TraceRecorder = {
  readonly sink: TraceSink
  /** A frozen snapshot, so clearing or future events cannot mutate a saved report. */
  readonly spans: readonly TraceSpan[]
  readonly droppedSpans: number
  clear(): void
  summary(): TraceSummary
  /** JSON.stringify this object and open it in Perfetto or Chrome's trace viewer. */
  toChromeTrace(): ChromeTrace
}

function distribution(values: number[]): TraceDistribution {
  values.sort((a, b) => a - b)
  const at = (p: number) => values[Math.ceil(values.length * p) - 1]!
  return {
    p50: at(0.5),
    p95: at(0.95),
    p99: at(0.99),
    min: values[0]!,
    max: values[values.length - 1]!,
  }
}

/** Wall time outside direct children, clipping overlaps and children that settle after a parent. */
function exclusiveDuration(
  span: TraceSpan,
  children: readonly TraceSpan[],
): number {
  if (!children.length) return span.durationMs
  const end = span.startMs + span.durationMs
  const intervals = children
    .map(
      (child) =>
        [
          Math.max(span.startMs, child.startMs),
          Math.min(end, child.startMs + child.durationMs),
        ] as const,
    )
    .filter(([start, finish]) => finish > start)
    .sort((a, b) => a[0] - b[0])
  let covered = 0
  let previousEnd = span.startMs
  for (const [start, finish] of intervals) {
    if (finish <= previousEnd) continue
    covered += finish - Math.max(start, previousEnd)
    previousEnd = finish
  }
  return Math.max(0, span.durationMs - covered)
}

function summarize(
  spans: readonly TraceSpan[],
  droppedSpans: number,
): TraceSummary {
  const children = new Map<string, TraceSpan[]>()
  const operations = new Set<number>()
  let earliest = Infinity
  let latest = -Infinity
  for (const span of spans) {
    operations.add(span.operationId)
    earliest = Math.min(earliest, span.startMs)
    latest = Math.max(latest, span.startMs + span.durationMs)
    if (span.parentId !== undefined) {
      const key = `${span.operationId}:${span.parentId}`
      const siblings = children.get(key)
      if (siblings) siblings.push(span)
      else children.set(key, [span])
    }
  }
  type Group = {
    name: string
    attributes?: TraceSpan['attributes']
    errors: number
    inclusive: number[]
    exclusive: number[]
  }
  const groups = new Map<string, Group>()
  for (const span of spans) {
    const attributes =
      span.name === 'rpc'
        ? {
            ...(span.attributes?.endpoint !== undefined
              ? { endpoint: span.attributes.endpoint }
              : {}),
            ...(span.attributes?.method !== undefined
              ? { method: span.attributes.method }
              : {}),
          }
        : undefined
    const key = JSON.stringify([span.name, attributes])
    let group = groups.get(key)
    if (!group) {
      group = {
        name: span.name,
        ...(attributes ? { attributes } : {}),
        errors: 0,
        inclusive: [],
        exclusive: [],
      }
      groups.set(key, group)
    }
    if (span.status === 'error') group.errors++
    group.inclusive.push(span.durationMs)
    group.exclusive.push(
      exclusiveDuration(
        span,
        children.get(`${span.operationId}:${span.id}`) ?? [],
      ),
    )
  }
  return {
    spans: spans.length,
    droppedSpans,
    operations: operations.size,
    durationMs: spans.length ? latest - earliest : 0,
    stages: [...groups.values()]
      .map((group) => ({
        name: group.name,
        ...(group.attributes ? { attributes: group.attributes } : {}),
        count: group.inclusive.length,
        errors: group.errors,
        totalMs: group.inclusive.reduce((sum, duration) => sum + duration, 0),
        selfMs: group.exclusive.reduce((sum, duration) => sum + duration, 0),
        inclusive: distribution(group.inclusive),
        exclusive: distribution(group.exclusive),
      }))
      .sort((a, b) => b.inclusive.p95 - a.inclusive.p95),
  }
}

/** Bounded, portable diagnostics. Collection is opt-in; retained timings include instrumentation cost. */
export function createTraceRecorder({
  maxSpans = 10_000,
}: { maxSpans?: number } = {}): TraceRecorder {
  if (!Number.isSafeInteger(maxSpans) || maxSpans < 0)
    throw new RangeError('Trace maxSpans must be a nonnegative safe integer.')
  const spans: TraceSpan[] = []
  let droppedSpans = 0
  return {
    sink(span) {
      if (spans.length >= maxSpans) {
        droppedSpans++
        return
      }
      spans.push(
        Object.freeze({
          ...span,
          ...(span.attributes
            ? { attributes: Object.freeze({ ...span.attributes }) }
            : {}),
        }),
      )
    },
    get spans() {
      return Object.freeze([...spans])
    },
    get droppedSpans() {
      return droppedSpans
    },
    clear() {
      spans.length = 0
      droppedSpans = 0
    },
    summary() {
      return summarize(spans, droppedSpans)
    },
    toChromeTrace() {
      const laneEnds: number[] = []
      const ordered = [...spans].sort(
        (a, b) => a.startMs - b.startMs || b.durationMs - a.durationMs,
      )
      return {
        displayTimeUnit: 'ms',
        traceEvents: ordered.map((span) => {
          // Reuse idle lanes across operations. Overlapping asynchronous spans
          // never form misleading synchronous stacks in the trace viewer.
          let lane = laneEnds.findIndex((end) => end <= span.startMs)
          if (lane === -1) lane = laneEnds.length
          laneEnds[lane] = span.startMs + span.durationMs
          return {
            name: span.name,
            cat: 'cetane',
            ph: 'X',
            pid: 1,
            tid: lane + 1,
            ts: span.startMs * 1_000,
            dur: span.durationMs * 1_000,
            args: {
              ...span.attributes,
              operationId: span.operationId,
              spanId: span.id,
              ...(span.parentId !== undefined
                ? { parentId: span.parentId }
                : {}),
              status: span.status,
            },
          }
        }),
        metadata: { droppedSpans, clock: 'monotonic', units: 'microseconds' },
      }
    },
  }
}
