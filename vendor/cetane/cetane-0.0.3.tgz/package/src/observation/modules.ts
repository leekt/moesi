import { parseAbi } from 'abitype'
import { readKernelModules } from '../accounts/kernelRead.js'
import { createReadBudget } from '../internal/readBudget.js'
import type { ReadBudget } from '../internal/readBudget.js'
import type { Address, Client, Hex, Request } from '../types.js'
import {
  decodeEventLog,
  decodeFunctionData,
  decodeFunctionResult,
  encodeFunctionData,
} from '../utils/abi.js'
import {
  assertAddress,
  assertHex,
  fromQuantity,
  toQuantity,
} from '../utils/hex.js'

export type ModuleInventoryEntry =
  | { kind: 'root'; id: Hex }
  | { kind: 'validator' | 'executor'; address: Address }
  | { kind: 'fallback'; selector: Hex; address: Address }
  | {
      kind: 'permission'
      id: Hex
      signer: Address
      policies: readonly Address[]
    }
  | { kind: 'hook'; context: Hex; address: Address }
export type ModuleInventoryInput = {
  profile: 'kernel-0.4.0'
  chainId: number
  account: Address
  snapshot: { blockNumber: string; blockHash: Hex }
  fromBlock: string
  declared: readonly ModuleInventoryEntry[]
  budget?: ReadBudget
}
export type ModuleInventory = {
  profile: 'kernel-0.4.0'
  account: Address
  snapshot: { chainId: number; blockNumber: string; blockHash: Hex }
  entries: readonly ModuleInventoryEntry[]
  checked: readonly string[]
  history: {
    fromBlock: string
    toBlock: string
    nextBlock: string
    complete: boolean
    counts: readonly {
      type: string
      address: Address
      installed: number
      uninstalled: number
    }[]
  }
  complete: boolean
  reason: 'partial-history' | 'unknown-context' | 'budget' | null
}
export class ModuleInventoryError extends Error {
  readonly code:
    | 'invalid_inventory_input'
    | 'inventory_chain_mismatch'
    | 'inventory_not_canonical'
    | 'invalid_inventory_response'
  constructor(code: ModuleInventoryError['code']) {
    super(code)
    this.name = 'ModuleInventoryError'
    this.code = code
  }
}
const abi = /* @__PURE__ */ parseAbi([
  'function root() view returns (bytes21)',
  'function validationInfo(bytes21 vId) view returns ((uint32 nonce,bool installed,address scopedExecutionHook,address signer,address[] policies))',
  'function isModuleInstalled(uint256 moduleType,address module,bytes context) view returns (bool)',
  'function executorConfig(address executor) view returns ((bool installed,address scopedExecutionHook))',
  'function selectorConfig(bytes4 selector) view returns ((address target,bytes1 callType,address scopedExecutionHook))',
  'event ModuleInstalled(uint256 moduleType,address module)',
  'event ModuleUninstalled(uint256 moduleType,address module)',
])
const zero = '0x0000000000000000000000000000000000000000'
const entryKey = (entry: ModuleInventoryEntry) =>
  entry.kind === 'root'
    ? 'root'
    : entry.kind === 'permission'
      ? `permission:${entry.id}`
      : entry.kind === 'fallback'
        ? `fallback:${entry.selector}`
        : entry.kind === 'hook'
          ? `hook:${entry.context}`
          : `${entry.kind}:${entry.address}`

/** Read-only Kernel 0.4.0 inventory; no account construction, credentials, signing or submission. */
export async function readAccountModuleInventory(
  request: Request,
  source: ModuleInventoryInput,
): Promise<ModuleInventory> {
  let input: ModuleInventoryInput
  try {
    if (
      !source ||
      !Array.isArray(source.declared) ||
      source.declared.length > 256
    )
      throw new Error()
    input = {
      ...source,
      snapshot: { ...source.snapshot },
      declared: source.declared.map((entry) => {
        switch (entry.kind) {
          case 'root':
            assertHex(entry.id, 21)
            return { ...entry, id: entry.id.toLowerCase() as Hex }
          case 'validator':
          case 'executor':
            assertAddress(entry.address)
            return { ...entry, address: entry.address.toLowerCase() as Address }
          case 'fallback':
            assertHex(entry.selector, 4)
            assertAddress(entry.address)
            return { ...entry, selector: entry.selector.toLowerCase() as Hex }
          case 'permission':
            assertHex(entry.id, 4)
            assertAddress(entry.signer)
            if (!Array.isArray(entry.policies) || entry.policies.length > 64)
              throw new Error()
            entry.policies.forEach(assertAddress)
            return {
              ...entry,
              id: entry.id.toLowerCase() as Hex,
              policies: [...entry.policies],
            }
          case 'hook':
            assertAddress(entry.address)
            if (
              !/^0x(?:0101[0-9a-f]{40}|0102[0-9a-f]{8}0{32}|02[0-9a-f]{40}|03[0-9a-f]{8})$/i.test(
                entry.context,
              )
            )
              throw new Error()
            return { ...entry, context: entry.context.toLowerCase() as Hex }
          default:
            throw new Error()
        }
      }),
      ...(source.budget ? { budget: { ...source.budget } } : {}),
    }
    if (
      input.profile !== 'kernel-0.4.0' ||
      !Number.isSafeInteger(input.chainId) ||
      input.chainId < 1
    )
      throw new Error()
    assertAddress(input.account)
    assertHex(input.snapshot.blockHash, 32)
    for (const number of [input.fromBlock, input.snapshot.blockNumber]) {
      if (
        typeof number !== 'string' ||
        !/^(0|[1-9][0-9]{0,77})$/.test(number) ||
        BigInt(number) >= 1n << 256n
      )
        throw new Error()
    }
  } catch {
    throw new ModuleInventoryError('invalid_inventory_input')
  }
  const height = BigInt(input.snapshot.blockNumber),
    origin = BigInt(input.fromBlock)
  if (origin > height) throw new ModuleInventoryError('invalid_inventory_input')
  const blockHash = input.snapshot.blockHash.toLowerCase() as Hex
  const account = input.account.toLowerCase() as Address
  const budget = createReadBudget(request, input.budget)
  const fence = async () => {
    if (
      fromQuantity(await budget.request({ method: 'eth_chainId' })) !==
      BigInt(input.chainId)
    )
      throw new ModuleInventoryError('inventory_chain_mismatch')
    const header = await budget.request<{ number: Hex; hash: Hex } | null>({
      method: 'eth_getBlockByNumber',
      params: [toQuantity(height), false],
    })
    if (
      !header ||
      fromQuantity(header.number) !== height ||
      typeof header.hash !== 'string' ||
      header.hash.toLowerCase() !== blockHash
    )
      throw new ModuleInventoryError('inventory_not_canonical')
  }
  await fence()
  const entries = new Map<string, ModuleInventoryEntry>()
  const checked = new Set<string>()
  const add = (entry: ModuleInventoryEntry) =>
    entries.set(entryKey(entry), entry)
  const hook = (context: Hex, value: Address) => {
    checked.add(`hook:${context}`)
    if (value !== zero) add({ kind: 'hook', context, address: value })
  }
  const observe = (data: Hex, value: Hex) => {
    const call = decodeFunctionData({ abi, data })
    const result = decodeFunctionResult({
      abi,
      functionName: call.functionName,
      data: value,
    })
    if (call.functionName === 'root') {
      checked.add('root')
      const id = result as Hex
      if (id !== `0x${'00'.repeat(21)}`) add({ kind: 'root', id })
    } else if (call.functionName === 'isModuleInstalled') {
      const kind =
        call.args[0] === 1n
          ? 'validator'
          : call.args[0] === 2n
            ? 'executor'
            : null
      if (kind) {
        const address = call.args[1].toLowerCase() as Address
        checked.add(`${kind}:${address}`)
        if (result === true) add({ kind, address })
      }
    } else if (call.functionName === 'validationInfo') {
      const id = call.args[0].toLowerCase() as Hex
      const info = result as {
        installed: boolean
        signer: Address
        policies: Address[]
        scopedExecutionHook: Address
      }
      if (id.startsWith('0x02')) {
        const permissionId: Hex = `0x${id.slice(4, 12)}`
        checked.add(`permission:${permissionId}`)
        if (info.installed)
          add({
            kind: 'permission',
            id: permissionId as Hex,
            signer: info.signer,
            policies: info.policies,
          })
      }
      hook(
        `0x01${id.slice(2)}`,
        info.installed ? info.scopedExecutionHook : zero,
      )
    } else if (call.functionName === 'executorConfig') {
      const address = call.args[0].toLowerCase() as Address
      const info = result as {
        installed: boolean
        scopedExecutionHook: Address
      }
      checked.add(`executor:${address}`)
      if (info.installed) add({ kind: 'executor', address })
      hook(
        `0x02${address.slice(2)}`,
        info.installed ? info.scopedExecutionHook : zero,
      )
    } else if (call.functionName === 'selectorConfig') {
      const selector = call.args[0].toLowerCase() as Hex
      const info = result as { target: Address; scopedExecutionHook: Address }
      checked.add(`fallback:${selector}`)
      if (info.target !== zero)
        add({ kind: 'fallback', selector, address: info.target })
      hook(
        `0x03${selector.slice(2)}`,
        info.target !== zero ? info.scopedExecutionHook : zero,
      )
    }
  }
  const pinned: Request = async (rpc) => {
    if (rpc.method === 'eth_call') {
      const call = rpc.params?.[0] as { to: Address; data: Hex }
      if (call.to.toLowerCase() !== account)
        throw new ModuleInventoryError('invalid_inventory_input')
      const value = await budget.request<Hex>({
        method: rpc.method,
        params: [
          { ...call, from: account },
          { blockHash, requireCanonical: true },
        ],
      })
      observe(call.data, value)
      return value as never
    }
    return budget.request(rpc)
  }
  const validators = new Set<Address>(),
    executors = new Set<Address>(),
    permissionIds = new Set<Hex>(),
    selectors = new Set<Hex>()
  for (const entry of input.declared) {
    if (entry.kind === 'validator') validators.add(entry.address)
    if (entry.kind === 'executor') executors.add(entry.address)
    if (entry.kind === 'permission') permissionIds.add(entry.id)
    if (entry.kind === 'fallback') selectors.add(entry.selector)
    if (entry.kind === 'hook') {
      if (entry.context.startsWith('0x0101'))
        validators.add(`0x${entry.context.slice(6)}`)
      else if (entry.context.startsWith('0x0102'))
        permissionIds.add(`0x${entry.context.slice(6, 14)}`)
      else if (entry.context.startsWith('0x02'))
        executors.add(`0x${entry.context.slice(4)}`)
      else if (entry.context.startsWith('0x03'))
        selectors.add(`0x${entry.context.slice(4)}`)
      else throw new ModuleInventoryError('invalid_inventory_input')
    }
  }
  const client = {
    request: pinned,
    chain: {
      id: input.chainId,
      name: 'Pinned module observation',
      limits: { maxLogBlockRange: 1000, maxLogResults: 1000 },
    },
  } as Client
  const result = await readKernelModules(client, {
    address: account,
    version: '4',
    blockNumber: height,
    fromBlock: origin,
    permissionIds: [...permissionIds],
    selectors: [...selectors],
    ...(input.budget ? { budget: input.budget } : {}),
  })
  const read = (
    functionName: 'isModuleInstalled' | 'validationInfo' | 'executorConfig',
    args: readonly unknown[],
  ) =>
    pinned({
      method: 'eth_call',
      params: [
        {
          to: account,
          data: encodeFunctionData({ abi, functionName, args: args as never }),
        },
        toQuantity(height),
      ],
    })
  for (const address of validators) {
    if (!checked.has(`validator:${address}`))
      await read('isModuleInstalled', [1n, address, '0x'])
    if (!entries.has(`validator:${address}`))
      checked.add(`hook:0x0101${address.slice(2)}`)
    if (
      entries.has(`validator:${address}`) &&
      !checked.has(`hook:0x0101${address.slice(2)}`)
    )
      await read('validationInfo', [`0x01${address.slice(2)}`])
  }
  for (const address of executors)
    if (
      !checked.has(`executor:${address}`) ||
      !checked.has(`hook:0x02${address.slice(2)}`)
    )
      await read('executorConfig', [address])
  // A positive history event never stands in for current state or complete enumeration.
  const counts = new Map<
    string,
    { type: string; address: Address; installed: number; uninstalled: number }
  >()
  for (const log of result.history.logs) {
    const event = decodeEventLog({ abi, data: log.data, topics: log.topics })
    const type = event.args.moduleType.toString(),
      address = event.args.module.toLowerCase() as Address
    const key = `${type}:${address}`,
      count = counts.get(key) ?? { type, address, installed: 0, uninstalled: 0 }
    count[event.eventName === 'ModuleInstalled' ? 'installed' : 'uninstalled']++
    counts.set(key, count)
  }
  await fence()
  if (entries.size > 256 || counts.size > 1024 || checked.size > 1024)
    throw new ModuleInventoryError('invalid_inventory_response')
  const output: ModuleInventory = {
    profile: input.profile,
    account,
    snapshot: {
      chainId: input.chainId,
      blockNumber: height.toString(),
      blockHash,
    },
    entries: [...entries.values()].sort((a, b) =>
      entryKey(a).localeCompare(entryKey(b)),
    ),
    checked: [...checked].sort(),
    history: {
      fromBlock: result.history.fromBlock.toString(),
      toBlock: height.toString(),
      nextBlock: result.history.nextBlock.toString(),
      complete: result.history.complete,
      counts: [...counts.values()],
    },
    complete: result.complete,
    reason: result.complete ? null : (result.reason ?? 'partial-history'),
  }
  return output
}
