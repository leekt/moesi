import { wasmBase64 } from './keccak.wasm.js'

type KeccakExports = {
  memory: WebAssembly.Memory
  Hash_GetBuffer(): number
  Hash_Calculate(length: number, bits: number, padding: number): void
  Hash_Init(bits: number): void
  Hash_Update(length: number): void
  Hash_Final(padding: number): void
}

const capacity = 16_384

/** Private whole-operation adapter; both inputs must already be plain local views. */
export async function createKeccak256(): Promise<
  (head: Uint8Array, tail?: Uint8Array) => Uint8Array
> {
  if (typeof WebAssembly === 'undefined')
    throw new Error('WebAssembly is not supported in this environment!')
  const binary = Uint8Array.from(atob(wasmBase64), (character) =>
    character.charCodeAt(0),
  )
  const module = await WebAssembly.compile(binary)
  if (WebAssembly.Module.imports(module).length !== 0)
    throw new Error('Unexpected WASM Keccak imports.')
  const instance = await WebAssembly.instantiate(module, {})
  const exports = instance.exports as KeccakExports
  if (exports.memory.buffer.byteLength !== 131_072)
    throw new Error('Unexpected WASM Keccak memory size.')
  const io = new Uint8Array(
    exports.memory.buffer,
    exports.Hash_GetBuffer(),
    capacity,
  )
  const update = (bytes: Uint8Array): void => {
    for (let offset = 0; offset < bytes.length; offset += capacity) {
      const length = Math.min(capacity, bytes.length - offset)
      // Construct a plain view instead of invoking a caller's species hook.
      io.set(new Uint8Array(bytes.buffer, bytes.byteOffset + offset, length))
      exports.Hash_Update(length)
    }
  }
  return (head, tail) => {
    if (tail === undefined && head.length <= capacity) {
      io.set(head)
      exports.Hash_Calculate(head.length, 256, 0x01)
    } else {
      exports.Hash_Init(256)
      update(head)
      if (tail !== undefined) update(tail)
      exports.Hash_Final(0x01)
    }
    // Finalization writes the digest over the input buffer. Never lend it out.
    return io.slice(0, 32)
  }
}
