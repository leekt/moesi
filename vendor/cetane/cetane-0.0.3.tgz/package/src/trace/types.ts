/** Structured, payload-free timing emitted when a span finishes. Times are monotonic milliseconds. */
export type TraceSpan = Readonly<{
  operationId: number
  id: number
  parentId?: number
  name: string
  startMs: number
  durationMs: number
  status: 'ok' | 'error'
  attributes?: Readonly<Record<string, string | number | boolean>>
}>

/** Observers must finish quickly; their exceptions never alter the operation. */
export type TraceSink = (span: TraceSpan) => void

/** Explicit parentage keeps concurrent operations and parallel authorization branches separate. */
export type TraceContext = Readonly<{
  sink: TraceSink
  operationId: number
  spanId?: number
  /** Injectable monotonic clock, primarily for deterministic diagnostics tests. */
  now?: () => number
  /** Decide once per root operation. False or a thrown error disables its entire span tree. */
  sample?: () => boolean
}>
